#!/bin/sh

# Sample script to stop a Cisco HDLC connection
#
# Invokation: ./start-cisco.sh [device name]
#
# $Id: stop-cisco.sh,v 1.5 2006/06/13 14:33:07 paulkf Exp $
#
# For more details refer to the README.Cisco file in
# the SyncLink software directory.


# locate the necessary utilities
# these locations may be distribution specific

IFCONFIG=/sbin/ifconfig


# set the SyncLink device name and network interface name
# Note: the device instance number is determined when loading
# the driver. 
#
# Naming conventions:
#
#	Adapter		Device Name	Network Interface Name
#
# SyncLink GT/GT2/GT4	/dev/ttySLG0	mgslg0
#			/dev/ttySLG1	mgslg1
#				etc.
#
# SyncLink WAN Adapter	/dev/ttySL0	mgsl0
#			/dev/ttySL1	mgsl1
#				etc.
#
# SyncLink MultiPort	/dev/ttySLM0p0	mgslm0p0
#	Adapter		/dev/ttySLM0p1	mgslm0p1
#			/dev/ttySLM0p2	mgslm0p2
#			/dev/ttySLM0p2	mgslm0p2
#			/dev/ttySLM1p0	mgslm0p0
#				etc.
#
# SyncLink SCC Adapter	/dev/ttySLS0	mgsls0
#			/dev/ttySLS1	mgsls1
#				etc.

# Device name is 1st argument to this script.
# Default to 1st Synclink adapter if not specified.

PORT=$1
if [ -z $PORT ] ; then
    PORT=/dev/ttySLG0
    echo "Device name not specified, defaulting to $PORT"
fi

# Derive the network interface name from the device name.
# The derived name can be overriden by specifying the network
# device name as the second argument to this script.

NETIF=$2

if [ -z $NETIF ] ; then
    NETIF=mgsl`echo $PORT | awk -F "ttySL" "/ttySL/ {print tolower(\\$2)}"`
else
    echo "Network interface name manually specified as $NETIF"
fi

if [ -z $NETIF ] ; then
    echo "Net I/F name was not specified and can't be derived from device name."
    exit 1
fi


# disable the network interface
#
# Note: This next line is just a sample. Some distributions use
# special scripts for handling network interfaces. For example,
# RedHat uses the if-up and if-down scripts.

echo "Disabling the network interface ${NETIF}..."
$IFCONFIG $NETIF down
