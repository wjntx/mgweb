#!/bin/sh
PATH=/sbin:/usr/sbin:/bin:/usr/bin

# Sample script to activate PPP connection using a SyncLink adapter
# and the pppd program.
#
# $Id: start-ppp.sh,v 1.15 2006/06/13 14:33:07 paulkf Exp $
#
# This script does not use PAP or CHAP authorization. Refer to
# the pppd documentation for details on authorization.
#
# This script does not use chat to autodial or setup a connection.
# pppd raises DTR and waits for DCD active to start connection.

# Set to yes for synchronous HDLC mode, otherwise async PPP is used

SYNC=yes

# This is the network device name created by pppd.
# If you have only one ppp connection leave this at ppp0.
# For additional connections use ppp1, ppp2 etc.

DEVICE=ppp0

# MODEMPORT is the device name of the SyncLink device.
#
# SyncLink GT/GT2/GT4 use /dev/ttySLGx where x is the adapter number
#
# SyncLink PCI/ISA use /dev/ttySLx where x is the adapter number
#
# SyncLink Multiport use /dev/ttySLMxpy where x is the adapter number
# and y is the port number.
#
# SyncLink SCC use /dev/ttySLSx where x is the adapter number
# 
# adapter and port numbers start at 0
#
# see readme.txt for more information of synclink adapter
# device naming conventions.

MODEMPORT=/dev/ttySLG0

# If this port needs to generate an output clock on the
# AUXCLK signal, set GENCLOCK to the data rate in bits per
# second. If data clocks are provided by an external
# device, then set GENCLOCK to zero (default).
#
# Generating a clock is usually only necessary when connecting
# two ports back to back through a NULL modem (cross over cable).
# In this case, one side of the connection generates the clock
# which must be routed to the RxC and TxC input signals on
# both sides of the connection.

GENCLOCK=0

# Asynchronous line speed in bits per second.
# Ignored for synchronous HDLC mode.

LINESPEED=38400

# Output debug information to the system log.
# Set to yes to diagnose problems. Set to no for
# production environment.

DEBUG=no

# Set this to yes to have pppd create a default route
# in the routing table that uses the ppp network interface.

DEFROUTE=yes

# Monitor the modem status signals.

HARDFLOWCTL=yes

# Misc pppd options. Refer to pppd documentation for
# a list of options.

PPPOPTIONS=

# Remote and local IP address. Usually only the
# local IP address is specified.

REMIP=
IPADDR=192.168.60.1

# Maximum Receive/Transmit Unit size in bytes.
# Leave blank unless you know what they do.

MRU=
MTU=

if [ "$1" != daemon ] ; then
  # disconnect stdin, out, err to disassociate from controlling tty
  # so that no HUPs will get through.
  $0 daemon $*& </dev/null >/dev/null 2>/dev/null
  exit 0
fi
shift

[ -x /usr/sbin/pppd ] || {
  echo "/usr/sbin/pppd does not exist or is not executable"
  exit 1
}

[ -c $MODEMPORT ] || {
  echo -e "SyncLink device $MODEMPORT does not exist.\n" \
          "Be sure that SyncLink device driver is loaded" \
          "and proper device instance is specified.\n"
  exit 1
}

opts="lock noauth"
if [ "${HARDFLOWCTL}" = yes ] ; then
  opts="$opts modem crtscts"
fi
if [ "${DEFROUTE}" = yes ] ; then
  opts="$opts defaultroute"
fi
if [ -n "${MRU}" ] ; then
  opts="$opts mru ${MRU}"
fi
if [ -n "${MTU}" ] ; then
  opts="$opts mtu ${MTU}"
fi
if [ -n "${IPADDR}${REMIP}" ] ; then
  # if either IP address is set, the following will work.
  opts="$opts ${IPADDR}:${REMIP}"
fi
if [ "${DEBUG}" = yes ] ; then
  opts="$opts debug"
  chatdbg="-v"
fi


#-----------------------------------------------------------
# load necessary drivers using the sample driver load script
#-----------------------------------------------------------

echo "Loading necessary drivers for $MODEMPORT..."
./load-drivers.sh $MODEMPORT || exit 1

#-----------------------------------------------
# Use mgslutil to configure the SyncLink adapter
#-----------------------------------------------

if [ ! -f ./mgslutil ] ; then
    echo "Can't find mgslutil program."
    echo "Verify program is built and installed in PATH."
    exit 1
fi

if [ "$SYNC" = "yes" ]; then
    PORTOPTIONS="hdlc nrz -loopback clock $GENCLOCK rxc"

    if [ "$GENCLOCK" = "0" ]; then
	# External clocks, use TxC input as transmit clock
	PORTOPTIONS="$PORTOPTIONS txc"
    else
	# Generating clock output on AUXCLK, use Baud Rate Generator
	# (generated clock source) directly as the transmit clock.
	# This is necessary because the multiport adapter can't generate
	# AUXCLK output and use the TxC input at the same time.
	PORTOPTIONS="$PORTOPTIONS txbrg"
    fi

    # add PPPD sync option
    opts="$opts sync"
else
    PORTOPTIONS="quiet async -loopback"
fi

# Uncomment one of the following lines to select the
# serial interface type. This option is only useful for
# adapters that have a programmable interface such as the
# SyncLink PC Card

#SERIAL_IF=rs232
#SERIAL_IF=v35
#SERIAL_IF=rs422

PORTOPTIONS="$PORTOPTIONS $SERIAL_IF"

#-------------------------------------------------------
# Default behavior for TTY ports is to activate DTR when
# the port is opened and deactivate DTR when the port is
# closed. This causes a problem when using NULL modem
# connections to connect two systems back-to-back for
# testing. Use 'stty' to clear this HUPCL (hang up on
# close) behavior before using 'mgslutil' to configure
# the port.
#-------------------------------------------------------
stty --file=$MODEMPORT -hupcl

./mgslutil $MODEMPORT $PORTOPTIONS

#-------------------------------------------
# start pppd program with configured options
#-------------------------------------------

/usr/sbin/pppd -detach $opts $MODEMPORT $LINESPEED \
    remotename $DEVICE ipparam $DEVICE \
    ${PPPOPTIONS}

#-------------------------------------------
# reset default HUPCL behavior on port after
# ppp session terminates.
#-------------------------------------------
stty --file=$MODEMPORT hupcl

