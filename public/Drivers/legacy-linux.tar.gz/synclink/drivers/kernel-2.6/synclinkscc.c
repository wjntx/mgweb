/*
 * linux/drivers/char/synclinkscc.c
 *
 * $Id: synclinkscc.c,v 4.28 2006/01/06 21:41:41 paulkf Exp $
 *
 * Device driver for Microgate SyncLink SCC PCI serial adapters.
 *
 * written by Paul Fulghum for Microgate Corporation
 * paulkf@microgate.com
 *
 * Microgate and SyncLink are trademarks of Microgate Corporation
 *
 * Derived from serial.c written by Theodore Ts'o and Linus Torvalds
 *
 * Original release 01/11/99
 *
 * This code is released under the GNU General Public License (GPL)
 *
 * This driver is primarily intended for use in synchronous
 * HDLC mode. Asynchronous mode is also provided.
 *
 * When operating in synchronous mode, each call to mgscc_write()
 * contains exactly one complete HDLC frame. Calling mgscc_put_char
 * will start assembling an HDLC frame that will not be sent until
 * mgscc_flush_chars or mgscc_write is called.
 *
 * Synchronous receive data is reported as complete frames. To accomplish
 * this, the TTY flip buffer is bypassed (too small to hold largest
 * frame and may fragment frames) and the line discipline
 * receive entry point is called directly.
 *
 * This driver has been tested with a slightly modified ppp.c driver
 * for synchronous PPP.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#define VERSION(ver,rel,seq) (((ver)<<16) | ((rel)<<8) | (seq))
#if defined(__i386__)
#  define BREAKPOINT() asm("   int $3");
#else
#  define BREAKPOINT() { }
#endif

#define MAX_PCI_DEVICES 10
#define MAX_TOTAL_DEVICES MAX_PCI_DEVICES

#include <linux/config.h>
#include <linux/module.h>
#include <linux/errno.h>
#include <linux/signal.h>
#include <linux/sched.h>
#include <linux/timer.h>
#include <linux/interrupt.h>
#include <linux/pci.h>
#include <linux/tty.h>
#include <linux/tty_flip.h>
#include <linux/serial.h>
#include <linux/major.h>
#include <linux/string.h>
#include <linux/fcntl.h>
#include <linux/ptrace.h>
#include <linux/ioport.h>
#include <linux/mm.h>
#include <linux/slab.h>
#include <linux/netdevice.h>
#include <linux/vmalloc.h>
#include <linux/init.h>
#include <asm/serial.h>
#include <linux/delay.h>
#include <linux/ioctl.h>

#include <asm/system.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <linux/bitops.h>
#include <asm/types.h>
#include <linux/termios.h>
#include <linux/workqueue.h>
#include <linux/hdlc.h>

#ifdef CONFIG_HDLC_MODULE
#define CONFIG_HDLC 1
#endif

#define GET_USER(error,value,addr) error = get_user(value,addr)
#define COPY_FROM_USER(error,dest,src,size) error = copy_from_user(dest,src,size) ? -EFAULT : 0
#define PUT_USER(error,value,addr) error = put_user(value,addr)
#define COPY_TO_USER(error,dest,src,size) error = copy_to_user(dest,src,size) ? -EFAULT : 0

#include <asm/uaccess.h>

#include "linux/synclink.h"

MGSL_PARAMS default_params = {
	MGSL_MODE_HDLC,			/* unsigned long mode */
	0,				/* unsigned char loopback; */
	HDLC_FLAG_UNDERRUN_ABORT7,	/* unsigned short flags; */
	HDLC_ENCODING_NRZI_SPACE,	/* unsigned char encoding; */
	0,				/* unsigned long clock_speed; */
	0xff,				/* unsigned char addr_filter; */
	HDLC_CRC_16_CCITT,		/* unsigned short crc_type; */
	HDLC_PREAMBLE_LENGTH_8BITS,	/* unsigned char preamble_length; */
	HDLC_PREAMBLE_PATTERN_NONE,	/* unsigned char preamble; */
	9600,				/* unsigned long data_rate; */
	8,				/* unsigned char data_bits; */
	1,				/* unsigned char stop_bits; */
	ASYNC_PARITY_NONE		/* unsigned char parity; */
};

#define MAXRXFRAMES 7

typedef struct _BUFFERENTRY
{
	u16 count;		/* buffer size/data count */
	u16 status;		/* Control/status field */
	u16 rcc;		/* character count field */
	char *get;		/* pointer to next char to retrieve */
	char *put;		/* pointer to next position to put char */
	char *databuffer;	/* virtual address of data buffer */
} BUFFERENTRY, *PBUFFERENTRY;

/* The queue of BH actions to be performed */

#define BH_RECEIVE  1
#define BH_TRANSMIT 2
#define BH_STATUS   4

#define IO_PIN_SHUTDOWN_LIMIT 100

#define RELEVANT_IFLAG(iflag) (iflag & (IGNBRK|BRKINT|IGNPAR|PARMRK|INPCK))

struct	_input_signal_events {
	int	ri_up;
	int	ri_down;
	int	dsr_up;
	int	dsr_down;
	int	dcd_up;
	int	dcd_down;
	int	cts_up;
	int	cts_down;
};

/*
 * Device instance data structure
 */

struct mgscc_struct {
	void *if_ptr;	/* General purpose pointer (used by SPPP) */
	int			magic;
	int			flags;
	int			count;		/* count of opens */
	int			line;
	unsigned short		close_delay;
	unsigned short		closing_wait;	/* time to wait before closing */

	struct mgsl_icount	icount;

	struct tty_struct	*tty;
	int			timeout;
	int			x_char;		/* xon/xoff character */
	int			blocked_open;	/* # of blocked opens */
	u16			read_status_mask;
	u16			ignore_status_mask;
	unsigned char		*xmit_buf;
	int			xmit_head;
	int			xmit_tail;
	int			xmit_cnt;

	wait_queue_head_t	open_wait;
	wait_queue_head_t	close_wait;

	wait_queue_head_t	status_event_wait_q;
	wait_queue_head_t	event_wait_q;
	struct timer_list	tx_timer;	/* HDLC transmit timeout timer */
	struct mgscc_struct	*next_device;	/* device list link */

	spinlock_t irq_spinlock;		/* spinlock for synchronizing with ISR */
	struct work_struct task;		/* task structure for scheduling bh */

	u32 max_frame_size;		/* as set by device config */

	u32 pending_bh;

	int bh_running;		/* Protection from multiple */
	int bh_requested;

	int dcd_chkcount;		/* check counts to prevent */
	int cts_chkcount;		/* too many IRQs if a signal */
	int dsr_chkcount;		/* is floating */
	int ri_chkcount;

	char *buffer_list;		/* virtual address of Rx & Tx buffer lists */

	unsigned int rx_buffer_count;	/* count of total allocated Rx buffers */
	BUFFERENTRY *rx_buffer_list;	/* list of receive buffer entries */
	unsigned int current_rx_buffer;
	unsigned int scc_rx_buffer;
	u16	scc_rx_databuffer_size;

	unsigned int tx_buffer_count;	/* count of total allocated Tx buffers */
	BUFFERENTRY *tx_buffer_list;	/* list of transmit buffer entries */
	unsigned int current_tx_buffer;

	unsigned int cts_failure;
	unsigned int abort_requested;
	unsigned int waiting_on_tx_crc;
	int	break_detected;

	unsigned char *intermediate_rxbuffer;

	int rx_enabled;
	int rx_overflow;

	int tx_enabled;
	int tx_active;
	u32 idle_mode;

	unsigned int	ctrl_b;
	unsigned int	data_b;
	unsigned int	ctrl_a;
	unsigned int	data_a;

	unsigned char	wr1a_value;
	unsigned char	wr15a_value;

	unsigned char	wr1b_value;
	unsigned char	wr3b_value;
	unsigned char	wr5b_value;
	unsigned char	wr6b_value;
	unsigned char	wr7b_prime_value;
	unsigned char	wr9b_value;
	unsigned char	wr10b_value;
	unsigned char	wr14b_value;
	unsigned char	wr15b_value;

	unsigned int	tx_fifo_size;

	char device_name[25];		/* device instance name */

	unsigned int bus_type;	/* expansion bus type (ISA,EISA,PCI) */
	unsigned char bus;		/* expansion bus number (zero based) */
	unsigned char function;		/* PCI device number */

	unsigned int io_base;		/* base I/O address of adapter */
	unsigned int io_addr_size;	/* size of the I/O address range */
	int io_addr_requested;		/* nonzero if I/O address requested */

	unsigned int irq_level;		/* interrupt level */
	unsigned long irq_flags;
	int irq_requested;		/* nonzero if IRQ requested */

	MGSL_PARAMS params;		/* communications parameters */

	unsigned char serial_signals;	/* current serial signal states */
	unsigned char last_serial_signals;

	int irq_occurred;		/* for diagnostics use */
	unsigned int init_error;	/* Initialization startup error			(DIAGS)	*/
	int	diagnostics_mode;	/* Driver in Diagnostic mode?			(DIAGS)	*/

	unsigned char* lcr_base;	/* local config registers (PCI only) */
	u32 phys_lcr_base;
	u32 lcr_offset;
	int lcr_mem_requested;


	u32 misc_ctrl_value;
	char flag_buf[MAX_ASYNC_BUFFER_SIZE];
	char char_buf[MAX_ASYNC_BUFFER_SIZE];
	BOOLEAN drop_rts_on_tx_done;

	struct	_input_signal_events	input_signal_events;

	/* SPPP/Cisco HDLC device parts */
	int netcount;
	int dosyncppp;
	spinlock_t netlock;

#ifdef CONFIG_HDLC
	struct net_device *netdev;
#endif

};

#define MGSL_MAGIC 0x5401	       /*  TODO: need to change??? */
#define MGSCC_MAGIC MGSL_MAGIC

/*
 * The size of the serial xmit buffer is 1 page, or 4096 bytes
 */
#ifndef SERIAL_XMIT_SIZE
#define SERIAL_XMIT_SIZE 4096
#endif

/*
 * MACRO DEFINITIONS FOR MODEM STATUS BITS
 */

#define MODEMSTATUS_DTR 0x80
#define MODEMSTATUS_DSR 0x40
#define MODEMSTATUS_RTS 0x20
#define MODEMSTATUS_CTS 0x10
#define MODEMSTATUS_RI	0x04
#define MODEMSTATUS_DCD 0x01

/*
 * SCC Registers
 */
#define	RR0	0
#define	RR1	1
#define	RR2	2
#define	RR3	3
#define	RR4	4
#define	RR5	5
#define	RR6	6
#define	RR7	7
#define	RR8	8
#define	RR9	9
#define	RR10	10
#define	RR11	11
#define	RR12	12
#define	RR13	13
#define	RR14	14
#define	RR15	15

#define	WR0	0
#define	WR1	1
#define	WR2	2
#define	WR3	3
#define	WR4	4
#define	WR5	5
#define	WR6	6
#define	WR7	7
#define	WR8	8
#define	WR9	9
#define	WR10	10
#define	WR11	11
#define	WR12	12
#define	WR13	13
#define	WR14	14
#define	WR15	15

/*
 * Receive status Bits
 */

#define RXSTATUS_SHORT_FRAME		BIT8
#define RXSTATUS_CODE_VIOLATION		BIT8
#define RXSTATUS_EXITED_HUNT		BIT7
#define RXSTATUS_IDLE_RECEIVED		BIT6
#define RXSTATUS_BREAK_RECEIVED		BIT5
#define RXSTATUS_ABORT_RECEIVED		BIT5
#define RXSTATUS_RXBOUND		BIT4
#define RXSTATUS_CRC_ERROR		BIT3
#define RXSTATUS_FRAMING_ERROR		BIT3
#define RXSTATUS_ABORT			BIT2
#define RXSTATUS_PARITY_ERROR		BIT2
#define RXSTATUS_OVERRUN		BIT1
#define RXSTATUS_DATA_AVAILABLE		BIT0


/*
 * transmit status bits
 */
#define TXSTATUS_PREAMBLE_SENT		BIT7
#define TXSTATUS_IDLE_SENT		BIT6
#define TXSTATUS_ABORT_SENT		BIT5
#define TXSTATUS_EOF_SENT		BIT4
#define TXSTATUS_EOM_SENT		BIT4
#define TXSTATUS_CRC_SENT		BIT3
#define TXSTATUS_ALL_SENT		BIT2
#define TXSTATUS_UNDERRUN		BIT1
#define TXSTATUS_FIFO_EMPTY		BIT0


static unsigned char scc_InRegA( struct mgscc_struct *info, unsigned char Port )
	{ outb(Port,info->ctrl_a); return inb(info->ctrl_a); }
static void scc_OutRegA( struct mgscc_struct *info, unsigned char Port, unsigned char Value )
	{ outb(Port,info->ctrl_a); outb(Value,info->ctrl_a); }
static unsigned char scc_InRegB( struct mgscc_struct *info, unsigned char Port )
	{ outb(Port,info->ctrl_b); return inb(info->ctrl_b); }
static void scc_OutRegB( struct mgscc_struct *info, unsigned char Port, unsigned char Value )
	{ outb(Port,info->ctrl_b); outb(Value,info->ctrl_b); }


#define scc_EnableMasterIrqBit(i) \
	{ (i)->wr9b_value |= BIT3; scc_OutRegB((i),WR9,(i)->wr9b_value); }

#define scc_DisableMasterIrqBit(i) \
	{ (i)->wr9b_value &= ~BIT3; scc_OutRegB((i),WR9,(i)->wr9b_value); }

static void scc_start_receiver( struct mgscc_struct *info );
static void scc_stop_receiver( struct mgscc_struct *info );

static void scc_start_transmitter( struct mgscc_struct *info );
static void scc_stop_transmitter( struct mgscc_struct *info );
static void scc_set_txidle( struct mgscc_struct *info );
static void scc_preload_txfifo( struct mgscc_struct *info );

static void scc_enable_aux_clock( struct mgscc_struct *info, u32 DataRate );
static void scc_enable_loopback( struct mgscc_struct *info );

static void scc_get_serial_signals( struct mgscc_struct *info );
static void scc_set_serial_signals( struct mgscc_struct *info );

static void scc_reset( struct mgscc_struct *info );

static void scc_set_sync_mode( struct mgscc_struct *info );
static void scc_set_sdlc_mode( struct mgscc_struct *info );
static void scc_set_async_mode( struct mgscc_struct *info );
static void scc_load_tx_reg( struct mgscc_struct *info);

static void mgscc_tx_timeout(unsigned long context);

static int mgscc_ioctl_common(struct mgscc_struct *info, unsigned int cmd, unsigned long arg);
static void scc_enable_txfifo_empty( struct mgscc_struct *info, int enable );

#ifdef CONFIG_HDLC
#define dev_to_port(D) (dev_to_hdlc(D)->priv)
static void hdlcdev_tx_done(struct mgscc_struct *info);
static void hdlcdev_rx(struct mgscc_struct *info, char *buf, int size);
static int  hdlcdev_init(struct mgscc_struct *info);
static void hdlcdev_exit(struct mgscc_struct *info);
#endif

static void mgscc_trace_block(struct mgscc_struct *info,const char* data, int count, int xmit);

/*
 * Adapter diagnostic routines
 */
static BOOLEAN mgscc_register_test( struct mgscc_struct *info );
static BOOLEAN mgscc_irq_test( struct mgscc_struct *info );
static int mgscc_adapter_test( struct mgscc_struct *info );

/*
 * device and resource management routines
 */
static int mgscc_claim_resources(struct mgscc_struct *info);
static void mgscc_release_resources(struct mgscc_struct *info);
static void mgscc_add_device(struct mgscc_struct *info);
static struct mgscc_struct* mgscc_allocate_device(void);

/*
 * buffer manupulation functions.
 */
static void mgscc_free_rx_frame_buffer( struct mgscc_struct *info, unsigned int index);
static int  mgscc_get_rx_frame( struct mgscc_struct *info );
static void mgscc_reset_rx_buffers( struct mgscc_struct *info );
static void mgscc_load_tx_buffer( struct mgscc_struct *info, const char *Buffer, unsigned int BufferSize);

/*
 * Memory buffer allocation and formatting
 */
static int  mgscc_allocate_buffers(struct mgscc_struct *info);
static void mgscc_free_buffers(struct mgscc_struct *info);
static int  mgscc_alloc_frame_memory(struct mgscc_struct *info, BUFFERENTRY *BufferList,int Buffercount);
static void mgscc_free_frame_memory(struct mgscc_struct *info, BUFFERENTRY *BufferList,int Buffercount);
static int  mgscc_alloc_buffer_list_memory(struct mgscc_struct *info);
static void mgscc_free_buffer_list_memory(struct mgscc_struct *info);
static int mgscc_alloc_intermediate_rxbuffer_memory(struct mgscc_struct *info);
static void mgscc_free_intermediate_rxbuffer_memory(struct mgscc_struct *info);

/*
 * Bottom half interrupt handlers
 */
static void mgscc_bh_handler(void* Context);
static void mgscc_bh_receive(struct mgscc_struct *info);
static void mgscc_bh_transmit(struct mgscc_struct *info);
static void mgscc_bh_status(struct mgscc_struct *info);

/*
 * Interrupt handler routines and dispatch table.
 */
static void IsrTransmitB(struct mgscc_struct *info);
static void IsrStatusB(struct mgscc_struct *info);
static void IsrReceiveB(struct mgscc_struct *info);
static void IsrTransmitA(struct mgscc_struct *info);
static void IsrStatusA(struct mgscc_struct *info);
static void IsrReceiveA(struct mgscc_struct *info);
static void IsrSpecialA(struct mgscc_struct *info);

typedef void (*isr_dispatch_func)(struct mgscc_struct *);
static isr_dispatch_func IsrTable[] =
{
	IsrTransmitB,
	IsrStatusB,
	IsrReceiveB,
	IsrReceiveB,
	IsrTransmitA,
	IsrStatusA,
	IsrReceiveA,
	IsrSpecialA,
};

/*
 * ioctl call handlers
 */
static int tiocmget(struct tty_struct *tty, struct file *file);
static int tiocmset(struct tty_struct *tty, struct file *file,
		    unsigned int set, unsigned int clear);
static int mgscc_get_stats(struct mgscc_struct * info, struct mgsl_icount
	*user_icount);
static int mgscc_get_params(struct mgscc_struct * info, MGSL_PARAMS *user_params);
static int mgscc_set_params(struct mgscc_struct * info, MGSL_PARAMS *new_params);
static int mgscc_get_txidle(struct mgscc_struct * info, int*idle_mode);
static int mgscc_set_txidle(struct mgscc_struct * info, int idle_mode);
static int mgscc_txenable(struct mgscc_struct * info, int enable);
static int mgscc_txabort(struct mgscc_struct * info);
static int mgscc_rxenable(struct mgscc_struct * info, int enable);
static int mgscc_wait_event(struct mgscc_struct * info, int * mask);

#define jiffies_from_ms(a) ((((a) * HZ)/1000)+1)

/*
 * Global linked list of SyncLink SCC devices
 */
static struct mgscc_struct *mgscc_device_list = NULL;
static int mgscc_device_count = 0;

/*
 * Set this param to non-zero to load eax with the
 * .text section address and breakpoint on module load.
 * This is useful for use with gdb and add-symbol-file command.
 */
static int break_on_load=0;

/*
 * Driver major number, defaults to zero to get auto
 * assigned major number. May be forced as module parameter.
 */
static int ttymajor=0;

/*
 * Array of user specified options for ISA adapters.
 */
static int debug_level = 0;
static int maxframe[MAX_TOTAL_DEVICES] = {0,};
static int dosyncppp[MAX_TOTAL_DEVICES] = {0,};

MODULE_LICENSE("GPL");

module_param(break_on_load, bool, 0);
module_param(ttymajor, int, 0);
module_param(debug_level, int, 0);
module_param_array(maxframe, int, NULL, 0);
module_param_array(dosyncppp, int, NULL, 0);

static char *driver_name = "SyncLink SCC serial driver";
static char *driver_version = "$Revision: 4.28 $";

static int mgscc_init_one(struct pci_dev *dev,
			   const struct pci_device_id *ent);
static void mgscc_remove_one(struct pci_dev *dev);

static struct pci_device_id mgscc_pci_tbl[] = {
	{ PCI_VENDOR_ID_MICROGATE, MGSCC_DEVICE_ID, PCI_ANY_ID, PCI_ANY_ID, },
	{ 0, }, /* terminate list */
};
MODULE_DEVICE_TABLE(pci, mgscc_pci_tbl);

static struct pci_driver mgscc_pci_driver = {
	.name     = "synclinkscc",
	.id_table = mgscc_pci_tbl,
	.probe    = mgscc_init_one,
	.remove   = __devexit_p(mgscc_remove_one)
};

static struct tty_driver *serial_driver;

/* number of characters left in xmit buffer before we ask for more */
#define WAKEUP_CHARS 256


static void mgscc_change_params(struct mgscc_struct *info);
static void mgscc_wait_until_sent(struct tty_struct *tty, int timeout);

#ifndef MIN
#define MIN(a,b)	((a) < (b) ? (a) : (b))
#endif

/*
 * 1st function defined in .text section. Calling this function in
 * init_module() followed by a breakpoint allows a remote debugger
 * (gdb) to get the .text address for the add-symbol-file command.
 * This allows remote debugging of dynamically loadable modules.
 */
void* mgscc_get_text_ptr(void);
void* mgscc_get_text_ptr() {return mgscc_get_text_ptr;}

/*
 * tmp_buf is used as a temporary buffer by mgscc_write.  We need to
 * lock it in case the COPY_FROM_USER blocks while swapping in a page,
 * and some other program tries to do a serial write at the same time.
 * Since the lock will only come under contention when the system is
 * swapping and available memory is low, it makes sense to share one
 * buffer across all the serial ioports, since it significantly saves
 * memory if large numbers of serial ports are open.
 */
static unsigned char *tmp_buf;
static DECLARE_MUTEX(tmp_buf_sem);

static inline int mgscc_paranoia_check(struct mgscc_struct *info,
				       char *name, const char *routine)
{
#ifdef MGSCC_PARANOIA_CHECK
	static const char *badmagic =
		"Warning: bad magic number for mgscc struct (%s) in %s\n";
	static const char *badinfo =
		"Warning: null mgscc_struct for (%s) in %s\n";

	if (!info) {
		printk(badinfo, name, routine);
		return 1;
	}
	if (info->magic != MGSCC_MAGIC) {
		printk(badmagic, name, routine);
		return 1;
	}
#else
	if (!info)
		return 1;
#endif
	return 0;
}

/**
 * line discipline callback wrappers
 *
 * The wrappers maintain line discipline references
 * while calling into the line discipline.
 *
 * ldisc_receive_buf  - pass receive data to line discipline
 */

static void ldisc_receive_buf(struct tty_struct *tty,
			      const __u8 *data, char *flags, int count)
{
	struct tty_ldisc *ld;
	if (!tty)
		return;
	ld = tty_ldisc_ref(tty);
	if (ld) {
		if (ld->receive_buf)
			ld->receive_buf(tty, data, flags, count);
		tty_ldisc_deref(ld);
	}
}

/* mgscc_stop()		throttle (stop) transmitter
 *
 * Arguments:		tty	pointer to tty info structure
 * Return Value:	None
 */
static void mgscc_stop(struct tty_struct *tty)
{
	struct mgscc_struct *info = (struct mgscc_struct *)tty->driver_data;
	unsigned long flags;

	if (mgscc_paranoia_check(info, tty->name, "mgscc_stop"))
		return;

	if ( debug_level >= DEBUG_LEVEL_INFO )
		printk("mgscc_stop(%s)\n",info->device_name);

	spin_lock_irqsave(&info->irq_spinlock,flags);
	if (info->tx_enabled)
		scc_stop_transmitter(info);
	spin_unlock_irqrestore(&info->irq_spinlock,flags);

}	/* end of mgscc_stop() */

/* mgscc_start()		release (start) transmitter
 *
 * Arguments:		tty	pointer to tty info structure
 * Return Value:	None
 */
static void mgscc_start(struct tty_struct *tty)
{
	struct mgscc_struct *info = (struct mgscc_struct *)tty->driver_data;
	unsigned long flags;

	if (mgscc_paranoia_check(info, tty->name, "mgscc_start"))
		return;

	if ( debug_level >= DEBUG_LEVEL_INFO )
		printk("mgscc_start(%s)\n",info->device_name);

	spin_lock_irqsave(&info->irq_spinlock,flags);
	if (!info->tx_enabled)
		scc_start_transmitter(info);
	spin_unlock_irqrestore(&info->irq_spinlock,flags);

}	/* end of mgscc_start() */

/*
 * Bottom half work queue access functions
 */

/* mgscc_bh_action()	Return next bottom half action to perform.
 * Return Value:	BH action code or 0 if nothing to do.
 */
int mgscc_bh_action(struct mgscc_struct *info)
{
	unsigned long flags;
	int rc = 0;

	spin_lock_irqsave(&info->irq_spinlock,flags);

	if (info->pending_bh & BH_RECEIVE) {
		info->pending_bh &= ~BH_RECEIVE;
		rc = BH_RECEIVE;
	} else if (info->pending_bh & BH_TRANSMIT) {
		info->pending_bh &= ~BH_TRANSMIT;
		rc = BH_TRANSMIT;
	} else if (info->pending_bh & BH_STATUS) {
		info->pending_bh &= ~BH_STATUS;
		rc = BH_STATUS;
	}

	if (!rc) {
		/* Mark BH routine as complete */
		info->bh_running   = 0;
		info->bh_requested = 0;
	}

	spin_unlock_irqrestore(&info->irq_spinlock,flags);

	return rc;
}

/*
 *	Perform bottom half processing of work items queued by ISR.
 */
void mgscc_bh_handler(void* Context)
{
	struct mgscc_struct *info = (struct mgscc_struct*)Context;
	int action;

	if (!info)
		return;

	if ( debug_level >= DEBUG_LEVEL_BH )
		printk( "%s(%d):mgscc_bh_handler(%s) entry\n",
			__FILE__,__LINE__,info->device_name);

	info->bh_running = 1;

	while((action = mgscc_bh_action(info)) != 0) {

		/* Process work item */
		if ( debug_level >= DEBUG_LEVEL_BH )
			printk( "%s(%d):mgscc_bh_handler() work item action=%d\n",
				__FILE__,__LINE__,action);

		switch (action) {

		case BH_RECEIVE:
			mgscc_bh_receive(info);
			break;
		case BH_TRANSMIT:
			mgscc_bh_transmit(info);
			break;
		case BH_STATUS:
			mgscc_bh_status(info);
			break;
		default:
			/* unknown work item ID */
			printk("Unknown work item ID=%08X!\n", action);
			break;
		}
	}

	if ( debug_level >= DEBUG_LEVEL_BH )
		printk( "%s(%d):mgscc_bh_handler(%s) exit\n",
			__FILE__,__LINE__,info->device_name);
}

void mgscc_bh_receive(struct mgscc_struct *info)
{
	if ( debug_level >= DEBUG_LEVEL_BH )
		printk( "%s(%d):mgscc_bh_receive(%s)\n",
			__FILE__,__LINE__,info->device_name);

	while( mgscc_get_rx_frame(info) );
}

void mgscc_bh_transmit(struct mgscc_struct *info)
{
	struct tty_struct *tty = info->tty;

	if ( debug_level >= DEBUG_LEVEL_BH )
		printk( "%s(%d):mgscc_bh_transmit() entry on %s\n",
			__FILE__,__LINE__,info->device_name);

	if (tty) {
		tty_wakeup(tty);
		wake_up_interruptible(&tty->write_wait);
	}
}

void mgscc_bh_status(struct mgscc_struct *info)
{
	if ( debug_level >= DEBUG_LEVEL_BH )
		printk( "%s(%d):mgscc_bh_status() entry on %s\n",
			__FILE__,__LINE__,info->device_name);

	info->ri_chkcount = 0;
	info->dsr_chkcount = 0;
	info->dcd_chkcount = 0;
	info->cts_chkcount = 0;
}

/*
 *
 * void rx_frame_complete()
 *
 * handle a rx frame complete condition
 *
 * Arguments:		info		pointer to device instance data
 * Return Value:	None
 *
 */
void rx_frame_complete(struct mgscc_struct *info, u16 status )
{
	BUFFERENTRY *pBufEntry;
	int index = info->scc_rx_buffer;

	if ( debug_level >= DEBUG_LEVEL_INFO )
		printk("%s(%u) rx_frame_complete, #%u status=%x\n",
			__FILE__,__LINE__,index,status);

	/* save frame status */
	pBufEntry = &info->rx_buffer_list[index];
	pBufEntry->status = status;

	/*
	 * advance to next rx buffer
	 */
	if ( ++index >= info->rx_buffer_count )
		index = 0;

	info->scc_rx_buffer = index;
	pBufEntry = &info->rx_buffer_list[index];

	if ( !pBufEntry->count ) {
		info->rx_overflow = 1;
		info->icount.buf_overrun++;
	}
	else {
		info->scc_rx_databuffer_size = pBufEntry->count;
		pBufEntry->count = 0;
		pBufEntry->get = pBufEntry->put = pBufEntry->databuffer;
	}

	info->pending_bh |= BH_RECEIVE;
}

/*
 *
 * void tx_frame_complete()
 *
 * handle a transmit complete condition
 *
 * Arguments:		info		pointer to device instance data
 * Return Value:	None
 */
void tx_frame_complete(struct mgscc_struct *info, int status)
{
	if ( debug_level >= DEBUG_LEVEL_INFO )
		printk("%s(%d):tx_frame_complete, status=%x\n",
			__FILE__,__LINE__,status);

	/* disable Tx Underrun/EOM Irq */
	info->wr15b_value &= ~BIT6;
	scc_OutRegB(info, WR15, info->wr15b_value);

	/* disable transmitter interrupts */
	info->wr1b_value &= ~BIT1;
	scc_OutRegB( info, WR1, info->wr1b_value );

	outb( 0x28, info->ctrl_b);     /* reset TxInt Pending */

	/* return to the configured idle mode for 8530 */
	if (info->tx_fifo_size == 1)
		scc_set_txidle(info);

	info->tx_active = 0;
	info->xmit_cnt = info->xmit_head = info->xmit_tail = 0;
	del_timer(&info->tx_timer);

	if ( info->drop_rts_on_tx_done ) {
		if ( info->serial_signals & SerialSignal_RTS ) {
			info->serial_signals &= ~SerialSignal_RTS;
			scc_set_serial_signals( info );
		}
		info->drop_rts_on_tx_done = 0;
	}

	if ( status & TXSTATUS_EOF_SENT )
		info->icount.txok++;
	else if ( status & TXSTATUS_UNDERRUN )
		info->icount.txunder++;
	else if ( status & TXSTATUS_ABORT_SENT )
		info->icount.txabort++;
	else
		info->icount.txunder++;

#ifdef CONFIG_HDLC
	if (info->netcount)
		hdlcdev_tx_done(info);
	else
#endif
	{
		if (info->tty->stopped || info->tty->hw_stopped) {
			scc_stop_transmitter(info);
			return;
		}
		info->pending_bh |= BH_TRANSMIT;
	}
}

/*
 *
 * void scc_serial_signals_change()
 *
 * handle a change in the input serial signals
 *
 * Arguments:		info		pointer to device instance data
 * Return Value:	None
 */
void scc_serial_signals_change(struct mgscc_struct *info)
{
	struct	mgsl_icount *icount = &info->icount;
	unsigned char delta = info->last_serial_signals ^ info->serial_signals;
	unsigned char status = info->serial_signals;

	if ( debug_level >= DEBUG_LEVEL_ISR )
		printk("%s(%d):scc_serial_signals_change last=%02x, current=%02X, changed=%02x\n",
			__FILE__,__LINE__,
			info->last_serial_signals,
			info->serial_signals,
			delta);

	info->last_serial_signals = info->serial_signals;

	if ( delta & ~(SerialSignal_DTR|SerialSignal_RTS) ) {
		/* update input line counters */
		if (delta & SerialSignal_RI ) {
			if ((info->ri_chkcount)++ >= IO_PIN_SHUTDOWN_LIMIT) {
				info->wr15a_value &= ~BIT5;
				scc_OutRegA( info, WR15, info->wr15a_value );
			}
			icount->rng++;
			if ( status & SerialSignal_RI )
				info->input_signal_events.ri_up++;
			else
				info->input_signal_events.ri_down++;
		}
		if (delta & SerialSignal_DSR) {
			if ((info->dsr_chkcount)++ >= IO_PIN_SHUTDOWN_LIMIT) {
				info->wr15a_value &= ~BIT3;
				scc_OutRegA( info, WR15, info->wr15a_value );
			}
			icount->dsr++;
			if ( status & SerialSignal_DSR)
				info->input_signal_events.dsr_up++;
			else
				info->input_signal_events.dsr_down++;
		}
		if (delta & SerialSignal_DCD) {
			if ((info->dcd_chkcount)++ >= IO_PIN_SHUTDOWN_LIMIT) {
				info->wr15b_value &= ~BIT3;
				scc_OutRegB( info, WR15, info->wr15b_value );
			}
			icount->dcd++;
			if (status & SerialSignal_DCD) {
				info->input_signal_events.dcd_up++;
			} else
				info->input_signal_events.dcd_down++;
#ifdef CONFIG_HDLC	
			if (info->netcount)
				hdlc_set_carrier(status & SerialSignal_DCD, info->netdev);
#endif
		}
		if (delta & SerialSignal_CTS)
		{
			if ((info->cts_chkcount)++ >= IO_PIN_SHUTDOWN_LIMIT) {
				info->wr15b_value &= ~BIT5;
				scc_OutRegB( info, WR15, info->wr15b_value );
			}
			icount->cts++;
			if ( status & SerialSignal_CTS )
				info->input_signal_events.cts_up++;
			else {
				info->input_signal_events.cts_down++;

				if ( info->tx_active ) {
					/* CTS failure during transmit. */
					info->cts_failure = 1;
					tx_frame_complete(info, TXSTATUS_UNDERRUN);
				}
			}
		}
		wake_up_interruptible(&info->status_event_wait_q);
		wake_up_interruptible(&info->event_wait_q);

		if ( (info->flags & ASYNC_CHECK_CD) &&
		     (delta & SerialSignal_DCD) ) {
			if ( debug_level >= DEBUG_LEVEL_ISR )
				printk("%s CD now %s...", info->device_name,
				       (status & SerialSignal_DCD) ? "on" : "off");
			if (status & SerialSignal_DCD)
				wake_up_interruptible(&info->open_wait);
			else {
				if ( debug_level >= DEBUG_LEVEL_ISR )
					printk("doing serial hangup...");
				if (info->tty)
					tty_hangup(info->tty);
			}
		}

		if ( (info->flags & ASYNC_CTS_FLOW) &&
		     (delta & SerialSignal_CTS) ) {
			if (info->tty->hw_stopped) {
				if (status & SerialSignal_CTS) {
					if ( debug_level >= DEBUG_LEVEL_ISR )
						printk("CTS tx start...");
					if (info->tty)
						info->tty->hw_stopped = 0;
					scc_start_transmitter(info);
					info->pending_bh |= BH_TRANSMIT;
					return;
				}
			} else {
				if (!(status & SerialSignal_CTS)) {
					if ( debug_level >= DEBUG_LEVEL_ISR )
						printk("CTS tx stop...");
					if (info->tty)
						info->tty->hw_stopped = 1;
					scc_stop_transmitter(info);
				}
			}
		}
	}

	info->pending_bh |= BH_STATUS;
}

/*
 *
 * static void IsrTransmitB()
 *
 * service transmit buffer empty interrupt on channel B.
 *
 * Arguments:		info		pointer to device instance data
 * Return Value:	None
 */
static void IsrTransmitB(struct mgscc_struct *info)
{
	if (info->params.mode == MGSL_MODE_HDLC ) {
		BUFFERENTRY * pTxBuffer = &info->tx_buffer_list[info->current_tx_buffer];

		if ( debug_level >= DEBUG_LEVEL_ISR )
			printk("%s(%d):mgscc_isr_transmit_data tx frame count=%d\n",
				__FILE__,__LINE__,pTxBuffer->count);

		if ( pTxBuffer->count ) {
			/* load another HDLC byte */
			scc_load_tx_reg(info);

			if ( pTxBuffer->count == 0 ) {
				/*
				 * just loaded last byte of frame,
				 * set SCC to interrupt on tx fifo empty,
				 * and reset WR10:2 in order to send CRC+Flag
				 * on underrun
				 */
				scc_enable_txfifo_empty(info,1);
				info->wr10b_value &= ~BIT2;
				scc_OutRegB(info,WR10,info->wr10b_value);
			}
		}
		else {
			/* all hdlc data sent, reset TxInt pending */
			outb(0x28, info->ctrl_b);

			if ( info->params.crc_type == HDLC_CRC_NONE ||
				info->waiting_on_tx_crc ) {
				tx_frame_complete( info, TXSTATUS_EOF_SENT );
			}
			else {
				if ( scc_InRegA(info,RR3) & BIT0 ) {
					/*
					 * External/Status interrupt on channel B is pending,
					 * check for TxUnder/EOM which will set waiting_on_tx_crc.
					 * Do this in case long IRQ latency allows 2nd TxEmpty
					 * IRQ to occur before servicing TxUnder/EOM (which
					 * has lower priority)
					 */
					IsrStatusB(info);
				}
			}
		}
	}
	else {
		if ( debug_level >= DEBUG_LEVEL_ISR )
			printk("%s(%d):mgscc_isr_transmit_data xmit_cnt=%d\n",
				__FILE__,__LINE__,info->xmit_cnt);

		if (info->tty->stopped || info->tty->hw_stopped) {
			scc_stop_transmitter(info);
			return;
		}

		if ( info->xmit_cnt )
			scc_load_tx_reg(info);
		else {
			info->tx_active = 0;
			/* all data sent, reset TxInt pending */
			outb(0x28, info->ctrl_b);
		}

		if (info->xmit_cnt < WAKEUP_CHARS)
			info->pending_bh |= BH_TRANSMIT;
	}
}

/*
 *
 * static void IsrStatusB()
 *
 * service external/status interrupt on channel B.
 *
 * Arguments:		info		pointer to device instance data
 * Return Value:	None
 */
static void IsrStatusB(struct mgscc_struct *info)
{
	struct tty_struct *tty;
	BUFFERENTRY *pBufEntry;
	unsigned char rr0b = inb(info->ctrl_b);
	scc_get_serial_signals(info);

	/* issue reset Ext/Status IRQ command and unlatch bits in RR0 */
	outb(0x10,info->ctrl_b);

	if ( debug_level >= DEBUG_LEVEL_ISR )
		printk("%s(%d):IsrStatusB, RR0B=%x\n",
			__FILE__,__LINE__,rr0b);

	/* for diagnostics, set IRQ flag on ZeroCount condition */
	if ( info->diagnostics_mode  ) /* && (rr0b & BIT1) ) */ {
		scc_OutRegB(info,WR9,0xc0);
		info->irq_occurred = 1;
		return;
	}

	if (info->params.mode == MGSL_MODE_HDLC ) {
		if ( rr0b & BIT7 ) {
			/* Abort detected, flush rx fifo, and clean up */
			while( inb(info->ctrl_b) & BIT0 )
				inb(info->data_b);

			pBufEntry = &info->rx_buffer_list[info->scc_rx_buffer];

			if (!pBufEntry->rcc) {
				/* rx frame not in progress */
				++info->icount.rxabort;
			}
			else
				rx_frame_complete( info, RXSTATUS_ABORT );
		}

		if ( (info->wr15b_value & BIT6) && (rr0b & BIT6)) {

			/* Tx Underrun/EOM */
			pBufEntry = &(info->tx_buffer_list[info->current_tx_buffer]);

			if (info->abort_requested)
				tx_frame_complete(info, TXSTATUS_ABORT_SENT);
			else if (pBufEntry->count != 0)
				tx_frame_complete(info, TXSTATUS_UNDERRUN);
			else
				info->waiting_on_tx_crc = TRUE;
		}
	}
	else {
		if ( rr0b & BIT7 ) {
			info->break_detected=1;
		}
		else if ( info->break_detected ) {
			unsigned char DataByte;
			tty = info->tty;
			info->break_detected = 0;

			/* Break received */
			info->icount.brk++;
			DataByte = inb(info->data_b);

			if (tty->flip.count < TTY_FLIPBUF_SIZE) {
				*tty->flip.char_buf_ptr = DataByte;
				info->icount.rx++;
				*tty->flip.flag_buf_ptr = 0;

				if ( !(info->ignore_status_mask & RXSTATUS_BREAK_RECEIVED)) {
					if ( info->read_status_mask & RXSTATUS_BREAK_RECEIVED ) {
						*tty->flip.flag_buf_ptr = TTY_BREAK;
						if (info->flags & ASYNC_SAK)
							do_SAK(tty);
					}
				}

				tty->flip.flag_buf_ptr++;
				tty->flip.char_buf_ptr++;
				tty->flip.count++;

				if ( tty->flip.count )
					tty_flip_buffer_push(tty);

			}

			if ( debug_level >= DEBUG_LEVEL_ISR ) {
				printk("%s(%d):IsrStatusB flip count=%d\n",
					__FILE__,__LINE__,tty->flip.count);
				printk("%s(%d):rx=%d brk=%d\n",
					__FILE__,__LINE__,
					info->icount.rx,
					info->icount.brk);
			}
		}
	}

	if ( info->serial_signals != info->last_serial_signals )
		scc_serial_signals_change(info);

}

/*
 *
 * static void IsrReceiveB()
 *
 * service receive char available interrupt on channel B
 *
 * Arguments:		info		pointer to device instance data
 * Return Value:	None
 */
static void IsrReceiveB(struct mgscc_struct *info)
{
	unsigned char rr1;
	unsigned char DataByte;
	u16 status = 0;
	struct tty_struct *tty = info->tty;
	struct	mgsl_icount *icount = &info->icount;

	if ( debug_level >= DEBUG_LEVEL_ISR )
		printk("%s(%d):IsrReceiveB\n",
			__FILE__,__LINE__);

	if (info->params.mode == MGSL_MODE_HDLC ) {

		PBUFFERENTRY pRxBuffer = &(info->rx_buffer_list[info->scc_rx_buffer]);

		/* flush the receive FIFO */
		while( inb(info->ctrl_b) & BIT0 ) {
			rr1 = scc_InRegB(info,RR1);
			outb(0x30,info->ctrl_b);  /* reset Rx special condition */
			DataByte = inb(info->data_b);

			*pRxBuffer->put++ = DataByte;
			++pRxBuffer->rcc;
			icount->rx++;

			/*
			 * check to see if Rx Fifo Overflow occurred or
			 * we hit max frame size
			 */
			if ( rr1&BIT5 ||
			     pRxBuffer->rcc >  info->scc_rx_databuffer_size ) {
				info->wr3b_value |= BIT4;  /* enter hunt mode */
				scc_OutRegB(info, WR3, info->wr3b_value);

				/* flush SCC receive FIFO */
				while( inb(info->ctrl_b) & BIT0 )
					inb(info->data_b);

				rx_frame_complete(info,RXSTATUS_OVERRUN);
				break;
			}

			if ( rr1 & BIT7 ) {
				status = RXSTATUS_RXBOUND;
				if (rr1 & BIT6)
					status |= RXSTATUS_CRC_ERROR;
				rx_frame_complete(info,status);
			}

			/*
			 * tweak: exit receive data handler if Tx or
			 * Ext/Status interrupt pending
			 */
			if ( scc_InRegA(info, RR3) & (BIT2|BIT0) )
				break;
		}
	}
	else {
		/* flush the receive FIFO */
		while( inb(info->ctrl_b) & BIT0 ) {
			rr1 = scc_InRegB(info,RR1);
			outb(0x30,info->ctrl_b);  /* reset Rx special condition */
			DataByte = inb(info->data_b);

			if (tty->flip.count >= TTY_FLIPBUF_SIZE)
				continue;

			*tty->flip.char_buf_ptr = DataByte;
			icount->rx++;

			*tty->flip.flag_buf_ptr = 0;
			if ( rr1 & (BIT6|BIT5|BIT4) ) {
				if ( debug_level >= DEBUG_LEVEL_ISR )
					printk("%s(%d):IsrReceiveB rxerr, RR1B=%02X\n",
							__FILE__,__LINE__,rr1);
				status = 0;
				if ( BIT6 )
					status |= RXSTATUS_FRAMING_ERROR;
				if ( BIT5 )
					status |= RXSTATUS_OVERRUN;
				if ( BIT4 )
					status |= RXSTATUS_PARITY_ERROR;

				/* update error statistics */
				if (status & RXSTATUS_PARITY_ERROR)
					icount->parity++;
				else if (status & RXSTATUS_FRAMING_ERROR)
					icount->frame++;
				else if (status & RXSTATUS_OVERRUN )
					icount->overrun++;

				/* discard char if tty control flags say so */
				if (status & info->ignore_status_mask)
					continue;

				status &= info->read_status_mask;

				if (status & RXSTATUS_PARITY_ERROR)
					*tty->flip.flag_buf_ptr = TTY_PARITY;
				else if (status & RXSTATUS_FRAMING_ERROR)
					*tty->flip.flag_buf_ptr = TTY_FRAME;
				if (status & RXSTATUS_OVERRUN) {
					/* Overrun is special, since it's
					* reported immediately, and doesn't
					* affect the current character
					*/
					if (tty->flip.count < TTY_FLIPBUF_SIZE) {
						tty->flip.count++;
						tty->flip.flag_buf_ptr++;
						tty->flip.char_buf_ptr++;
						*tty->flip.flag_buf_ptr = TTY_OVERRUN;
					}
				}
			}	/* end of if (error) */

			tty->flip.flag_buf_ptr++;
			tty->flip.char_buf_ptr++;
			tty->flip.count++;
		}

		if ( debug_level >= DEBUG_LEVEL_ISR ) {
			printk("%s(%d):IsrReceiveB flip count=%d\n",
				__FILE__,__LINE__,tty->flip.count);
			printk("%s(%d):rx=%d parity=%d frame=%d overrun=%d\n",
				__FILE__,__LINE__,icount->rx,
				icount->parity,icount->frame,icount->overrun);
		}

		if ( tty->flip.count )
			tty_flip_buffer_push(tty);
	}
}

/*
 *
 * static void IsrTransmitA()
 *
 * service transmit buffer empty interrupt on channel A.
 * Channel is not used so this should never be dipatched
 *
 * Arguments:		info		pointer to device instance data
 * Return Value:	None
 */
static void IsrTransmitA(struct mgscc_struct *info)
{
	if ( debug_level >= DEBUG_LEVEL_ISR )
		printk("%s(%d):IsrTransmitA\n",
			__FILE__,__LINE__);

	/* reset TxInt pending */
	outb(0x28, info->ctrl_a);
}

/*
 *
 * static void IsrStatusA()
 *
 * service external/status interrupt on channel A.
 * This should be a change in DSR/RI serial signals
 *
 * Arguments:		info		pointer to device instance data
 * Return Value:	None
 */
static void IsrStatusA(struct mgscc_struct *info)
{
	if ( debug_level >= DEBUG_LEVEL_ISR )
		printk("%s(%d):IsrStatusA, RR0A=%x\n",
			__FILE__,__LINE__, inb(info->ctrl_a));

	scc_get_serial_signals(info);

	/* issue reset Ext/Status IRQ command */
	outb(0x10, info->ctrl_a);

	if ( info->serial_signals != info->last_serial_signals )
		scc_serial_signals_change(info);
}

/*
 *
 * static void IsrReceiveA()
 *
 * service receive char available interrupt on channel A.
 * Channel is not used so this should never be dipatched
 *
 * Arguments:		info		pointer to device instance data
 * Return Value:	None
 */
static void IsrReceiveA(struct mgscc_struct *info)
{
	/* read a byte of receive data from the SCC */
	unsigned char ch = inb(info->data_a);

	if ( debug_level >= DEBUG_LEVEL_ISR )
		printk("%s(%d):IsrReceiveA, DataA=%x\n",
			__FILE__,__LINE__, ch );

}

/*
 *
 * static void IsrSpecialA()
 *
 * service special receive condition interrupt on channel A.
 * Channel is not used so this should never be dipatched
 *
 * Arguments:		info		pointer to device instance data
 * Return Value:	None
 */
static void IsrSpecialA(struct mgscc_struct *info)
{
	/* read a byte of receive data from the SCC */
	unsigned char rr1 = scc_InRegA( info, RR1 );

	if ( debug_level >= DEBUG_LEVEL_ISR )
		printk("%s(%d):IsrSpecialA, RR1A=%x\n",
			__FILE__,__LINE__, rr1);

	/* reset Rx special condition */
	outb(0x30, info->ctrl_a);
}


/* mgscc_interrupt()
 *
 *	Interrupt service routine entry point.
 *
 * Arguments:
 *
 *	irq		interrupt number that caused interrupt
 *	dev_id		device ID supplied during interrupt registration
 *	regs		interrupted processor context
 *
 * Return Value: None
 */
static irqreturn_t mgscc_interrupt(int irq, void *dev_id, struct pt_regs * regs)
{
	struct mgscc_struct * info;
	unsigned char rr3a;

	if ( debug_level >= DEBUG_LEVEL_ISR )
		printk("%s(%d):mgscc_interrupt(%d)entry.\n",
			__FILE__,__LINE__,irq);

	info = (struct mgscc_struct *)dev_id;
	if (!info)
		return IRQ_NONE;

	spin_lock(&info->irq_spinlock);

	for(;;) {
		/* Read the interrupt vectors from hardware. */
		rr3a = scc_InRegA( info, RR3 );
		if ( debug_level >= DEBUG_LEVEL_ISR )
			printk("%s(%d):%s RR3A=%02X\n",
				__FILE__,__LINE__,info->device_name,rr3a);

		if ( !rr3a )
			break;
		/*
		 * External/Status interrupts on Channel B has the lowest
		 * priority, yet reports underrun/abort conditions,
		 * handle it first
		 */
		if ( rr3a & BIT0 )
			IsrStatusB(info);
		else if ( rr3a & BIT1 )
			IsrTransmitB(info);
		else
			(*IsrTable[((0x0e & scc_InRegB( info, RR2 )) >> 1)])(info);
	}

	/* Request bottom half processing if there's something
	 * for it to do and the bh is not already running
	 */
	if ( info->pending_bh && !info->bh_running && !info->bh_requested ) {
		if ( debug_level >= DEBUG_LEVEL_ISR )
			printk("%s(%d):%s queueing bh task.\n",
				__FILE__,__LINE__,info->device_name);
		schedule_work(&info->task);
		info->bh_requested = 1;
	}

	spin_unlock(&info->irq_spinlock);

	if ( debug_level >= DEBUG_LEVEL_ISR )
		printk("%s(%d):mgscc_interrupt(%d)exit.\n",
			__FILE__,__LINE__,irq);

	return IRQ_HANDLED;

}	/* end of mgscc_interrupt() */

/* startup()
 *
 *	Initialize and start device.
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:	0 if success, otherwise error code
 */
static int startup(struct mgscc_struct * info)
{
	if ( debug_level >= DEBUG_LEVEL_INFO )
		printk("%s(%d):mgscc_startup(%s)\n",__FILE__,__LINE__,info->device_name);

	if (info->flags & ASYNC_INITIALIZED)
		return 0;

	if (!info->xmit_buf) {
		/* allocate a page of memory for a transmit buffer */
		info->xmit_buf = (unsigned char *)get_zeroed_page(GFP_KERNEL);
		if (!info->xmit_buf) {
			printk(KERN_ERR"%s(%d):%s can't allocate transmit buffer\n",
				__FILE__,__LINE__,info->device_name);
			return -ENOMEM;
		}
	}

	info->pending_bh = 0;

	memset(&info->icount, 0, sizeof(info->icount));

	/* program hardware for current parameters */
	mgscc_change_params(info);

	if (info->tty)
		clear_bit(TTY_IO_ERROR, &info->tty->flags);

	info->flags |= ASYNC_INITIALIZED;

	return 0;

}	/* end of startup() */

/* shutdown()
 *
 * Called by mgscc_close() and mgscc_hangup() to shutdown hardware
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:	None
 */
static void shutdown(struct mgscc_struct * info)
{
	unsigned long flags;

	if (!(info->flags & ASYNC_INITIALIZED))
		return;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_shutdown(%s)\n",
			 __FILE__,__LINE__, info->device_name );

	/* clear status wait queue because status changes */
	/* can't happen after shutting down the hardware */
	wake_up_interruptible(&info->status_event_wait_q);
	wake_up_interruptible(&info->event_wait_q);

	del_timer(&info->tx_timer);

	if (info->xmit_buf) {
		free_page((unsigned long) info->xmit_buf);
		info->xmit_buf = 0;
	}

	spin_lock_irqsave(&info->irq_spinlock,flags);
	scc_DisableMasterIrqBit(info);
	scc_stop_receiver(info);
	scc_stop_transmitter(info);

	/* reset all interrupt enables */
	info->wr1b_value = 0;
	scc_OutRegB(info,WR1,info->wr1b_value);

	if (!info->tty || info->tty->termios->c_cflag & HUPCL) {
		info->serial_signals &= ~(SerialSignal_DTR + SerialSignal_RTS);
		scc_set_serial_signals(info);
	}

	spin_unlock_irqrestore(&info->irq_spinlock,flags);

	if (info->tty)
		set_bit(TTY_IO_ERROR, &info->tty->flags);

	info->flags &= ~ASYNC_INITIALIZED;

}	/* end of shutdown() */

static void mgscc_program_hw(struct mgscc_struct *info)
{
	unsigned long flags;

	spin_lock_irqsave(&info->irq_spinlock,flags);

	scc_stop_receiver(info);
	scc_stop_transmitter(info);
	info->xmit_cnt = info->xmit_head = info->xmit_tail = 0;

	if (info->params.mode == MGSL_MODE_HDLC || info->netcount)
		scc_set_sync_mode(info);
	else
		scc_set_async_mode(info);

	scc_set_serial_signals(info);

	info->dcd_chkcount = 0;
	info->cts_chkcount = 0;
	info->ri_chkcount = 0;
	info->dsr_chkcount = 0;

	/*
	 * enable serial signal status interrupts
	 *	CTS/B is CTS, DCD/B is DCD
	 *	CTS/A is RI,  DCD/A is DSR
	 */
	info->wr15b_value |= (BIT3|BIT5);
	scc_OutRegB(info,WR15,info->wr15b_value);

	info->wr15a_value |= (BIT3|BIT5);
	scc_OutRegA(info,WR15,info->wr15a_value);

	info->wr1b_value |= BIT0;
	scc_OutRegB(info,WR1,info->wr1b_value);

	info->wr1a_value |= BIT0;
	scc_OutRegA(info,WR1,info->wr1a_value);

	scc_get_serial_signals(info);

	if (info->netcount || info->tty->termios->c_cflag & CREAD)
		scc_start_receiver(info);

	spin_unlock_irqrestore(&info->irq_spinlock,flags);
}

/* Reconfigure adapter based on new parameters
 */
static void mgscc_change_params(struct mgscc_struct *info)
{
	unsigned cflag;
	int bits_per_char;

	if (!info->tty || !info->tty->termios)
		return;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_change_params(%s)\n",
			 __FILE__,__LINE__, info->device_name );

	cflag = info->tty->termios->c_cflag;

	/* if B0 rate (hangup) specified then negate DTR and RTS */
	/* otherwise assert DTR and RTS */
	if (cflag & CBAUD)
		info->serial_signals |= SerialSignal_RTS + SerialSignal_DTR;
	else
		info->serial_signals &= ~(SerialSignal_RTS + SerialSignal_DTR);

	/* byte size and parity */

	switch (cflag & CSIZE) {
	      case CS5: info->params.data_bits = 5; break;
	      case CS6: info->params.data_bits = 6; break;
	      case CS7: info->params.data_bits = 7; break;
	      case CS8: info->params.data_bits = 8; break;
	      /* Never happens, but GCC is too dumb to figure it out */
	      default:	info->params.data_bits = 7; break;
	      }

	if (cflag & CSTOPB)
		info->params.stop_bits = 2;
	else
		info->params.stop_bits = 1;

	info->params.parity = ASYNC_PARITY_NONE;
	if (cflag & PARENB) {
		if (cflag & PARODD)
			info->params.parity = ASYNC_PARITY_ODD;
		else
			info->params.parity = ASYNC_PARITY_EVEN;
#ifdef CMSPAR
		if (cflag & CMSPAR)
			info->params.parity = ASYNC_PARITY_SPACE;
#endif
	}

	/* calculate number of jiffies to transmit a full
	 * FIFO (32 bytes) at specified data rate
	 */
	bits_per_char = info->params.data_bits +
			info->params.stop_bits + 1;

/* TODO: determine what is relevant about 460800 baud */

	/* if port data rate is set to 460800 or less then
	 * allow tty settings to override, otherwise keep the
	 * current data rate.
	 */
	if (info->params.data_rate <= 460800)
		info->params.data_rate = tty_get_baud_rate(info->tty);

	if ( info->params.data_rate ) {
		info->timeout = (32*HZ*bits_per_char) /
				info->params.data_rate;
	}
	info->timeout += HZ/50;		/* Add .02 seconds of slop */

	if (cflag & CRTSCTS)
		info->flags |= ASYNC_CTS_FLOW;
	else
		info->flags &= ~ASYNC_CTS_FLOW;

	if (cflag & CLOCAL)
		info->flags &= ~ASYNC_CHECK_CD;
	else
		info->flags |= ASYNC_CHECK_CD;

	/* process tty input control flags */
	info->read_status_mask = RXSTATUS_OVERRUN;
	if (I_INPCK(info->tty))
		info->read_status_mask |= RXSTATUS_PARITY_ERROR | RXSTATUS_FRAMING_ERROR;
	if (I_BRKINT(info->tty) || I_PARMRK(info->tty))
		info->read_status_mask |= RXSTATUS_BREAK_RECEIVED;

	if (I_IGNPAR(info->tty))
		info->ignore_status_mask |= RXSTATUS_PARITY_ERROR | RXSTATUS_FRAMING_ERROR;
	if (I_IGNBRK(info->tty)) {
		info->ignore_status_mask |= RXSTATUS_BREAK_RECEIVED;
		/* If ignoring parity and break indicators, ignore
		 * overruns too.  (For real raw support).
		 */
		if (I_IGNPAR(info->tty))
			info->ignore_status_mask |= RXSTATUS_OVERRUN;
	}

	mgscc_program_hw(info);

}	/* end of mgscc_change_params() */

/* mgscc_put_char()
 *
 *	Add a character to the transmit buffer.
 *
 * Arguments:		tty	pointer to tty information structure
 *			ch	character to add to transmit buffer
 *
 * Return Value:	None
 */
static void mgscc_put_char(struct tty_struct *tty, unsigned char ch)
{
	struct mgscc_struct *info = (struct mgscc_struct *)tty->driver_data;
	unsigned long flags;

	if ( debug_level >= DEBUG_LEVEL_INFO ) {
		printk( "%s(%d):mgscc_put_char(%d) on %s\n",
			__FILE__,__LINE__,ch,info->device_name);
	}

	if (mgscc_paranoia_check(info, tty->name, "mgscc_put_char"))
		return;

	if (!tty || !info->xmit_buf)
		return;

	spin_lock_irqsave(&info->irq_spinlock,flags);

	if ( (info->params.mode != MGSL_MODE_HDLC) ||
	     !info->tx_active ) {

		if (info->xmit_cnt < SERIAL_XMIT_SIZE - 1) {
			info->xmit_buf[info->xmit_head++] = ch;
			info->xmit_head &= SERIAL_XMIT_SIZE-1;
			info->xmit_cnt++;
		}
	}

	spin_unlock_irqrestore(&info->irq_spinlock,flags);

}	/* end of mgscc_put_char() */

/* mgscc_flush_chars()
 *
 *	Enable transmitter so remaining characters in the
 *	transmit buffer are sent.
 *
 * Arguments:		tty	pointer to tty information structure
 * Return Value:	None
 */
static void mgscc_flush_chars(struct tty_struct *tty)
{
	struct mgscc_struct *info = (struct mgscc_struct *)tty->driver_data;
	unsigned long flags;

	if ( debug_level >= DEBUG_LEVEL_INFO )
		printk( "%s(%d):mgscc_flush_chars() entry on %s xmit_cnt=%d\n",
			__FILE__,__LINE__,info->device_name,info->xmit_cnt);

	if (mgscc_paranoia_check(info, tty->name, "mgscc_flush_chars"))
		return;

	if (info->xmit_cnt <= 0 || tty->stopped || tty->hw_stopped ||
	    !info->xmit_buf)
		return;

	if ( debug_level >= DEBUG_LEVEL_INFO )
		printk( "%s(%d):mgscc_flush_chars() entry on %s starting transmitter\n",
			__FILE__,__LINE__,info->device_name );

	spin_lock_irqsave(&info->irq_spinlock,flags);

	if (!info->tx_active) {
		if ( (info->params.mode == MGSL_MODE_HDLC) &&
			info->xmit_cnt ) {
			/* operating in synchronous (frame oriented) mode */
			/* copy data from circular xmit_buf to */
			/* transmit buffer. */
			mgscc_load_tx_buffer(info,info->xmit_buf,info->xmit_cnt);
		}
		scc_start_transmitter(info);
	}

	spin_unlock_irqrestore(&info->irq_spinlock,flags);

}	/* end of mgscc_flush_chars() */

/* mgscc_write()
 *
 *	Send a block of data
 *
 * Arguments:
 *
 *	tty		pointer to tty information structure
 *	buf		pointer to buffer containing send data
 *	count		size of send data in bytes
 *
 * Return Value:	number of characters written
 */
static int mgscc_write(struct tty_struct * tty,
		    const unsigned char *buf, int count)
{
	int	c, ret = 0;
	struct mgscc_struct *info = (struct mgscc_struct *)tty->driver_data;
	unsigned long flags;

	if ( debug_level >= DEBUG_LEVEL_INFO )
		printk( "%s(%d):mgscc_write(%s) count=%d\n",
			__FILE__,__LINE__,info->device_name,count);

	if (mgscc_paranoia_check(info, tty->name, "mgscc_write"))
		goto cleanup;

	if (!tty || !info->xmit_buf || !tmp_buf)
		goto cleanup;

	if ( info->params.mode == MGSL_MODE_HDLC ) {
		/* operating in synchronous (frame oriented) mode */

		if (info->tx_active) {
			ret = 0; goto cleanup;
		}

		if ( info->xmit_cnt ) {
			/* Send accumulated from send_char() calls */
			/* as frame and wait before accepting more data. */
			ret = 0;

			/* copy data from circular xmit_buf to */
			/* transmit buffer. */
			mgscc_load_tx_buffer(info,info->xmit_buf,info->xmit_cnt);
			if ( debug_level >= DEBUG_LEVEL_INFO )
				printk( "%s(%d):mgscc_write(%s) sync xmit_cnt flushing\n",
					__FILE__,__LINE__,info->device_name);
		} else {
			if ( debug_level >= DEBUG_LEVEL_INFO )
				printk( "%s(%d):mgscc_write(%s) sync transmit accepted\n",
					__FILE__,__LINE__,info->device_name);
			ret = count;
			info->xmit_cnt = count;
			mgscc_load_tx_buffer(info,buf,count);
		}
	} else {
		while (1) {
			spin_lock_irqsave(&info->irq_spinlock,flags);
			c = MIN(count,
				MIN(SERIAL_XMIT_SIZE - info->xmit_cnt - 1,
				    SERIAL_XMIT_SIZE - info->xmit_head));
			if (c <= 0) {
				spin_unlock_irqrestore(&info->irq_spinlock,flags);
				break;
			}
			memcpy(info->xmit_buf + info->xmit_head, buf, c);
			info->xmit_head = ((info->xmit_head + c) &
					   (SERIAL_XMIT_SIZE-1));
			info->xmit_cnt += c;
			spin_unlock_irqrestore(&info->irq_spinlock,flags);
			buf += c;
			count -= c;
			ret += c;
		}
	}

	if (info->xmit_cnt && !tty->stopped && !tty->hw_stopped) {
		spin_lock_irqsave(&info->irq_spinlock,flags);
		if (!info->tx_active)
			scc_start_transmitter(info);
		spin_unlock_irqrestore(&info->irq_spinlock,flags);
	}
cleanup:
	if ( debug_level >= DEBUG_LEVEL_INFO )
		printk( "%s(%d):mgscc_write(%s) returning=%d\n",
			__FILE__,__LINE__,info->device_name,ret);

	return ret;

}	/* end of mgscc_write() */

/* mgscc_write_room()
 *
 *	Return the count of free bytes in transmit buffer
 *
 * Arguments:		tty	pointer to tty info structure
 * Return Value:	None
 */
static int mgscc_write_room(struct tty_struct *tty)
{
	struct mgscc_struct *info = (struct mgscc_struct *)tty->driver_data;
	int	ret;

	if (mgscc_paranoia_check(info, tty->name, "mgscc_write_room"))
		return 0;
	ret = SERIAL_XMIT_SIZE - info->xmit_cnt - 1;
	if (ret < 0)
		ret = 0;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_write_room(%s)=%d\n",
			 __FILE__,__LINE__, info->device_name,ret );

	if ( info->params.mode == MGSL_MODE_HDLC ) {
		/* operating in synchronous (frame oriented) mode */
		if ( info->tx_active )
			return 0;
		else
			return HDLC_MAX_FRAME_SIZE;
	}

	return ret;

}	/* end of mgscc_write_room() */

/* mgscc_chars_in_buffer()
 *
 *	Return the count of bytes in transmit buffer
 *
 * Arguments:		tty	pointer to tty info structure
 * Return Value:	None
 */
static int mgscc_chars_in_buffer(struct tty_struct *tty)
{
	struct mgscc_struct *info = (struct mgscc_struct *)tty->driver_data;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_chars_in_buffer(%s)\n",
			 __FILE__,__LINE__, info->device_name );

	if (mgscc_paranoia_check(info, tty->name, "mgscc_chars_in_buffer"))
		return 0;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_chars_in_buffer(%s)=%d\n",
			 __FILE__,__LINE__, info->device_name,info->xmit_cnt );

	if ( info->params.mode == MGSL_MODE_HDLC ) {
		/* operating in synchronous (frame oriented) mode */
		if ( info->tx_active )
			return info->tx_buffer_list[0].count;
		else
			return 0;
	}

	return info->xmit_cnt;
}	/* end of mgscc_chars_in_buffer() */

/* mgscc_flush_buffer()
 *
 *	Discard all data in the send buffer
 *
 * Arguments:		tty	pointer to tty info structure
 * Return Value:	None
 */
static void mgscc_flush_buffer(struct tty_struct *tty)
{
	struct mgscc_struct *info = (struct mgscc_struct *)tty->driver_data;
	unsigned long flags;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_flush_buffer(%s) entry\n",
			 __FILE__,__LINE__, info->device_name );

	if (mgscc_paranoia_check(info, tty->name, "mgscc_flush_buffer"))
		return;

	spin_lock_irqsave(&info->irq_spinlock,flags);
	info->xmit_cnt = info->xmit_head = info->xmit_tail = 0;
	del_timer(&info->tx_timer);
	spin_unlock_irqrestore(&info->irq_spinlock,flags);

	wake_up_interruptible(&tty->write_wait);
	tty_wakeup(tty);
}

/* mgscc_send_xchar()
 *
 *	Send a high-priority XON/XOFF character
 *
 * Arguments:		tty	pointer to tty info structure
 *			ch	character to send
 * Return Value:	None
 */
static void mgscc_send_xchar(struct tty_struct *tty, char ch)
{
	struct mgscc_struct *info = (struct mgscc_struct *)tty->driver_data;
	unsigned long flags;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_send_xchar(%s,%d)\n",
			 __FILE__,__LINE__, info->device_name, ch );

	if (mgscc_paranoia_check(info, tty->name, "mgscc_send_xchar"))
		return;

	info->x_char = ch;
	if (ch) {
		/* Make sure transmit interrupts are on */
		spin_lock_irqsave(&info->irq_spinlock,flags);
		if (!info->tx_enabled)
			scc_start_transmitter(info);
		spin_unlock_irqrestore(&info->irq_spinlock,flags);
	}
}	/* end of mgscc_send_xchar() */

/* mgscc_throttle()
 *
 *	Signal remote device to throttle send data (our receive data)
 *
 * Arguments:		tty	pointer to tty info structure
 * Return Value:	None
 */
static void mgscc_throttle(struct tty_struct * tty)
{
	struct mgscc_struct *info = (struct mgscc_struct *)tty->driver_data;
	unsigned long flags;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_throttle(%s) entry\n",
			 __FILE__,__LINE__, info->device_name );

	if (mgscc_paranoia_check(info, tty->name, "mgscc_throttle"))
		return;

	if (I_IXOFF(tty))
		mgscc_send_xchar(tty, STOP_CHAR(tty));

	if (tty->termios->c_cflag & CRTSCTS) {
		spin_lock_irqsave(&info->irq_spinlock,flags);
		info->serial_signals &= ~SerialSignal_RTS;
		scc_set_serial_signals(info);
		spin_unlock_irqrestore(&info->irq_spinlock,flags);
	}
}	/* end of mgscc_throttle() */

/* mgscc_unthrottle()
 *
 *	Signal remote device to stop throttling send data (our receive data)
 *
 * Arguments:		tty	pointer to tty info structure
 * Return Value:	None
 */
static void mgscc_unthrottle(struct tty_struct * tty)
{
	struct mgscc_struct *info = (struct mgscc_struct *)tty->driver_data;
	unsigned long flags;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_unthrottle(%s) entry\n",
			 __FILE__,__LINE__, info->device_name );

	if (mgscc_paranoia_check(info, tty->name, "mgscc_unthrottle"))
		return;

	if (I_IXOFF(tty)) {
		if (info->x_char)
			info->x_char = 0;
		else
			mgscc_send_xchar(tty, START_CHAR(tty));
	}

	if (tty->termios->c_cflag & CRTSCTS) {
		spin_lock_irqsave(&info->irq_spinlock,flags);
		info->serial_signals |= SerialSignal_RTS;
		scc_set_serial_signals(info);
		spin_unlock_irqrestore(&info->irq_spinlock,flags);
	}

}	/* end of mgscc_unthrottle() */

/* mgscc_get_stats()
 *
 *	get the current serial parameters information
 *
 * Arguments:	info		pointer to device instance data
 *		user_icount	pointer to buffer to hold returned stats
 *
 * Return Value:	0 if success, otherwise error code
 */
static int mgscc_get_stats(struct mgscc_struct * info, struct mgsl_icount *user_icount)
{
	int err;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_get_stats(%s)\n",
			 __FILE__,__LINE__, info->device_name);

	if (!user_icount) {
		memset(&info->icount, 0, sizeof(info->icount));
	} else {
		COPY_TO_USER(err, user_icount, &info->icount, sizeof(struct mgsl_icount));
		if (err)
			return -EFAULT;
	}

	return 0;

}	/* end of mgscc_get_stats() */

/* mgscc_get_params()
 *
 *	get the current serial parameters information
 *
 * Arguments:	info		pointer to device instance data
 *		user_params	pointer to buffer to hold returned params
 *
 * Return Value:	0 if success, otherwise error code
 */
static int mgscc_get_params(struct mgscc_struct * info, MGSL_PARAMS *user_params)
{
	int err;
	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_get_params(%s)\n",
			 __FILE__,__LINE__, info->device_name);

	COPY_TO_USER(err,user_params, &info->params, sizeof(MGSL_PARAMS));
	if (err) {
		if ( debug_level >= DEBUG_LEVEL_INFO )
			printk( "%s(%d):mgscc_get_params(%s) user buffer copy failed\n",
				__FILE__,__LINE__,info->device_name);
		return -EFAULT;
	}

	return 0;

}	/* end of mgscc_get_params() */

/* mgscc_set_params()
 *
 *	set the serial parameters
 *
 * Arguments:
 *
 *	info		pointer to device instance data
 *	new_params	user buffer containing new serial params
 *
 * Return Value:	0 if success, otherwise error code
 */
static int mgscc_set_params(struct mgscc_struct * info, MGSL_PARAMS *new_params)
{
	unsigned long flags;
	MGSL_PARAMS tmp_params;
	int err;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_set_params %s\n", __FILE__,__LINE__,
			info->device_name );
	COPY_FROM_USER(err,&tmp_params, new_params, sizeof(MGSL_PARAMS));
	if (err) {
		if ( debug_level >= DEBUG_LEVEL_INFO )
			printk( "%s(%d):mgscc_set_params(%s) user buffer copy failed\n",
				__FILE__,__LINE__,info->device_name);
		return -EFAULT;
	}

	spin_lock_irqsave(&info->irq_spinlock,flags);
	memcpy(&info->params,&tmp_params,sizeof(MGSL_PARAMS));
	spin_unlock_irqrestore(&info->irq_spinlock,flags);

	mgscc_change_params(info);

	return 0;

}	/* end of mgscc_set_params() */

/* mgscc_get_txidle()
 *
 *	get the current transmit idle mode
 *
 * Arguments:	info		pointer to device instance data
 *		idle_mode	pointer to buffer to hold returned idle mode
 *
 * Return Value:	0 if success, otherwise error code
 */
static int mgscc_get_txidle(struct mgscc_struct * info, int*idle_mode)
{
	int err;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_get_txidle(%s)=%d\n",
			 __FILE__,__LINE__, info->device_name, info->idle_mode);

	COPY_TO_USER(err,idle_mode, &info->idle_mode, sizeof(int));
	if (err) {
		if ( debug_level >= DEBUG_LEVEL_INFO )
			printk( "%s(%d):mgscc_get_txidle(%s) user buffer copy failed\n",
				__FILE__,__LINE__,info->device_name);
		return -EFAULT;
	}

	return 0;

}	/* end of mgscc_get_txidle() */

/* mgscc_set_txidle()	service ioctl to set transmit idle mode
 *
 * Arguments:		info		pointer to device instance data
 *			idle_mode	new idle mode
 *
 * Return Value:	0 if success, otherwise error code
 */
static int mgscc_set_txidle(struct mgscc_struct * info, int idle_mode)
{
	unsigned long flags;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_set_txidle(%s,%d)\n", __FILE__,__LINE__,
			info->device_name, idle_mode );

	spin_lock_irqsave(&info->irq_spinlock,flags);
	info->idle_mode = idle_mode;
	scc_set_txidle( info );
	spin_unlock_irqrestore(&info->irq_spinlock,flags);
	return 0;

}	/* end of mgscc_set_txidle() */

/* mgscc_txenable()
 *
 *	enable or disable the transmitter
 *
 * Arguments:
 *
 *	info		pointer to device instance data
 *	enable		1 = enable, 0 = disable
 *
 * Return Value:	0 if success, otherwise error code
 */
static int mgscc_txenable(struct mgscc_struct * info, int enable)
{
	unsigned long flags;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_txenable(%s,%d)\n", __FILE__,__LINE__,
			info->device_name, enable);

	spin_lock_irqsave(&info->irq_spinlock,flags);
	if ( enable ) {
		if ( !info->tx_enabled ) {
			scc_start_transmitter(info);
		}
	} else {
		if ( info->tx_enabled )
			scc_stop_transmitter(info);
	}
	spin_unlock_irqrestore(&info->irq_spinlock,flags);
	return 0;

}	/* end of mgscc_txenable() */

/* mgscc_txabort()	abort send HDLC frame
 *
 * Arguments:		info		pointer to device instance data
 * Return Value:	0 if success, otherwise error code
 */
static int mgscc_txabort(struct mgscc_struct * info)
{
	unsigned long flags;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_txabort(%s)\n", __FILE__,__LINE__,
			info->device_name);

	spin_lock_irqsave(&info->irq_spinlock,flags);
	if ( info->tx_active && info->params.mode == MGSL_MODE_HDLC ) {
		info->abort_requested = 1;
		info->tx_buffer_list[info->current_tx_buffer].count = 0;

		info->wr10b_value |= BIT2;	/* abort on underrun */
		scc_OutRegB( info, WR10, info->wr10b_value );
	}
	spin_unlock_irqrestore(&info->irq_spinlock,flags);
	return 0;

}	/* end of mgscc_txabort() */

/* mgscc_rxenable()	enable or disable the receiver
 *
 * Arguments:		info		pointer to device instance data
 *			enable		1 = enable, 0 = disable
 * Return Value:	0 if success, otherwise error code
 */
static int mgscc_rxenable(struct mgscc_struct * info, int enable)
{
	unsigned long flags;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_rxenable(%s,%d)\n", __FILE__,__LINE__,
			info->device_name, enable);

	spin_lock_irqsave(&info->irq_spinlock,flags);
	if ( enable ) {
		if ( !info->rx_enabled )
			scc_start_receiver(info);
	} else {
		if ( info->rx_enabled )
			scc_stop_receiver(info);
	}
	spin_unlock_irqrestore(&info->irq_spinlock,flags);
	return 0;

}	/* end of mgscc_rxenable() */

/* mgscc_wait_event()	wait for specified event to occur
 *
 * Arguments:		info	pointer to device instance data
 *			mask	pointer to bitmask of events to wait for
 * Return Value:	0	if successful and bit mask updated with
 *				of events triggerred,
 *			otherwise error code
 */
static int mgscc_wait_event(struct mgscc_struct * info, int * mask_ptr)
{
	unsigned long flags;
	int s;
	int rc=0;
	struct mgsl_icount cprev, cnow;
	int events = 0;
	int mask;
	struct	_input_signal_events oldsigs, newsigs;
	DECLARE_WAITQUEUE(wait, current);

	COPY_FROM_USER(rc,&mask, mask_ptr, sizeof(int));
	if (rc) {
		return	-EFAULT;
	}

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_wait_event(%s,%d)\n", __FILE__,__LINE__,
			info->device_name, mask);

	spin_lock_irqsave(&info->irq_spinlock,flags);

	/* return immediately if state matches requested events */
	scc_get_serial_signals(info);
	s = info->serial_signals;
	events = mask &
		( ((s & SerialSignal_DSR) ? MgslEvent_DsrActive:MgslEvent_DsrInactive) +
 		  ((s & SerialSignal_DCD) ? MgslEvent_DcdActive:MgslEvent_DcdInactive) +
		  ((s & SerialSignal_CTS) ? MgslEvent_CtsActive:MgslEvent_CtsInactive) +
		  ((s & SerialSignal_RI)  ? MgslEvent_RiActive :MgslEvent_RiInactive) );
	if (events) {
		spin_unlock_irqrestore(&info->irq_spinlock,flags);
		goto exit;
	}

	/* save current irq counts */
	cprev = info->icount;
	oldsigs = info->input_signal_events;

	set_current_state(TASK_INTERRUPTIBLE);
	add_wait_queue(&info->event_wait_q, &wait);

	spin_unlock_irqrestore(&info->irq_spinlock,flags);

	for(;;) {
		schedule();
		if (signal_pending(current)) {
			rc = -ERESTARTSYS;
			break;
		}

		/* get current irq counts */
		spin_lock_irqsave(&info->irq_spinlock,flags);
		cnow = info->icount;
		newsigs = info->input_signal_events;
		set_current_state(TASK_INTERRUPTIBLE);
		spin_unlock_irqrestore(&info->irq_spinlock,flags);

		/* if no change, wait aborted for some reason */
		if (newsigs.dsr_up   == oldsigs.dsr_up   &&
		    newsigs.dsr_down == oldsigs.dsr_down &&
		    newsigs.dcd_up   == oldsigs.dcd_up   &&
		    newsigs.dcd_down == oldsigs.dcd_down &&
		    newsigs.cts_up   == oldsigs.cts_up   &&
		    newsigs.cts_down == oldsigs.cts_down &&
		    newsigs.ri_up    == oldsigs.ri_up    &&
		    newsigs.ri_down  == oldsigs.ri_down  &&
		    cnow.exithunt    == cprev.exithunt   &&
		    cnow.rxidle      == cprev.rxidle) {
			rc = -EIO;
			break;
		}

		events = mask &
			( (newsigs.dsr_up   != oldsigs.dsr_up   ? MgslEvent_DsrActive:0)   +
			  (newsigs.dsr_down != oldsigs.dsr_down ? MgslEvent_DsrInactive:0) +
			  (newsigs.dcd_up   != oldsigs.dcd_up   ? MgslEvent_DcdActive:0)   +
			  (newsigs.dcd_down != oldsigs.dcd_down ? MgslEvent_DcdInactive:0) +
			  (newsigs.cts_up   != oldsigs.cts_up   ? MgslEvent_CtsActive:0)   +
			  (newsigs.cts_down != oldsigs.cts_down ? MgslEvent_CtsInactive:0) +
			  (newsigs.ri_up    != oldsigs.ri_up    ? MgslEvent_RiActive:0)    +
			  (newsigs.ri_down  != oldsigs.ri_down  ? MgslEvent_RiInactive:0)  +
			  (cnow.exithunt    != cprev.exithunt   ? MgslEvent_ExitHuntMode:0) +
			  (cnow.rxidle      != cprev.rxidle     ? MgslEvent_IdleReceived:0) );

		if (events)
			break;

		cprev = cnow;
		oldsigs = newsigs;
	}

	remove_wait_queue(&info->event_wait_q, &wait);
	set_current_state(TASK_RUNNING);

exit:
	if ( rc == 0 )
		PUT_USER(rc, events, mask_ptr);

	return rc;

}	/* end of mgscc_wait_event() */

static int modem_input_wait(struct mgscc_struct *info,int arg)
{
 	unsigned long flags;
	int rc;
	struct mgsl_icount cprev, cnow;
	DECLARE_WAITQUEUE(wait, current);

	/* save current irq counts */
	spin_lock_irqsave(&info->irq_spinlock,flags);
	cprev = info->icount;
	add_wait_queue(&info->status_event_wait_q, &wait);
	set_current_state(TASK_INTERRUPTIBLE);
	spin_unlock_irqrestore(&info->irq_spinlock,flags);

	for(;;) {
		schedule();
		if (signal_pending(current)) {
			rc = -ERESTARTSYS;
			break;
		}

		/* get new irq counts */
		spin_lock_irqsave(&info->irq_spinlock,flags);
		cnow = info->icount;
		set_current_state(TASK_INTERRUPTIBLE);
		spin_unlock_irqrestore(&info->irq_spinlock,flags);

		/* if no change, wait aborted for some reason */
		if (cnow.rng == cprev.rng && cnow.dsr == cprev.dsr &&
		    cnow.dcd == cprev.dcd && cnow.cts == cprev.cts) {
			rc = -EIO;
			break;
		}

		/* check for change in caller specified modem input */
		if ((arg & TIOCM_RNG && cnow.rng != cprev.rng) ||
		    (arg & TIOCM_DSR && cnow.dsr != cprev.dsr) ||
		    (arg & TIOCM_CD  && cnow.dcd != cprev.dcd) ||
		    (arg & TIOCM_CTS && cnow.cts != cprev.cts)) {
			rc = 0;
			break;
		}

		cprev = cnow;
	}
	remove_wait_queue(&info->status_event_wait_q, &wait);
	set_current_state(TASK_RUNNING);
	return rc;
}

/* return the state of the serial control and status signals
 */
static int tiocmget(struct tty_struct *tty, struct file *file)
{
	struct mgscc_struct *info = (struct mgscc_struct *)tty->driver_data;
	unsigned int result;
 	unsigned long flags;

	spin_lock_irqsave(&info->irq_spinlock,flags);
 	scc_get_serial_signals(info);
	spin_unlock_irqrestore(&info->irq_spinlock,flags);

	result = ((info->serial_signals & SerialSignal_RTS) ? TIOCM_RTS:0) +
		((info->serial_signals & SerialSignal_DTR) ? TIOCM_DTR:0) +
		((info->serial_signals & SerialSignal_DCD) ? TIOCM_CAR:0) +
		((info->serial_signals & SerialSignal_RI)  ? TIOCM_RNG:0) +
		((info->serial_signals & SerialSignal_DSR) ? TIOCM_DSR:0) +
		((info->serial_signals & SerialSignal_CTS) ? TIOCM_CTS:0);

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):%s tiocmget() value=%08X\n",
			 __FILE__,__LINE__, info->device_name, result );
	return result;
}

/* set modem control signals (DTR/RTS)
 */
static int tiocmset(struct tty_struct *tty, struct file *file,
		    unsigned int set, unsigned int clear)
{
	struct mgscc_struct *info = (struct mgscc_struct *)tty->driver_data;
 	unsigned long flags;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):%s tiocmset(%x,%x)\n",
			__FILE__,__LINE__,info->device_name, set, clear);

	if (set & TIOCM_RTS)
		info->serial_signals |= SerialSignal_RTS;
	if (set & TIOCM_DTR)
		info->serial_signals |= SerialSignal_DTR;
	if (clear & TIOCM_RTS)
		info->serial_signals &= ~SerialSignal_RTS;
	if (clear & TIOCM_DTR)
		info->serial_signals &= ~SerialSignal_DTR;

	spin_lock_irqsave(&info->irq_spinlock,flags);
 	scc_set_serial_signals(info);
	spin_unlock_irqrestore(&info->irq_spinlock,flags);

	return 0;
}


/* mgscc_break()		Set or clear transmit break condition
 *
 * Arguments:		tty		pointer to tty instance data
 *			break_state	-1=set break condition, 0=clear
 * Return Value:	None
 */
static void mgscc_break(struct tty_struct *tty, int break_state)
{
	struct mgscc_struct * info = (struct mgscc_struct *)tty->driver_data;
	unsigned long flags;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_break(%s,%d)\n",
			 __FILE__,__LINE__, info->device_name, break_state);

	if (mgscc_paranoia_check(info, tty->name, "mgscc_break"))
		return;

	spin_lock_irqsave(&info->irq_spinlock,flags);
	if (break_state == -1)
		scc_OutRegB(info,WR5, (info->wr5b_value |= BIT4));
	else
		scc_OutRegB(info,WR5, (info->wr5b_value &= ~BIT4));
	spin_unlock_irqrestore(&info->irq_spinlock,flags);

}	/* end of mgscc_break() */

/* mgscc_ioctl()	Service an IOCTL request
 *
 * Arguments:
 *
 *	tty	pointer to tty instance data
 *	file	pointer to associated file object for device
 *	cmd	IOCTL command code
 *	arg	command argument/context
 *
 * Return Value:	0 if success, otherwise error code
 */
static int mgscc_ioctl(struct tty_struct *tty, struct file * file,
		    unsigned int cmd, unsigned long arg)
{
	struct mgscc_struct * info = (struct mgscc_struct *)tty->driver_data;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_ioctl %s cmd=%08X\n", __FILE__,__LINE__,
			info->device_name, cmd );

	if (mgscc_paranoia_check(info, tty->name, "mgscc_ioctl"))
		return -ENODEV;

	if ((cmd != TIOCGSERIAL) && (cmd != TIOCSSERIAL) &&
	    (cmd != TIOCMIWAIT) && (cmd != TIOCGICOUNT)) {
		if (tty->flags & (1 << TTY_IO_ERROR))
		    return -EIO;
	}

	return mgscc_ioctl_common(info, cmd, arg);
}

int mgscc_ioctl_common(struct mgscc_struct *info, unsigned int cmd, unsigned long arg)
{
	int error;
	struct mgsl_icount cnow;	/* kernel counter temps */
	struct serial_icounter_struct *p_cuser;	/* user space */
	unsigned long flags;

	switch (cmd) {
		case MGSL_IOCGPARAMS:
			return mgscc_get_params(info,(MGSL_PARAMS *)arg);
		case MGSL_IOCSPARAMS:
			return mgscc_set_params(info,(MGSL_PARAMS *)arg);
		case MGSL_IOCGTXIDLE:
			return mgscc_get_txidle(info,(int*)arg);
		case MGSL_IOCSTXIDLE:
			return mgscc_set_txidle(info,(int)arg);
		case MGSL_IOCTXENABLE:
			return mgscc_txenable(info,(int)arg);
		case MGSL_IOCRXENABLE:
			return mgscc_rxenable(info,(int)arg);
		case MGSL_IOCTXABORT:
			return mgscc_txabort(info);
		case MGSL_IOCGSTATS:
			return mgscc_get_stats(info,(struct mgsl_icount*)arg);
		case MGSL_IOCWAITEVENT:
			return mgscc_wait_event(info,(int*)arg);
		/* Wait for modem input (DCD,RI,DSR,CTS) change
		 * as specified by mask in arg (TIOCM_RNG/DSR/CD/CTS)
		 */
		case TIOCMIWAIT:
			return modem_input_wait(info,(int)arg);

		/*
		 * Get counter of input serial line interrupts (DCD,RI,DSR,CTS)
		 * Return: write counters to the user passed counter struct
		 * NB: both 1->0 and 0->1 transitions are counted except for
		 *     RI where only 0->1 is counted.
		 */
		case TIOCGICOUNT:
			spin_lock_irqsave(&info->irq_spinlock,flags);
			cnow = info->icount;
			spin_unlock_irqrestore(&info->irq_spinlock,flags);
			p_cuser = (struct serial_icounter_struct *) arg;
			PUT_USER(error,cnow.cts, &p_cuser->cts);
			if (error) return error;
			PUT_USER(error,cnow.dsr, &p_cuser->dsr);
			if (error) return error;
			PUT_USER(error,cnow.rng, &p_cuser->rng);
			if (error) return error;
			PUT_USER(error,cnow.dcd, &p_cuser->dcd);
			if (error) return error;
			PUT_USER(error,cnow.rx, &p_cuser->rx);
			if (error) return error;
			PUT_USER(error,cnow.tx, &p_cuser->tx);
			if (error) return error;
			PUT_USER(error,cnow.frame, &p_cuser->frame);
			if (error) return error;
			PUT_USER(error,cnow.overrun, &p_cuser->overrun);
			if (error) return error;
			PUT_USER(error,cnow.parity, &p_cuser->parity);
			if (error) return error;
			PUT_USER(error,cnow.brk, &p_cuser->brk);
			if (error) return error;
			PUT_USER(error,cnow.buf_overrun, &p_cuser->buf_overrun);
			if (error) return error;
			return 0;
		default:
			return -ENOIOCTLCMD;
	}
	return 0;
}

/* mgscc_set_termios()
 *
 *	Set new termios settings
 *
 * Arguments:
 *
 *	tty		pointer to tty structure
 *	termios		pointer to buffer to hold returned old termios
 *
 * Return Value:		None
 */
static void mgscc_set_termios(struct tty_struct *tty, struct termios *old_termios)
{
	struct mgscc_struct *info = (struct mgscc_struct *)tty->driver_data;
	unsigned long flags;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_set_termios %s\n", __FILE__,__LINE__,
			tty->driver->name );

	/* just return if nothing has changed */
	if ((tty->termios->c_cflag == old_termios->c_cflag)
	    && (RELEVANT_IFLAG(tty->termios->c_iflag)
		== RELEVANT_IFLAG(old_termios->c_iflag)))
	  return;

	mgscc_change_params(info);

	/* Handle transition to B0 status */
	if (old_termios->c_cflag & CBAUD &&
	    !(tty->termios->c_cflag & CBAUD)) {
		info->serial_signals &= ~(SerialSignal_RTS + SerialSignal_DTR);
		spin_lock_irqsave(&info->irq_spinlock,flags);
		scc_set_serial_signals(info);
		spin_unlock_irqrestore(&info->irq_spinlock,flags);
	}

	/* Handle transition away from B0 status */
	if (!(old_termios->c_cflag & CBAUD) &&
	    tty->termios->c_cflag & CBAUD) {
		info->serial_signals |= SerialSignal_DTR;
		if (!(tty->termios->c_cflag & CRTSCTS) ||
		    !test_bit(TTY_THROTTLED, &tty->flags)) {
			info->serial_signals |= SerialSignal_RTS;
		}
		spin_lock_irqsave(&info->irq_spinlock,flags);
		scc_set_serial_signals(info);
		spin_unlock_irqrestore(&info->irq_spinlock,flags);
	}

	/* Handle turning off CRTSCTS */
	if (old_termios->c_cflag & CRTSCTS &&
	    !(tty->termios->c_cflag & CRTSCTS)) {
		tty->hw_stopped = 0;
		mgscc_start(tty);
	}

}	/* end of mgscc_set_termios() */

/* mgscc_close()
 *
 *	Called when port is closed. Wait for remaining data to be
 *	sent. Disable port and free resources.
 *
 * Arguments:
 *
 *	tty	pointer to open tty structure
 *	filp	pointer to open file object
 *
 * Return Value:	None
 */
static void mgscc_close(struct tty_struct *tty, struct file * filp)
{
	struct mgscc_struct * info = (struct mgscc_struct *)tty->driver_data;

	if (mgscc_paranoia_check(info, tty->name, "mgscc_close"))
		return;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_close(%s) entry, count=%d\n",
			 __FILE__,__LINE__, info->device_name, info->count);

	if (tty_hung_up_p(filp) || !info->count)
		goto cleanup;

	if ((tty->count == 1) && (info->count != 1)) {
		/*
		 * tty->count is 1 and the tty structure will be freed.
		 * info->count should be one in this case.
		 * if it's not, correct it so that the port is shutdown.
		 */
		printk("mgscc_close: bad refcount; tty->count is 1, "
		       "info->count is %d\n", info->count);
		info->count = 1;
	}

	info->count--;

	/* if at least one open remaining, leave hardware active */
	if (info->count)
		goto cleanup;

	info->flags |= ASYNC_CLOSING;

	/* set tty->closing to notify line discipline to
	 * only process XON/XOFF characters. Only the N_TTY
	 * discipline appears to use this (ppp does not).
	 */
	tty->closing = 1;

	/* wait for transmit data to clear all layers */

	if (info->closing_wait != ASYNC_CLOSING_WAIT_NONE) {
		if (debug_level >= DEBUG_LEVEL_INFO)
			printk("%s(%d):mgscc_close(%s) calling tty_wait_until_sent\n",
				 __FILE__,__LINE__, info->device_name );
		tty_wait_until_sent(tty, info->closing_wait);
	}

	if (info->flags & ASYNC_INITIALIZED)
		mgscc_wait_until_sent(tty, info->timeout);

	if (tty->driver->flush_buffer)
		tty->driver->flush_buffer(tty);

	tty_ldisc_flush(tty);

	shutdown(info);

	tty->closing = 0;
	info->tty = 0;

	if (info->blocked_open) {
		if (info->close_delay)
			msleep_interruptible(jiffies_to_msecs(info->close_delay));
		wake_up_interruptible(&info->open_wait);
	}

	info->flags &= ~(ASYNC_NORMAL_ACTIVE|ASYNC_CLOSING);

	wake_up_interruptible(&info->close_wait);

cleanup:
	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_close(%s) exit, count=%d\n", __FILE__,__LINE__,
			tty->driver->name, info->count);

}	/* end of mgscc_close() */

/* mgscc_wait_until_sent()
 *
 *	Wait until the transmitter is empty.
 *
 * Arguments:
 *
 *	tty		pointer to tty info structure
 *	timeout		time to wait for send completion
 *
 * Return Value:	None
 */
static void mgscc_wait_until_sent(struct tty_struct *tty, int timeout)
{
	struct mgscc_struct * info = (struct mgscc_struct *)tty->driver_data;
	unsigned long orig_jiffies, char_time;

	if (!info )
		return;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_wait_until_sent(%s) entry\n",
			 __FILE__,__LINE__, info->device_name );

	if (mgscc_paranoia_check(info, tty->name, "mgscc_wait_until_sent"))
		return;

	if (!(info->flags & ASYNC_INITIALIZED))
		goto exit;

	orig_jiffies = jiffies;

	/* Set check interval to 1/5 of estimated time to
	 * send a character, and make it at least 1. The check
	 * interval should also be less than the timeout.
	 * Note: use tight timings here to satisfy the NIST-PCTS.
	 */

	if ( info->params.data_rate ) {
		char_time = info->timeout/(32 * 5);
		if (!char_time)
			char_time++;
	} else
		char_time = 1;

	if (timeout)
		char_time = MIN(char_time, timeout);

	while (info->tx_active) {
		msleep_interruptible(jiffies_to_msecs(char_time));
		if (signal_pending(current))
			break;
		if (timeout && ((orig_jiffies + timeout) < jiffies))
			break;
	}

exit:
	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_wait_until_sent(%s) exit\n",
			 __FILE__,__LINE__, info->device_name );

}	/* end of mgscc_wait_until_sent() */

/* mgscc_hangup()
 *
 *	Called by tty_hangup() when a hangup is signaled.
 *	This is the same as to closing all open files for the port.
 *
 * Arguments:		tty	pointer to associated tty object
 * Return Value:	None
 */
static void mgscc_hangup(struct tty_struct *tty)
{
	struct mgscc_struct * info = (struct mgscc_struct *)tty->driver_data;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_hangup(%s)\n",
			 __FILE__,__LINE__, info->device_name );

	if (mgscc_paranoia_check(info, tty->name, "mgscc_hangup"))
		return;

	mgscc_flush_buffer(tty);
	shutdown(info);

	info->count = 0;
	info->flags &= ~ASYNC_NORMAL_ACTIVE;
	info->tty = 0;

	wake_up_interruptible(&info->open_wait);

}	/* end of mgscc_hangup() */

/* block_til_ready()
 *
 *	Block the current process until the specified port
 *	is ready to be opened.
 *
 * Arguments:
 *
 *	tty		pointer to tty info structure
 *	filp		pointer to open file object
 *	info		pointer to device instance data
 *
 * Return Value:	0 if success, otherwise error code
 */
static int block_til_ready(struct tty_struct *tty, struct file * filp,
			   struct mgscc_struct *info)
{
	DECLARE_WAITQUEUE(wait, current);
	int		retval;
	int		do_clocal = 0, extra_count = 0;
	unsigned long	flags;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):block_til_ready on %s\n",
			 __FILE__,__LINE__, tty->driver->name );

	if (filp->f_flags & O_NONBLOCK || tty->flags & (1 << TTY_IO_ERROR)){
		/* nonblock mode is set or port is not enabled */
		info->flags |= ASYNC_NORMAL_ACTIVE;
		return 0;
	}

	if (tty->termios->c_cflag & CLOCAL)
		do_clocal = 1;

	/* Wait for carrier detect and the line to become
	 * free (i.e., not in use by the callout).  While we are in
	 * this loop, info->count is dropped by one, so that
	 * mgscc_close() knows when to free things.  We restore it upon
	 * exit, either normal or abnormal.
	 */

	retval = 0;
	add_wait_queue(&info->open_wait, &wait);

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):block_til_ready before block on %s count=%d\n",
			 __FILE__,__LINE__, tty->driver->name, info->count );

	spin_lock_irqsave(&info->irq_spinlock,flags);
	if (!tty_hung_up_p(filp)) {
		extra_count = 1;
		info->count--;
	}
	spin_unlock_irqrestore(&info->irq_spinlock,flags);
	info->blocked_open++;

	while (1) {
		if (tty->termios->c_cflag & CBAUD) {
			spin_lock_irqsave(&info->irq_spinlock,flags);
			info->serial_signals |= SerialSignal_RTS + SerialSignal_DTR;
			scc_set_serial_signals(info);
			spin_unlock_irqrestore(&info->irq_spinlock,flags);
		}

		set_current_state(TASK_INTERRUPTIBLE);

		if (tty_hung_up_p(filp) || !(info->flags & ASYNC_INITIALIZED)){
			retval = (info->flags & ASYNC_HUP_NOTIFY) ?
					-EAGAIN : -ERESTARTSYS;
			break;
		}

		spin_lock_irqsave(&info->irq_spinlock,flags);
		scc_get_serial_signals(info);
		spin_unlock_irqrestore(&info->irq_spinlock,flags);

		if (!(info->flags & ASYNC_CLOSING) &&
		    (do_clocal || (info->serial_signals & SerialSignal_DCD)) ) {
			break;
		}

		if (signal_pending(current)) {
			retval = -ERESTARTSYS;
			break;
		}

		if (debug_level >= DEBUG_LEVEL_INFO)
			printk("%s(%d):block_til_ready blocking on %s count=%d\n",
				 __FILE__,__LINE__, tty->driver->name, info->count );

		schedule();
	}

	set_current_state(TASK_RUNNING);
	remove_wait_queue(&info->open_wait, &wait);

	if (extra_count)
		info->count++;
	info->blocked_open--;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):block_til_ready after blocking on %s count=%d\n",
			 __FILE__,__LINE__, tty->driver->name, info->count );

	if (!retval)
		info->flags |= ASYNC_NORMAL_ACTIVE;

	return retval;

}	/* end of block_til_ready() */

/* mgscc_open()
 *
 *	Called when a port is opened.  Init and enable port.
 *	Perform serial-specific initialization for the tty structure.
 *
 * Arguments:		tty	pointer to tty info structure
 *			filp	associated file pointer
 *
 * Return Value:	0 if success, otherwise error code
 */
static int mgscc_open(struct tty_struct *tty, struct file * filp)
{
	struct mgscc_struct	*info;
	int			retval, line;
	unsigned long		page;
	unsigned long flags;

	/* verify range of specified line number */
	line = tty->index;
	if ((line < 0) || (line >= mgscc_device_count)) {
		printk("%s(%d):mgscc_open with invalid line #%d.\n",
			__FILE__,__LINE__,line);
		return -ENODEV;
	}

	/* find the info structure for the specified line */
	info = mgscc_device_list;
	while(info && info->line != line)
		info = info->next_device;
	if (mgscc_paranoia_check(info, tty->name, "mgscc_open"))
		return -ENODEV;

	tty->driver_data = info;
	info->tty = tty;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_open(%s), old ref count = %d\n",
			 __FILE__,__LINE__,tty->driver->name, info->count);

	/* If port is closing, signal caller to try again */
	if (tty_hung_up_p(filp) || info->flags & ASYNC_CLOSING){
		if (info->flags & ASYNC_CLOSING)
			interruptible_sleep_on(&info->close_wait);
		retval = ((info->flags & ASYNC_HUP_NOTIFY) ?
			-EAGAIN : -ERESTARTSYS);
		goto cleanup;
	}

	if (!tmp_buf) {
		page = get_zeroed_page(GFP_KERNEL);
		if (!page) {
			retval = -ENOMEM;
			goto cleanup;
		}
		if (tmp_buf)
			free_page(page);
		else
			tmp_buf = (unsigned char *) page;
	}

	info->tty->low_latency = (info->flags & ASYNC_LOW_LATENCY) ? 1 : 0;

	spin_lock_irqsave(&info->netlock, flags);
	if (info->netcount) {
		retval = -EBUSY;
		spin_unlock_irqrestore(&info->netlock, flags);
		goto cleanup;
	}
	info->count++;
	spin_unlock_irqrestore(&info->netlock, flags);

	if (info->count == 1) {
		/* 1st open on this device, init hardware */
		retval = startup(info);
		if (retval < 0)
			goto cleanup;
	}

	retval = block_til_ready(tty, filp, info);
	if (retval) {
		if (debug_level >= DEBUG_LEVEL_INFO)
			printk("%s(%d):block_til_ready(%s) returned %d\n",
				 __FILE__,__LINE__, info->device_name, retval);
		goto cleanup;
	}

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s(%d):mgscc_open(%s) success\n",
			 __FILE__,__LINE__, info->device_name);
	retval = 0;

cleanup:
	if (retval) {
		if (tty->count == 1)
			info->tty = 0; /* tty layer will release tty struct */
		if(info->count)
			info->count--;
	}

	return retval;

}	/* end of mgscc_open() */

/*
 * /proc fs routines....
 */

static inline int line_info(char *buf, struct mgscc_struct *info)
{
	char	stat_buf[30];
	int	ret=0;
	unsigned long flags;

	if (info->bus_type == MGSL_BUS_TYPE_PCI) {
		ret = sprintf(buf, "%s:PCI io:%04X irq:%d lcr:%08X",
			info->device_name, info->io_base, info->irq_level,
			info->phys_lcr_base);
	}

	/* output current serial signal states */
	spin_lock_irqsave(&info->irq_spinlock,flags);
	scc_get_serial_signals(info);
	spin_unlock_irqrestore(&info->irq_spinlock,flags);

	stat_buf[0] = 0;
	stat_buf[1] = 0;
	if (info->serial_signals & SerialSignal_RTS)
		strcat(stat_buf, "|RTS");
	if (info->serial_signals & SerialSignal_CTS)
		strcat(stat_buf, "|CTS");
	if (info->serial_signals & SerialSignal_DTR)
		strcat(stat_buf, "|DTR");
	if (info->serial_signals & SerialSignal_DSR)
		strcat(stat_buf, "|DSR");
	if (info->serial_signals & SerialSignal_DCD)
		strcat(stat_buf, "|CD");
	if (info->serial_signals & SerialSignal_RI)
		strcat(stat_buf, "|RI");

	if (info->params.mode == MGSL_MODE_HDLC) {
		ret += sprintf(buf+ret, " HDLC txok:%d rxok:%d",
			      info->icount.txok, info->icount.rxok);
		if (info->icount.txunder)
			ret += sprintf(buf+ret, " txunder:%d", info->icount.txunder);
		if (info->icount.txabort)
			ret += sprintf(buf+ret, " txabort:%d", info->icount.txabort);
		if (info->icount.rxshort)
			ret += sprintf(buf+ret, " rxshort:%d", info->icount.rxshort);
		if (info->icount.rxlong)
			ret += sprintf(buf+ret, " rxlong:%d", info->icount.rxlong);
		if (info->icount.rxover)
			ret += sprintf(buf+ret, " rxover:%d", info->icount.rxover);
		if (info->icount.rxcrc)
			ret += sprintf(buf+ret, " rxlong:%d", info->icount.rxcrc);
	} else {
		ret += sprintf(buf+ret, " ASYNC tx:%d rx:%d",
			      info->icount.tx, info->icount.rx);
		if (info->icount.frame)
			ret += sprintf(buf+ret, " fe:%d", info->icount.frame);
		if (info->icount.parity)
			ret += sprintf(buf+ret, " pe:%d", info->icount.parity);
		if (info->icount.brk)
			ret += sprintf(buf+ret, " brk:%d", info->icount.brk);
		if (info->icount.overrun)
			ret += sprintf(buf+ret, " oe:%d", info->icount.overrun);
	}

	/* Append serial signal status to end */
	ret += sprintf(buf+ret, " %s\n", stat_buf+1);

	ret += sprintf(buf+ret, "txactive=%d bh_req=%d bh_run=%d pending_bh=%x\n",
	 info->tx_active,info->bh_requested,info->bh_running,
	 info->pending_bh);

//	spin_lock_irqsave(&info->irq_spinlock,flags);
//	{
//	}
//	spin_unlock_irqrestore(&info->irq_spinlock,flags);

	return ret;

}	/* end of line_info() */

/* mgscc_read_proc()
 *
 * Called to print information about devices
 *
 * Arguments:
 *	page	page of memory to hold returned info
 *	start
 *	off
 *	count
 *	eof
 *	data
 *
 * Return Value:
 */
int mgscc_read_proc(char *page, char **start, off_t off, int count,
		 int *eof, void *data)
{
	int len = 0, l;
	off_t	begin = 0;
	struct mgscc_struct *info;

	len += sprintf(page, "synclink scc driver:%s\n", driver_version);

	info = mgscc_device_list;
	while( info ) {
		l = line_info(page + len, info);
		len += l;
		if (len+begin > off+count)
			goto done;
		if (len+begin < off) {
			begin += len;
			len = 0;
		}
		info = info->next_device;
	}

	*eof = 1;
done:
	if (off >= len+begin)
		return 0;
	*start = page + (off-begin);
	return ((count < begin+len-off) ? count : begin+len-off);

}	/* end of mgscc_read_proc() */

/* mgscc_allocate_buffers()
 *
 *	Allocate and format hdlc frame buffers
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:	0 if success, otherwise error
 */
int mgscc_allocate_buffers(struct mgscc_struct *info)
{
	info->rx_buffer_count = MAXRXFRAMES;
	info->tx_buffer_count = 1;

	if ( debug_level >= DEBUG_LEVEL_INFO )
		printk("%s(%d):Allocating %d TX and %d RX buffers.\n",
			__FILE__,__LINE__, info->tx_buffer_count,info->rx_buffer_count);

	if ( mgscc_alloc_buffer_list_memory( info ) < 0 ||
		  mgscc_alloc_frame_memory(info, info->rx_buffer_list, info->rx_buffer_count) < 0 ||
		  mgscc_alloc_frame_memory(info, info->tx_buffer_list, info->tx_buffer_count) < 0 ||
		  mgscc_alloc_intermediate_rxbuffer_memory(info) < 0 ) {
		printk("%s(%d):Can't allocate buffer memory\n",__FILE__,__LINE__);
		return -ENOMEM;
	}

	mgscc_reset_rx_buffers( info );

	return 0;

}	/* end of mgscc_allocate_buffers() */

/*
 * mgscc_alloc_buffer_list_memory()
 *
 * Allocate a common buffer for use as the receive and transmit buffer lists.
 *
 * A buffer list is a set of buffer entries where each entry contains
 * a pointer to an actual buffer and a pointer to the next buffer entry
 * (plus some other info about the buffer).
 *
 * The buffer entries for a list are built to form a circular list so
 * that when the entire list has been traversed you start back at the
 * beginning.
 *
 * This function allocates memory for just the buffer entries.
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:	0 if success, otherwise error
 */
int mgscc_alloc_buffer_list_memory( struct mgscc_struct *info )
{
	int num_buffers = info->rx_buffer_count + info->tx_buffer_count;

	/* The buffer lists are allocated as a common buffer that both */
	/* the processor and adapter can access. This allows the driver to */
	/* inspect portions of the buffer while other portions are being */
	/* updated by the adapter ISR. */

	info->buffer_list = kmalloc( sizeof(BUFFERENTRY)*num_buffers, GFP_KERNEL);
	if ( info->buffer_list == NULL )
		return -ENOMEM;

	/* We got the memory for the buffer entry lists. */
	/* Initialize the memory block to all zeros. */
	memset( info->buffer_list, 0, sizeof(BUFFERENTRY)*num_buffers);

	/* Save virtual address pointers to the receive and */
	/* transmit buffer lists. (Receive 1st). These pointers will */
	/* be used by the processor to access the lists. */
	info->rx_buffer_list = (BUFFERENTRY *)info->buffer_list;
	info->tx_buffer_list = (BUFFERENTRY *)info->buffer_list;
	info->tx_buffer_list += info->rx_buffer_count;
	return 0;

}	/* end of mgscc_alloc_buffer_list_memory() */

/* Free buffers allocated for use as the  receive and transmit buffer lists.
 * Warning:
 *
 *	The data transfer buffers associated with the buffer list
 *	MUST be freed before freeing the buffer list itself because
 *	the buffer list contains the information necessary to free
 *	the individual buffers!
 */
void mgscc_free_buffer_list_memory( struct mgscc_struct *info )
{
	if (info->buffer_list)
		kfree(info->buffer_list);

	info->buffer_list = NULL;
	info->rx_buffer_list = NULL;
	info->tx_buffer_list = NULL;

}	/* end of mgscc_free_buffer_list_memory() */

/*
 * mgscc_alloc_frame_memory()
 *
 *	Allocate the frame buffers used by the specified buffer list.
 *
 * Arguments:
 *
 *	info		pointer to device instance data
 *	BufferList	pointer to list of buffer entries
 *	Buffercount	count of buffer entries in buffer list
 *
 * Return Value:	0 if success, otherwise -ENOMEM
 */
int mgscc_alloc_frame_memory(struct mgscc_struct *info,BUFFERENTRY *BufferList,int Buffercount)
{
	int i;

	/* Allocate page sized buffers for the receive buffer list */

	for ( i = 0; i < Buffercount; i++ ) {
		BufferList[i].databuffer= kmalloc(info->max_frame_size, GFP_KERNEL);
		if ( BufferList[i].databuffer == NULL )
			return -ENOMEM;
	}

	return 0;

}	/* end of mgscc_alloc_frame_memory() */

/*
 * mgscc_free_frame_memory()
 *
 *	Free the buffers associated with
 *	each buffer entry of a buffer list.
 *
 * Arguments:
 *
 *	info		pointer to device instance data
 *	BufferList	pointer to list of buffer entries
 *	Buffercount	count of buffer entries in buffer list
 *
 * Return Value:	None
 */
void mgscc_free_frame_memory(struct mgscc_struct *info, BUFFERENTRY *BufferList, int Buffercount)
{
	int i;

	if ( BufferList ) {
		for ( i = 0 ; i < Buffercount ; i++ ) {
			if ( BufferList[i].databuffer) {
				kfree(BufferList[i].databuffer);
				BufferList[i].databuffer = NULL;
			}
		}
	}

}	/* end of mgscc_free_frame_memory() */

/* mgscc_free_buffers()
 *
 *	Free hdlc frame buffers
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:	None
 */
void mgscc_free_buffers( struct mgscc_struct *info )
{
	mgscc_free_intermediate_rxbuffer_memory(info);
	mgscc_free_frame_memory( info, info->rx_buffer_list, info->rx_buffer_count );
	mgscc_free_frame_memory( info, info->tx_buffer_list, info->tx_buffer_count );
	mgscc_free_buffer_list_memory( info );

}	/* end of mgscc_free_buffers() */

/*
 * mgscc_alloc_intermediate_rxbuffer_memory()
 *
 *	Allocate a buffer large enough to hold max_frame_size. This buffer
 *	is used to pass an assembled frame to the line discipline.
 *
 * Arguments:
 *
 *	info		pointer to device instance data
 *
 * Return Value:	0 if success, otherwise -ENOMEM
 */
int mgscc_alloc_intermediate_rxbuffer_memory(struct mgscc_struct *info)
{
	info->intermediate_rxbuffer = kmalloc(info->max_frame_size, GFP_KERNEL);
	if ( info->intermediate_rxbuffer == NULL )
		return -ENOMEM;

	return 0;

}	/* end of mgscc_alloc_intermediate_rxbuffer_memory() */

/*
 * mgscc_free_intermediate_rxbuffer_memory()
 *
 *
 * Arguments:
 *
 *	info		pointer to device instance data
 *
 * Return Value:	None
 */
void mgscc_free_intermediate_rxbuffer_memory(struct mgscc_struct *info)
{
	if ( info->intermediate_rxbuffer )
		kfree(info->intermediate_rxbuffer);

	info->intermediate_rxbuffer = NULL;

}	/* end of mgscc_free_intermediate_rxbuffer_memory() */

int mgscc_claim_resources(struct mgscc_struct *info)
{
	if (request_region(info->io_base,info->io_addr_size,"synclinkscc") == NULL) {
		printk( "%s(%d):I/O address conflict on device %s Addr=%08X\n",
			__FILE__,__LINE__,info->device_name, info->io_base);
		return -ENODEV;
	}
	info->io_addr_requested = 1;

	if ( request_irq(info->irq_level,mgscc_interrupt,info->irq_flags,
		info->device_name, info ) < 0 ) {
		printk( "%s(%d):Cant request interrupt on device %s IRQ=%d\n",
			__FILE__,__LINE__,info->device_name, info->irq_level );
		goto errout;
	}
	info->irq_requested = 1;

	if (request_mem_region(info->phys_lcr_base + info->lcr_offset,128,"synclinkscc") == NULL) {
		printk( "%s(%d):%s lcr mem addr conflict, Addr=%08X\n",
			__FILE__,__LINE__,info->device_name, info->phys_lcr_base);
		goto errout;
	}
	info->lcr_mem_requested = 1;

	info->lcr_base = ioremap(info->phys_lcr_base,PAGE_SIZE) + info->lcr_offset;
	if (!info->lcr_base) {
		printk( "%s(%d):Cant map LCR memory on device %s MemAddr=%08X\n",
			__FILE__,__LINE__,info->device_name, info->phys_lcr_base );
		goto errout;
	}

	if ( mgscc_allocate_buffers(info) < 0 ) {
		printk( "%s(%d):Cant allocate buffers on device %s\n",
			__FILE__,__LINE__,info->device_name);
		goto errout;
	}

	return 0;
errout:
	mgscc_release_resources(info);
	return -ENODEV;
}

/* end of mgscc_claim_resources() */

void mgscc_release_resources(struct mgscc_struct *info)
{
	if ( debug_level >= DEBUG_LEVEL_INFO )
		printk( "%s(%d):mgscc_release_resources(%s) entry\n",
			__FILE__,__LINE__,info->device_name );

	if ( info->irq_requested ) {
		free_irq(info->irq_level, info);
		info->irq_requested = 0;
	}

	mgscc_free_buffers(info);

	if ( info->lcr_mem_requested ) {
		release_mem_region(info->phys_lcr_base + info->lcr_offset,128);
		info->lcr_mem_requested = 0;
	}

	if ( info->io_addr_requested ) {
		release_region(info->io_base,info->io_addr_size);
		info->io_addr_requested = 0;
	}

	if (info->lcr_base){
		iounmap(info->lcr_base - info->lcr_offset);
		info->lcr_base = 0;
	}

	if ( debug_level >= DEBUG_LEVEL_INFO )
		printk( "%s(%d):mgscc_release_resources(%s) exit\n",
			__FILE__,__LINE__,info->device_name );

}	/* end of mgscc_release_resources() */

/* mgscc_add_device()
 *
 *	Add the specified device instance data structure to the
 *	global linked list of devices and increment the device count.
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:	None
 */
void mgscc_add_device( struct mgscc_struct *info )
{
	int retval;

	info->next_device = NULL;
	info->line = mgscc_device_count;
	sprintf(info->device_name,"ttySLS%d",info->line);

	if (info->line < MAX_TOTAL_DEVICES) {
		if (maxframe[info->line])
			info->max_frame_size = maxframe[info->line];
		info->dosyncppp = dosyncppp[info->line];
	}

	retval = mgscc_claim_resources(info);
	if (!retval)
		retval = mgscc_adapter_test(info);
	if (retval)
		mgscc_release_resources(info);
	mgscc_device_count++;

	if ( !mgscc_device_list )
		mgscc_device_list = info;
	else {
		struct mgscc_struct *current_dev = mgscc_device_list;
		while( current_dev->next_device )
			current_dev = current_dev->next_device;
		current_dev->next_device = info;
	}

	if ( info->max_frame_size < 4096 )
		info->max_frame_size = 4096;
	else if ( info->max_frame_size > 65535 )
		info->max_frame_size = 65535;

	if ( info->bus_type == MGSL_BUS_TYPE_PCI ) {
		printk( "SyncLink SCC device %s added:PCI bus IO=%04X IRQ=%d LCR=%08X MaxFrameSize=%u\n",
			info->device_name, info->io_base, info->irq_level,
			info->phys_lcr_base,
			info->max_frame_size );
	}

#ifdef CONFIG_HDLC
	hdlcdev_init(info);
#endif
}	/* end of mgscc_add_device() */

/* mgscc_allocate_device()
 *
 *	Allocate and initialize a device instance structure
 *
 * Arguments:		none
 * Return Value:	pointer to mgscc_struct if success, otherwise NULL
 */
struct mgscc_struct* mgscc_allocate_device()
{
	struct mgscc_struct *info;

	info = (struct mgscc_struct *)kmalloc(sizeof(struct mgscc_struct),
		 GFP_KERNEL);

	if (!info) {
		printk("Error can't allocate device instance data\n");
	} else {
		memset(info, 0, sizeof(struct mgscc_struct));
		info->magic = MGSCC_MAGIC;
		INIT_WORK(&info->task, mgscc_bh_handler, info);
		info->max_frame_size = 4096;
		info->close_delay = 5*HZ/10;
		info->closing_wait = 30*HZ;
		init_waitqueue_head(&info->open_wait);
		init_waitqueue_head(&info->close_wait);
		init_waitqueue_head(&info->status_event_wait_q);
		init_waitqueue_head(&info->event_wait_q);
		spin_lock_init(&info->irq_spinlock);
		spin_lock_init(&info->netlock);
		memcpy(&info->params,&default_params,sizeof(MGSL_PARAMS));
		info->idle_mode = HDLC_TXIDLE_FLAGS;
		init_timer(&info->tx_timer);
		info->tx_timer.data = (unsigned long)info;
		info->tx_timer.function = mgscc_tx_timeout;
	}

	return info;

}	/* end of mgscc_allocate_device()*/

static struct tty_operations mgscc_ops = {
	.open = mgscc_open,
	.close = mgscc_close,
	.write = mgscc_write,
	.put_char = mgscc_put_char,
	.flush_chars = mgscc_flush_chars,
	.write_room = mgscc_write_room,
	.chars_in_buffer = mgscc_chars_in_buffer,
	.flush_buffer = mgscc_flush_buffer,
	.ioctl = mgscc_ioctl,
	.throttle = mgscc_throttle,
	.unthrottle = mgscc_unthrottle,
	.send_xchar = mgscc_send_xchar,
	.break_ctl = mgscc_break,
	.wait_until_sent = mgscc_wait_until_sent,
 	.read_proc = mgscc_read_proc,
	.set_termios = mgscc_set_termios,
	.stop = mgscc_stop,
	.start = mgscc_start,
	.hangup = mgscc_hangup,
	.tiocmget = tiocmget,
	.tiocmset = tiocmset,
};


/*
 * perform tty device initialization
 */
int mgscc_init_tty(void);
int mgscc_init_tty()
{
	serial_driver = alloc_tty_driver(mgscc_device_count);
	if (!serial_driver)
		return -ENOMEM;

	serial_driver->owner = THIS_MODULE;
	serial_driver->driver_name = "synclinkscc";
	serial_driver->name = "ttySLS";
	serial_driver->major = ttymajor;
	serial_driver->minor_start = 64;
	serial_driver->type = TTY_DRIVER_TYPE_SERIAL;
	serial_driver->subtype = SERIAL_TYPE_NORMAL;
	serial_driver->init_termios = tty_std_termios;
	serial_driver->init_termios.c_cflag =
		B9600 | CS8 | CREAD | HUPCL | CLOCAL;
	serial_driver->flags = TTY_DRIVER_REAL_RAW | TTY_DRIVER_NO_DEVFS;
	tty_set_operations(serial_driver, &mgscc_ops);
	if (tty_register_driver(serial_driver) < 0)
		printk("%s(%d):Couldn't register serial driver\n",
			__FILE__,__LINE__);

 	printk("%s %s, tty major#%d\n",
		driver_name, driver_version,
		serial_driver->major);

	return 0;
}

/* mgscc_init()
 *
 *	Driver initialization entry point.
 *
 * Arguments:	None
 * Return Value:	0 if success, otherwise error code
 */
static int __init mgscc_init(void)
{
/* Uncomment this to kernel debug module.
 * mgscc_get_text_ptr() leaves the .text address in eax
 * which can be used with add-symbol-file with gdb.
 */
	if (break_on_load) {
		mgscc_get_text_ptr();
		BREAKPOINT();
	}

	printk("%s version %s\n", driver_name, driver_version);

	pci_register_driver(&mgscc_pci_driver);
	if ( !mgscc_device_list ) {
		printk("%s(%d):No MicroGate SCC devices found.\n",__FILE__,__LINE__);
		return -ENODEV;
	}

	return mgscc_init_tty();

}


static void __exit mgscc_exit(void)
{
	int rc;
	struct mgscc_struct *info;
	struct mgscc_struct *tmp;

	printk("Unloading %s: version %s\n", driver_name, driver_version);

	if ((rc = tty_unregister_driver(serial_driver)))
		printk("%s(%d) failed to unregister tty driver err=%d\n",
		       __FILE__,__LINE__,rc);

	put_tty_driver(serial_driver);
	info = mgscc_device_list;
	while(info) {
#ifdef CONFIG_HDLC
		hdlcdev_exit(info);
#endif
		mgscc_release_resources(info);
		tmp = info;
		info = info->next_device;
		kfree(tmp);
	}

	if (tmp_buf) {
		free_page((unsigned long) tmp_buf);
		tmp_buf = NULL;
	}

	pci_unregister_driver(&mgscc_pci_driver);

}	/* end of cleanup_module() */


module_init(mgscc_init);
module_exit(mgscc_exit);

/* scc_set_sdlc_mode()
 *
 *    Set up the adapter for SDLC communications.
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:	NONE
 */
void scc_set_sdlc_mode( struct mgscc_struct *info )
{
	unsigned char wr11b_value;

	/*
	 * disable interrupts while programming SCC
	 */
	scc_DisableMasterIrqBit(info);

	info->wr1b_value = 0;			/* disable individual IRQs */
	scc_OutRegB( info, WR1, info->wr1b_value );

	scc_stop_transmitter(info);		/* disable transmitter */
	scc_stop_receiver(info);		/* disable receiver */

	info->wr14b_value = 0;			/* disable BRG on ChannelB */
	scc_OutRegB( info, WR14, info->wr14b_value );

	/*
	 * adapter modes
	 */
	scc_OutRegB( info, WR4, 0x20 );		/* 1x clock mode, SDLC mode */
	scc_OutRegB( info, WR2, 0x00);		/* interrupt vector */

	info->wr3b_value = 0x00;		/* receive parameters and control */
	scc_OutRegB( info, WR3, info->wr3b_value);
						/* transmit parameters and control */
	info->wr5b_value &= BIT7|BIT1;		/* (preserve DTR/RTS setting) */
	scc_OutRegB( info, WR5, info->wr5b_value);

	/* Enable Address Search Mode if configured address is NOT 0xff */
	info->wr6b_value =
		( info->params.addr_filter == 0xff ? 0 : info->params.addr_filter );
	scc_OutRegB( info, WR6, info->wr6b_value);

	if ( info->params.addr_filter != 0xff )
		info->wr3b_value |= BIT2;

	/* SDLC Flag */
	scc_OutRegB( info, WR7, 0x7e );

	if (info->tx_fifo_size > 1)
	{
		/* allow access to WR7' */
		scc_OutRegB( info, WR15,
			(unsigned char)(info->wr15b_value | BIT0) );

		/* Enable Auto TX flag */
		info->wr7b_prime_value = BIT0;
		scc_OutRegB( info, WR7, info->wr7b_prime_value );

		/* remove access to WR7' */
		scc_OutRegB( info, WR15,
			(unsigned char)(info->wr15b_value & ~BIT0) );
	}

	info->wr9b_value = 0x05;		/* disable lower chain, vector include status */
	scc_OutRegB( info, WR9, info->wr9b_value );

	info->wr10b_value = 0x80;		/* CRC Preset to 1, NRZ */
						/* Idle Flags		*/
	if ( info->params.encoding == HDLC_ENCODING_NRZI ) {
		info->wr10b_value |= BIT5;	/* encode NRZI encoding */
	}
	else if ( info->params.encoding == HDLC_ENCODING_BIPHASE_MARK ) {
		info->wr10b_value |= BIT6;	/* encode BIPHASE Mark (FM1) encoding */
						/* TODO: doc - only works with DPLL */
	}
	else if ( info->params.encoding == HDLC_ENCODING_BIPHASE_SPACE ) {
		info->wr10b_value |= BIT6|BIT5;	/* encode BIPHASE Space (FM0) encoding */
						/* TODO: doc - only works with DPLL */
	}
	else if ( info->params.encoding == HDLC_ENCODING_BIPHASE_LEVEL ) {
		/* TODO: Document Not Supported */
		/* Manchester encoding - force NRZ encoding and DPLL FM Mode */
		info->wr10b_value &= ~(BIT6|BIT5); /* NRZ encoding */
	}
	else if ( info->params.encoding == HDLC_ENCODING_DIFF_BIPHASE_LEVEL ) {
		/* TODO: Document Not Supported */
	}

	/* TODO: Doc which underrun actions are supported */
	/* default is HDLC_FLAG_UNDERRUN_CRC, check for other options */

	/* NOTE: WR10:2 (Abort/Flag on Underrun is ignored when operating */
	/* in LoopMode) */
	if ( info->params.encoding == HDLC_FLAG_UNDERRUN_ABORT7 )
		info->wr10b_value |= BIT2;	/* abort on underrun */

	scc_OutRegB( info, WR10, info->wr10b_value );

	scc_set_txidle(info);

	/*
	* Clock Mode Control WR11:
	* 7	0	RTxC XTAL
	* 6-5	00	Rx Clock = RTxC Pin
	* 4-3	01	Tx Clock = TRxC Pin
	* 2	0	TRxC Input
	* 1-0	00	TRxC Output source
	*
	* 0000 1000 = 0x08
	*/
	wr11b_value = 0x08;

					/* Default RxClock = x00xxxxx (RTxC Pin)																		  */
	if ( info->params.flags & HDLC_FLAG_RXC_DPLL )
		wr11b_value	|= BIT6|BIT5;
	else if ( info->params.flags & HDLC_FLAG_RXC_BRG )
		wr11b_value	|= BIT6;
	else if ( info->params.flags & HDLC_FLAG_RXC_TXCPIN )
		wr11b_value	|= BIT5;

					/* Default TxClock	= xxx01xxx (TRxC Pin) */
	if ( info->params.flags & HDLC_FLAG_TXC_DPLL ) {
		wr11b_value |= BIT4|BIT3;	/* TxC DPLL	= xxx11xxx */
	}
	else if ( info->params.flags & HDLC_FLAG_TXC_BRG ) {
		wr11b_value &= ~(BIT4|BIT3);	/* TxC BRG	= xxx10xxx */
		wr11b_value |= BIT4;
	}
	else if ( info->params.flags & HDLC_FLAG_TXC_TXCPIN ) {
		wr11b_value &= ~(BIT4|BIT3);	/* TxC TRxC Pin = xxx01xxx */
		wr11b_value |= BIT3;
	}
	else if ( info->params.flags & HDLC_FLAG_TXC_RXCPIN ) {
		wr11b_value &= ~(BIT4|BIT3);	/* TxC RTxC Pin = xxx00xxx */
	}

	scc_OutRegB( info, WR11, wr11b_value);

	/*
	 * if BOTH RXC and TXC sources are from the baud
	 * rate generator, set it up now
	 */
	if ( (info->params.flags & (HDLC_FLAG_RXC_BRG|HDLC_FLAG_TXC_BRG)) ==
		(HDLC_FLAG_RXC_BRG|HDLC_FLAG_TXC_BRG) ) {

		unsigned short constant =
			(unsigned short)((3686400 / (2*info->params.clock_speed)) - 2);

		/* program baud rate divisors (WR12 = LSB, WR13 = MSB) */

		scc_OutRegB( info, WR12, (unsigned char)constant);
		scc_OutRegB( info, WR13, (unsigned char)(constant >> 8) );

		info->wr14b_value |= BIT1|BIT0;	   /* Brg Source, Brg Enable */
		scc_OutRegB( info, WR14, info->wr14b_value);
	}

	/*
	 * if either RXC or TXC is source from DPLL,
	 * set it up now
	 */
	if ( (info->params.flags & (HDLC_FLAG_RXC_DPLL|HDLC_FLAG_TXC_DPLL)) ||
		info->params.encoding == HDLC_ENCODING_BIPHASE_SPACE ||
		info->params.encoding == HDLC_ENCODING_BIPHASE_MARK ||
		info->params.encoding == HDLC_ENCODING_BIPHASE_LEVEL )
	{
		/*
		 * DPLL uses a 32x clock for NRZ(I) modes and a
		 * 16x clock for FM modes - set default modes/divisors
		 */
		unsigned short constant;
		unsigned short divisor;
		unsigned char WR14_mode;

		if ( info->params.encoding == HDLC_ENCODING_NRZ ||
			info->params.encoding == HDLC_ENCODING_NRZB ||
			info->params.encoding == HDLC_ENCODING_NRZI_MARK ||
			info->params.encoding == HDLC_ENCODING_NRZI_SPACE ||
			info->params.encoding == HDLC_ENCODING_NRZI ) {
			divisor = 32;
			WR14_mode = BIT7|BIT6|BIT5;	/* Set NRZI Mode */
		}
		else {
			divisor = 16;
			WR14_mode = BIT7|BIT6;		/* Set FM Mode */
		}

		constant =
			(unsigned short)((3686400 / (2*info->params.clock_speed*divisor )) - 2);

		/* program baud rate divisors (WR12 = LSB, WR13 = MSB) */

		scc_OutRegB( info, WR12, (unsigned char)constant);
		scc_OutRegB( info, WR13, (unsigned char)(constant >> 8) );

		info->wr14b_value |= BIT1|BIT0;	   /* Brg Source, Brg Enable */

		/* Select Clock Mode First - DPLL Src = Brg */
		scc_OutRegB( info, WR14,
			(unsigned char)(info->wr14b_value|BIT7));

		/* Select Operating Mode  */
		scc_OutRegB( info, WR14,
			(unsigned char)(info->wr14b_value|WR14_mode));

		/* Enter Search Mode */
		scc_OutRegB( info, WR14,
			(unsigned char)(info->wr14b_value|BIT5));
	}

	/*
	* adapter enables
	*/

	info->wr3b_value |= 0xc0;	/* receive parameters and control */
					/* Rx 8 bits per char */
					/* NOTE: SCC Internally sets */
					/* Rx CRC Enable when running  */
					/* SDLC mode */

	/* TODO: document that auto enable CTS/DCD enables both for SCC */
	/* one bit (WR3:5) enable AutoCTS-Transmit and AutoDCD-Receive */
	/* for 8530 */
	if ( info->params.flags & (HDLC_FLAG_AUTO_CTS | HDLC_FLAG_AUTO_DCD) )
		info->wr3b_value |= BIT5;

	scc_OutRegB( info, WR3, info->wr3b_value );

	/*
	 * Transmitter setup/control
	 */
	info->wr5b_value |= BIT6|BIT5;	/* TX 8 bits per char */

	if ( info->params.crc_type != HDLC_CRC_NONE )
		info->wr5b_value |= BIT0;

	scc_OutRegB( info, WR5, info->wr5b_value );

	scc_OutRegB( info, WR0, 0x80);	/* reset xmt crc */

	/*
	 * interrupt enables
	 */
	info->wr15b_value |= BIT7;	/* Always want AbortIE for rx frame status */

	if ( info->params.flags & HDLC_FLAG_AUTO_CTS )
		info->wr15b_value |= BIT5;	/* CTS IE */

	scc_OutRegB( info, WR15, info->wr15b_value );

	scc_OutRegB( info, WR0, 0x10);	/* reset ext/status */
	scc_OutRegB( info, WR0, 0x10);	/* reset ext/status */

	info->wr1b_value = 0x01;	/* enable external/status interrupts */
	scc_OutRegB( info, WR1, info->wr1b_value );

	/*
	 * The 8530's receiver will always implicitly
	 * enables CCITT-CRC16 when in SDLC mode, set
	 * Params to reflect that fact.
	 */
	 info->params.crc_type = HDLC_CRC_16_CCITT;

	/* enable Master Interrupt Enable bit (MIE) */
	scc_EnableMasterIrqBit( info );

}	/* end of usc_set_sdlc_mode() */

/* scc_enable_loopback()
 *
 * When 8530 is placed in Internal Loopback mode, the AutoDCD/CTS enables
 * are ignored.
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:	None
 */
void scc_enable_loopback(struct mgscc_struct *info)
{
	unsigned short constant = 0;

	if ( info->params.clock_speed )
		constant = (unsigned short)((3686400 / (2*info->params.clock_speed )) - 2);

	/* disable BRG while programming */
	info->wr14b_value &= ~BIT0;
	scc_OutRegB( info, WR14, info->wr14b_value );

	scc_OutRegB( info, WR11, 0x52 ); /* TRxC is output, source = BRG */

	/* program baud rate divisors (WR12 = LSB, WR13 = MSB) */
	scc_OutRegB( info, WR12, (unsigned char)constant);
	scc_OutRegB( info, WR13, (unsigned char)(constant >> 8) );

	/* enable BRK, source = PCLK, loopback */
	info->wr14b_value |= BIT4 | BIT2 | BIT1 | BIT0;
	scc_OutRegB( info, WR14, info->wr14b_value );

}	/* end of scc_enable_loopback() */

/* scc_enable_aux_clock()
 *
 * Enabled the AUX clock output at the specified frequency.
 *
 * Arguments:
 *
 *	info		pointer to device extension
 *	data_rate	data rate of clock in bits per second
 *			A data rate of 0 disables the AUX clock.
 *
 * Return Value:	None
 */
void scc_enable_aux_clock( struct mgscc_struct *info, u32 data_rate )
{
	if ( data_rate )
	{
		u32 constant =	((3686400 / (2*data_rate)) - 2);

		scc_OutRegA( info, WR14, 0x02 );	// disable BRG while programming
		scc_OutRegA( info, WR4, 0x40 );		// set X1 clock mode
		scc_OutRegA( info, WR11, 0x56 );	// source = BRG, TRxC = output

		// program baud rate divisors (WR12 = LSB, WR13 = MSB)

		scc_OutRegA( info, WR12, (unsigned char)constant);
		scc_OutRegA( info, WR13, (unsigned char)(constant >> 8) );

		scc_OutRegA( info, WR14, 0x03 );	// enable BRG, source = PCLK
	}
	else {
		scc_OutRegA( info, WR14, 0x02 );	// disable BRG
	}

}	/* end of scc_enable_aux_clock() */

/*
 *
 * void enable_receiver()
 *
 *	Enable/Disable SCC receiver
 *
 * Arguments:		info	pointer to device instance data
 *			enable	0=disable,non-0=enable
 * Return Value:	None
 *
 */
void enable_receiver(struct mgscc_struct *info, int enable)
{
	if ( enable ) {
		/* enable receiver */
		info->wr3b_value |= BIT0;
		scc_OutRegB( info, WR3, info->wr3b_value );

		/* enable receiver interrupts (special condition + all rx char) */
		info->wr1b_value |= BIT4;
		scc_OutRegB( info, WR1, info->wr1b_value );
	}
	else {
		/* disable receiver interrupts */
		info->wr1b_value &= ~(BIT4+BIT3);
		scc_OutRegB( info, WR1, info->wr1b_value );

		/* disable receiver */
		info->wr3b_value &= ~BIT0;
		scc_OutRegB( info, WR3, info->wr3b_value );

		/* flush SCC receive FIFO */
		while( inb(info->ctrl_b) & BIT0 )
			inb(info->data_b);
	}
}

/* scc_stop_receiver()
 *
 *	Disable receiver
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:	None
 */
void scc_stop_receiver( struct mgscc_struct *info )
{
	if (debug_level >= DEBUG_LEVEL_ISR)
		printk("%s(%d):scc_stop_receiver(%s)\n",
			 __FILE__,__LINE__, info->device_name );

	enable_receiver(info,0);

	info->rx_enabled = 0;
	info->rx_overflow = 0;

}	/* end of stop_receiver() */

/* scc_start_receiver()
 *
 *	Enable the receiver
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:	None
 */
void scc_start_receiver( struct mgscc_struct *info )
{
	if (debug_level >= DEBUG_LEVEL_ISR)
		printk("%s(%d):usc_start_receiver(%s)\n",
			 __FILE__,__LINE__, info->device_name );

	scc_stop_receiver( info );
	mgscc_reset_rx_buffers( info );
	enable_receiver(info,1);

	info->rx_enabled = 1;

}	/* end of scc_start_receiver() */

/*
 *
 * static void scc_enable_txfifo_empty()
 *
 *	Set the Z85230 to interrupt on TxFifo Empty or Top of
 *	TxFifo empty.
 *
 * Arguments:		info	pointer to device instance data
 *			enable	TRUE to interrupt on TxFifo Empty
 *				FALSE to interrupt on Top of TxFifo available
 * Return Value:	None
 *
 */
static void scc_enable_txfifo_empty( struct mgscc_struct *info, int enable )
{
	if ( info->tx_fifo_size >  1 ) {

		/* allow access to WR7' */
		scc_OutRegB( info, WR15,
			(unsigned char)(info->wr15b_value|BIT0) );

		if ( enable )
			info->wr7b_prime_value |= BIT5;	/* transmit IRQ on Tx Fifo Empty */
		else
			info->wr7b_prime_value &= ~BIT5; /* transmit IRQ on top of FIFO empty */

		scc_OutRegB( info, WR7, info->wr7b_prime_value );

		/* remove access to WR7' */
		scc_OutRegB( info, WR15,
			(unsigned char)(info->wr15b_value & ~BIT0) );
	}
}

/* scc_start_transmitter()
 *
 *	Enable the transmitter and send a transmit frame if
 *	one is loaded in the transmit frame buffers.
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:	None
 */
void scc_start_transmitter( struct mgscc_struct *info )
{
	if (debug_level >= DEBUG_LEVEL_ISR)
		printk("%s(%d):scc_start_transmitter(%s)\n",
			 __FILE__,__LINE__, info->device_name );

	if ( info->xmit_cnt ) {

		/* Enable transmitter */
		info->wr5b_value |= BIT3;
		scc_OutRegB( info, WR5, info->wr5b_value );

		/* If auto RTS enabled and RTS is inactive, then assert */
		/* RTS and set a flag indicating that the driver should */
		/* negate RTS when the transmission completes. */

		info->drop_rts_on_tx_done = 0;

		if ( info->params.flags & HDLC_FLAG_AUTO_RTS ) {
			if ( !(info->serial_signals & SerialSignal_RTS) ) {
				info->serial_signals |= SerialSignal_RTS;
				scc_set_serial_signals( info );
				info->drop_rts_on_tx_done = 1;
			}
		}

		if ( info->params.mode == MGSL_MODE_ASYNC ) {
			if ( !info->tx_active ) {
				/*
				 * if we have a tx fifo, set the transmitter to
				 * interrupt on top of FIFO full and pre-fill
				 * the tx fifo
				 */
				if ( info->tx_fifo_size > 1 ) {
					scc_enable_txfifo_empty(info,0);
					scc_preload_txfifo(info);
				}
				/* enable transmit interrupts */
				info->wr1b_value |= BIT1;
				scc_OutRegB( info, WR1, info->wr1b_value );

				/* prime tx interrupts by loading another byte */
				scc_load_tx_reg(info);
			}

		}
		else {
			info->cts_failure = 0;
			info->abort_requested = 0;
			info->waiting_on_tx_crc = 0;

			if (info->tx_fifo_size == 1) {
				/*
				 * NMOS SCC requires flag idle mode to be set
				 * before transmitting to send opening flag
				 * properly. 8-bit periods must elapse before
				 * writing 1st data character to guarantee that
				 * any mark idle char in the shift register is
				 * shifted out and the initial flag is loaded
				 * into the shift register. Otherwise the data
				 * character overwrites the flag.
				 */
				info->wr10b_value &= ~BIT3;
				scc_OutRegB(info, WR10, info->wr10b_value);
			}

			/* reset Tx CRC Generator */
			outb( 0x80, info->ctrl_b );

			/* enable Tx Underrun/EOM interrupt */
			info->wr15b_value |= BIT6;
			scc_OutRegB( info, WR15, info->wr15b_value );

			/* enable external/status interrupts if not already enabled */
			if ( !(info->wr1b_value & BIT0) ) {
				info->wr1b_value |= BIT0;
				scc_OutRegB( info, WR1, info->wr1b_value );
			}

			/*
			 * if we have a tx fifo, set the transmitter to
			 * interrupt on top of FIFO full and pre-fill
			 * the tx fifo
			 */
			if ( info->tx_fifo_size > 1 ) {
				scc_enable_txfifo_empty(info,0);
				scc_preload_txfifo(info);
			}

			/* enable transmit interrupts */
			info->wr1b_value |= BIT1;
			scc_OutRegB( info, WR1, info->wr1b_value );

			/* prime tx interrupts by loading another byte */
			scc_load_tx_reg(info);

			/* reset TxUnder/EOM latch */
			outb(0xc0, info->ctrl_b);

			/* if more data, set abort on underrun, otherwise
			 * set send crc+flag on underrun
			 */
			if (info->tx_buffer_list[info->current_tx_buffer].count)
				info->wr10b_value |= BIT2;
			else
				info->wr10b_value &= ~BIT2;

			scc_OutRegB( info, WR10, info->wr10b_value );

			info->tx_timer.expires = jiffies + jiffies_from_ms(5000);
			add_timer(&info->tx_timer);
		}

		info->tx_active = 1;
	}

	info->tx_enabled = 1;

}	/* end of scc_start_transmitter() */

/* scc_stop_transmitter()
 *
 *	Stops the transmitter
 *
 * Arguments:		info	pointer to device isntance data
 * Return Value:	None
 */
void scc_stop_transmitter( struct mgscc_struct *info )
{
	if (debug_level >= DEBUG_LEVEL_ISR)
		printk("%s(%d):scc_stop_transmitter(%s)\n",
			 __FILE__,__LINE__, info->device_name );

	del_timer(&info->tx_timer);

	/* disable transmitter interrupts */
	info->wr1b_value &= ~BIT1;
	scc_OutRegB( info, WR1, info->wr1b_value );

	/* disable transmitter */
	info->wr5b_value &= ~BIT3;
	scc_OutRegB( info, WR5, info->wr5b_value );

	info->tx_enabled = 0;
	info->tx_active	 = 0;

}	/* end of scc_stop_transmitter() */

/*
 *
 * scc_load_tx_reg()
 *
 *	load the next char to be transmitted into the SCC TxData Register
 *
 * Arguments:		info	pointer to device extension (instance data)
 * Return Value:	None
 *
 */
void scc_load_tx_reg( struct mgscc_struct *info)
{
	BUFFERENTRY * pTxBuffer = &info->tx_buffer_list[info->current_tx_buffer];

	if ( info->params.mode == MGSL_MODE_ASYNC ) {
		outb( info->xmit_buf[info->xmit_tail++],info->data_b);
		info->xmit_tail = info->xmit_tail & (SERIAL_XMIT_SIZE-1);
		info->xmit_cnt--;
		info->icount.tx++;
	}
	else {
		outb( *pTxBuffer->get, info->data_b);
		++pTxBuffer->get;
		--pTxBuffer->count;
		info->icount.tx++;
	}
}

/* scc_preload_txfifo()
 *
 *	Fill the transmit FIFO until the FIFO has one char position available
 *	there is no more data to load.
 *
 * NOTE:	The SCC requires that one char be loaded in the the TxData
 *		register after TxInt is enable in order to transmit on
 *		TxBufferEmpty. Make sure there is at least one char left
 *		after we pre-load the TxFifo to make this happen
 *
 * Arguments:		info	pointer to device extension (instance data)
 * Return Value:	None
 */
void scc_preload_txfifo( struct mgscc_struct *info)
{
	int fifo_count = info->tx_fifo_size - 1;

	/*
	 * return if no tx bytes pending and no flow control char (XON/XOFF)
	 * pending
	 */
	if ( !info->xmit_cnt && !info->x_char )
		return;

	if ( info->params.mode == MGSL_MODE_ASYNC ) {

		while ( (fifo_count>0) && (info->xmit_cnt > 1) ) {

			if (info->x_char) {
				/* transmit pending high priority char */
				outb(info->x_char, info->data_b);
				info->x_char = 0;
				info->icount.tx++;
			} else {
				scc_load_tx_reg(info);
			}

			--fifo_count;
		}
	}
	else {
		PBUFFERENTRY pTxBuffer = &info->tx_buffer_list[info->current_tx_buffer];

		while ( (fifo_count>0) && (pTxBuffer->count > 1) ) {
			/* there is more space in the transmit FIFO and */
			/* there is more data in transmit buffer */
			scc_load_tx_reg(info);
			--fifo_count;
		}
	}

}	/* end of scc_preload_txfifo() */

/* scc_reset()
 *
 *	Reset the adapter to a known state and prepare it for further use.
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:	None
 */
void scc_reset( struct mgscc_struct *info )
{
	int i;
	u32 readval;

	/* Set BIT30 of Misc Control Register */
	/* (Local Control Register 0x50) to force reset of USC. */

	volatile u32 *MiscCtrl = (u32 *)(info->lcr_base + 0x50);

	info->misc_ctrl_value |= BIT30;
	*MiscCtrl = info->misc_ctrl_value;

	/*
	 * Force at least 170ns delay before clearing
	 * reset bit. Each read from LCR takes at least
	 * 30ns so 10 times for 300ns to be safe.
	 */
	for(i=0;i<10;i++)
		readval = *MiscCtrl;

	info->misc_ctrl_value &= ~BIT30;
	*MiscCtrl = info->misc_ctrl_value;

	info->idle_mode = 0;

	/* do SCC reset */
	scc_OutRegB(info,WR9,0xc0);

	info->wr1a_value =
	info->wr15a_value =
	info->wr1b_value =
	info->wr3b_value =
	info->wr5b_value =
	info->wr6b_value =
	info->wr7b_prime_value =
	info->wr9b_value =
	info->wr10b_value =
	info->wr14b_value =
	info->wr15b_value = 0;

}	/* end of scc_reset() */

/* scc_set_async_mode()
 *
 *	Program adapter for asynchronous communications.
 *
 * Arguments:		info		pointer to device instance data
 * Return Value:	None
 */
void scc_set_async_mode( struct mgscc_struct *info )
{
	unsigned char wr4b_value = 0;
	unsigned short Speed = 300;
	unsigned short Constant;

	/* disable interrupts while programming USC */
	scc_DisableMasterIrqBit( info );

	/*
	* set communications mode to async with X16 clock, encode
	* parity options
	*/
	wr4b_value = BIT6;			/* Default = x16 clock */
	if ( info->params.stop_bits == 2 )	/* encode stop bits (1,2) */
		wr4b_value |= BIT3+BIT2;
	else
		wr4b_value |= BIT2;

	if ( info->params.parity == ASYNC_PARITY_EVEN )
		wr4b_value |= BIT1 | BIT0;
	else if ( info->params.parity == ASYNC_PARITY_ODD )
		wr4b_value |= BIT0;

	scc_OutRegB( info, WR4, wr4b_value );

	/* Set Receiver options */
	info->wr3b_value = 0;
	if ( info->params.data_bits == 6 )
		info->wr3b_value |= BIT7;
	else if ( info->params.data_bits == 7 )
		info->wr3b_value |= BIT6;
	else if ( info->params.data_bits == 8 )
		info->wr3b_value |= BIT7|BIT6;

	scc_OutRegB( info, WR3, info->wr3b_value);

	/* Set Transmitter options (leave DTR/RTS intact) */
	info->wr5b_value &= (BIT7|BIT1);
	if ( info->params.data_bits == 6 )
		info->wr5b_value |= BIT6;
	else if ( info->params.data_bits == 7 )
		info->wr5b_value |= BIT5;
	else if ( info->params.data_bits == 8 )
		info->wr5b_value |= BIT6|BIT5;

	scc_OutRegB( info, WR5, info->wr5b_value);

	/* Sync Options */
	scc_OutRegB( info, WR6, 0 );
	scc_OutRegB( info, WR7, 0 );

	/* Interrupt Control */
	info->wr9b_value = BIT2;
	scc_OutRegB( info, WR9, info->wr9b_value);

	/* Misc Control */
	scc_OutRegB( info, WR10, 0 );

	/* Disable Clock generation on ChannelA */
	scc_OutRegA( info, WR14, 0x02 );

	/* Clock control and data rate constant */
	if ( info->params.data_rate )
		Speed = (unsigned short)info->params.data_rate;

	Constant = (unsigned short)((3686400 / (2*16*Speed)) - 2);

	/* disable BRG while programming */
	info->wr14b_value = 0x02;
	scc_OutRegB( info, WR14, info->wr14b_value);

	/* TRxC is output, source = BRG */
	scc_OutRegB( info, WR11, 0x52 );

	/* program baud rate divisors */
	scc_OutRegB( info, WR12, (unsigned char)Constant);
	scc_OutRegB( info, WR13, (unsigned char)(Constant >> 8) );

	if ( info->params.loopback )
		info->wr14b_value |= BIT4;

	scc_OutRegB( info, WR14, info->wr14b_value );

	info->wr14b_value |= BIT0;	/* Enable BRG, source = PCLK */
	scc_OutRegB( info, WR14, info->wr14b_value );

	/* Enable receiver */
	info->wr3b_value |= BIT0;
	scc_OutRegB( info, WR3, info->wr3b_value );

	/* Enable transmitter */
	info->wr5b_value |= BIT3;
	scc_OutRegB( info, WR5, info->wr5b_value );

	/* Interrupt Enables */
	scc_OutRegB( info, WR15, 0 );		/* no external/status interrupts */
	scc_OutRegB( info, WR0, 0x10);		/* reset ext/status */
	scc_OutRegB( info, WR0, 0x10);		/* reset ext/status */

	/*
	 * Interrupt on all Rx/Special Condition, Tx Int Enable and External
	 * status Interrupt enable
	 */
	info->wr1b_value |= BIT4 | BIT1 | BIT0;
	scc_OutRegB( info, WR1, info->wr1b_value );

	scc_EnableMasterIrqBit( info );

}	/* end of scc_set_async_mode() */

/* scc_set_sync_mode()	Programs the adapter for HDLC communications.
 *
 * Arguments:		info	pointer to adapter info structure
 * Return Value:	None
 */
void scc_set_sync_mode( struct mgscc_struct *info )
{
	scc_set_sdlc_mode( info );
	scc_enable_aux_clock(info, info->params.clock_speed);

	if (info->params.loopback)
		scc_enable_loopback(info);

}	/* end of scc_set_sync_mode() */

/* scc_set_txidle()	Set the HDLC idle mode for the transmitter.
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:	None
 */
void scc_set_txidle( struct mgscc_struct *info )
{
	unsigned char wr10b = info->wr10b_value;

	if ( info->idle_mode == HDLC_TXIDLE_FLAGS )
		wr10b &= ~BIT3;
	else if ( info->idle_mode == HDLC_TXIDLE_MARK )
		wr10b |= BIT3;

	if ( wr10b != info->wr10b_value ) {
		info->wr10b_value = wr10b;
		scc_OutRegB( info, WR10, info->wr10b_value );
	}

}	/* end of scc_set_txidle() */

/* scc_get_serial_signals()
 *
 *	Query the adapter for the state of the V24 status (input) signals.
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:	None
 */
void scc_get_serial_signals( struct mgscc_struct *info )
{
	unsigned char rr0a, rr0b;

	/* clear all serial signals except DTR and RTS */
	info->serial_signals &= SerialSignal_DTR + SerialSignal_RTS;

	/*
	 * read RR0B to get CTS/DCD and RR0A to get DSR/RI status signals
	 */
	rr0a = inb(info->ctrl_a);
	rr0b = inb(info->ctrl_b);

	if ( rr0a & BIT5 )
		info->serial_signals |= SerialSignal_RI;
	if ( rr0a & BIT3 )
		info->serial_signals |= SerialSignal_DSR;

	if ( rr0b & BIT5 )
		info->serial_signals |= SerialSignal_CTS;
	if ( rr0b & BIT3 )
		info->serial_signals |= SerialSignal_DCD;

}	/* end of scc_get_serial_signals() */

/* scc_set_serial_signals()
 *
 *	Set the state of DTR and RTS based on contents of
 *	serial_signals member of device extension.
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:	None
 */
void scc_set_serial_signals( struct mgscc_struct *info )
{
	if ( info->serial_signals & SerialSignal_RTS )
		info->wr5b_value |= BIT1;
	else
		info->wr5b_value &= ~BIT1;

	if ( info->serial_signals & SerialSignal_DTR )
		info->wr5b_value |= BIT7;
	else
		info->wr5b_value &= ~BIT7;

	scc_OutRegB(info, WR5, info->wr5b_value);

}	/* end of scc_set_serial_signals() */

/*
 * mgscc_free_rx_frame_buffer()
 *
 *	Free the current receive buffer used by a received HDLC
 *	frame such that the buffer can be reused.
 *
 * Arguments:
 *
 *	info			pointer to device instance data
 *	index			index of receive buffer of frame
 *
 * Return Value:	None
 */
void mgscc_free_rx_frame_buffer( struct mgscc_struct *info, unsigned int index)
{
	BUFFERENTRY *pBufEntry = &(info->rx_buffer_list[index]);

	/* reset current buffer for reuse */
	pBufEntry->status = pBufEntry->rcc = 0;
	pBufEntry->count = info->max_frame_size;
	pBufEntry->get = pBufEntry->put = pBufEntry->databuffer;

	/* advance to next buffer entry in linked list */
	if ( ++index == info->rx_buffer_count )
		index = 0;

	info->current_rx_buffer = index;

}	/* end of free_rx_frame_buffer() */

/*
 * mgscc_reset_rx_buffers()
 *
 *	Set the count for all receive buffers and set the current
 *	buffer to the first buffer. This effectively makes all
 *	buffers free and discards any data in buffers.
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:	None
 */
void mgscc_reset_rx_buffers( struct mgscc_struct *info )
{
	BUFFERENTRY *pBufEntry;
	unsigned int i;

	/*
	 * a non-zero count field indicates the buffer is available
	 * to receive incoming frames. Once a buffer is acquired for
	 * a receive operation, the count field will be set to zero
	 * to indicate the buffer is no longer free
	 */
	for ( i = 0; i < info->rx_buffer_count; i++ ) {
		mgscc_free_rx_frame_buffer(info, i );
	}

	info->current_rx_buffer = 0;
	info->scc_rx_buffer = 0;

	/* mark first rx buffer as the active rx buffer */
	pBufEntry = &(info->rx_buffer_list[info->scc_rx_buffer]);

	info->scc_rx_databuffer_size = pBufEntry->count;
	pBufEntry->count = 0;

}	/* end of mgscc_reset_rx_buffers() */

/* mgscc_get_rx_frame()
 *
 *	This function attempts to return a received SDLC frame from the
 *	receive buffers. Only frames received without errors are returned.
 *
 * Arguments:		info	pointer to device extension
 * Return Value:	1 if frame returned, otherwise 0
 */
int mgscc_get_rx_frame(struct mgscc_struct *info)
{
	BUFFERENTRY *pBufEntry;
	unsigned int framesize;
	int ReturnCode = 0;
	unsigned long flags;
	struct tty_struct *tty = info->tty;
	unsigned int index = info->current_rx_buffer;

	/*
	 * current_rx_buffer points to the 1st buffer of the next available
	 * receive frame.
	 */
	pBufEntry = &(info->rx_buffer_list[index]);

	/*
	 * If the count field of the buffer entry is non-zero then
	 * this buffer has not been used. The count field is set to the max size
	 * of the data buffer available for receipt of HDLC frames.
	 *
	 * The receiver routines clear the count field when it starts using the
	 * next available rx buffer. Once a received HDLC frame starts filling
	 * a buffer, the  'rcc' field is bumped to indicate the actual frame
	 * byte count. The 'status' field is set to a non-zero value to indicate
	 * a complete rx frame occupies the rx buffer.
	 *
	 * If we encount a buffer entry with a non-zero count field, there are
	 * no rx frames available. If we encounter a buffer entry with a zero
	 * count field AND a zero status field, the buffer is currently being
	 * used to accept an incoming frame, and no frame is available.
	 *
	 * The existence of a buffer entry with a zero count AND a non-zero
	 * status, indicates a completed rx frame awaiting processing.
	 */
	if ( pBufEntry->count || !pBufEntry->status )
		goto Cleanup;

	/* check status of receive frame */
	if ( pBufEntry->status & (RXSTATUS_SHORT_FRAME + RXSTATUS_OVERRUN +
			RXSTATUS_CRC_ERROR + RXSTATUS_ABORT) ) {
		/*
		 * the frame has some error, bump error count(s), but
		 * do not return anything
		 */
		if ( pBufEntry->status & RXSTATUS_SHORT_FRAME )
			info->icount.rxshort++;
		else if ( pBufEntry->status & RXSTATUS_ABORT )
			info->icount.rxabort++;
		else if ( pBufEntry->status & RXSTATUS_OVERRUN )
			info->icount.rxover++;
		else
			info->icount.rxcrc++;

		framesize = 0;
#ifdef CONFIG_HDLC
		{
			struct net_device_stats *stats = hdlc_stats(info->netdev);
			stats->rx_errors++;
			stats->rx_frame_errors++;
		}
#endif
	} else {
		/* receive frame has no errors, get frame size.
		 * The frame size is the starting value of the RCC (which was
		 * set to 0xffff) minus the ending value of the RCC (decremented
		 * once for each receive character) minus 2 for the 16-bit CRC.
		 */

		framesize = pBufEntry->rcc;

		/* adjust frame size for CRC if any */
		if ( info->params.crc_type == HDLC_CRC_16_CCITT )
			framesize -= 2;
	}

	if ( debug_level >= DEBUG_LEVEL_BH )
		printk("%s(%d):mgscc_get_rx_frame(%s) status=%04X size=%d\n",
			__FILE__,__LINE__,info->device_name,pBufEntry->status,framesize);

	if ( debug_level >= DEBUG_LEVEL_DATA )
		mgscc_trace_block(info,pBufEntry->databuffer,
			MIN(framesize,PAGE_SIZE),0);

	if (framesize) {
		if (framesize > info->max_frame_size)
			info->icount.rxlong++;
		else {
			/* copy buffer(s) to contiguous intermediate buffer */
			memcpy( info->intermediate_rxbuffer,
				pBufEntry->databuffer,
				framesize );

			info->icount.rxok++;

#ifdef CONFIG_HDLC
			if (info->netcount)
				hdlcdev_rx(info,info->intermediate_rxbuffer,framesize);
			else
#endif
				ldisc_receive_buf(tty, info->intermediate_rxbuffer, info->flag_buf, framesize);
		}
	}

	/*
	 * Free the buffer used by this frame.
	 *
	 * NOTE: mgscc_free_rx_frame_buffer automatically bumps
	 *	current_rx_buffer to the next rx buffer to be
	 *	processed.
	 */
	mgscc_free_rx_frame_buffer(info, index);
	ReturnCode = 1;

Cleanup:

	if ( info->rx_enabled && info->rx_overflow ) {
		/*
		 * The receiver needs to restarted because an out of
		 * buffers condition occurred earlier. When the receiver
		 * was stopped because an out of buffers condition,
		 * the scc_rx_buffer pointed to the next buffer to be
		 * used to connect incoming rx bytes. See if that buffer
		 * is not available.
		 */
		pBufEntry = &(info->rx_buffer_list[info->scc_rx_buffer]);

		if ( !pBufEntry->status && pBufEntry->count ) {
			spin_lock_irqsave(&info->irq_spinlock,flags);
			enable_receiver(info,1);
			spin_unlock_irqrestore(&info->irq_spinlock,flags);
		}
	}

	return ReturnCode;

}	/* end of mgscc_get_rx_frame() */

/* mgscc_load_tx_buffer()
 *
 *	Load the transmit buffer with the specified data.
 *
 * Arguments:
 *
 *	info		pointer to device extension
 *	Buffer		pointer to buffer containing frame to load
 *	BufferSize	size in bytes of frame in Buffer
 *
 * Return Value:	None
 */
void mgscc_load_tx_buffer(struct mgscc_struct *info, const char *Buffer,
	 unsigned int BufferSize)
{
	BUFFERENTRY *pBufEntry = &(info->tx_buffer_list[0]);

	if ( debug_level >= DEBUG_LEVEL_DATA )
		mgscc_trace_block(info,Buffer, MIN(BufferSize,PAGE_SIZE), 1);

	pBufEntry->status = 0;
	pBufEntry->count = BufferSize;
	pBufEntry->get = pBufEntry->put = pBufEntry->databuffer;

	/* Copy frame data from source buffer to the tx buffer. */
	memcpy(pBufEntry->databuffer, Buffer, BufferSize);
}	/* end of mgscc_load_tx_buffer() */

/*
 * mgscc_register_test()
 *
 *	Performs a register test of the 16C32.
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:		TRUE if test passed, otherwise FALSE
 */
BOOLEAN mgscc_register_test( struct mgscc_struct *info )
{
	static unsigned char BitPatterns[] =
		{ 0x00, 0xff, 0xaa, 0x55, 0xa5, 0x5a, 0x12, 0x34, 0x69, 0x96, 0x0f };

	unsigned int i;
	BOOLEAN rc = TRUE;
	unsigned long flags;

	spin_lock_irqsave(&info->irq_spinlock,flags);
	scc_reset(info);

	/*
	 * write out values to the SCC Write Regs known to have
	 * correspondiong Read Regs and verify write/read values
	 */
	for ( i = 0; i < sizeof(BitPatterns)/sizeof(unsigned char); ++i ) {
		scc_OutRegB( info, WR13, BitPatterns[i] );
		if ( scc_InRegB( info, WR13 ) != BitPatterns[i] ) {
			rc = FALSE;
			break;
		}
	}

	if ( rc ) {
		/*
		 * read/write tests seem to indicate SCC is available
		 * at the specified I/O address. Now We have either a
		 * Z8530 or a Z85230, determine which using the following:
		 *
		 * Z85230 will allow readback of WR4 when extended read enabled.
		 * Z8530 (no FIFO) does not allow read back of WR4 (RR0 returned).
		 */
		scc_OutRegB( info, WR15, 0x01 );	/* allow access to WR7' */
		scc_OutRegB( info, WR7, 0x40 );		/* enable extended reads */
		scc_OutRegB( info, WR15, 0x0 );		/* remove access to WR7' */
		scc_OutRegB( info, WR4, 0x14 );		/* write test value to WR4 */

		if ( scc_InRegB( info, WR4 ) == 0x14 )
			info->tx_fifo_size = 4;		/* Enhanced SCC (85230) */
		else
			info->tx_fifo_size = 1;

		scc_reset(info);
	}

	spin_unlock_irqrestore(&info->irq_spinlock,flags);

	return rc;

}	/* end of mgscc_register_test() */

/* mgscc_irq_test()	Perform interrupt test of the SCC
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:	TRUE if test passed, otherwise FALSE
 */
BOOLEAN mgscc_irq_test( struct mgscc_struct *info )
{
	unsigned long EndTime;
	unsigned long flags;

	spin_lock_irqsave(&info->irq_spinlock,flags);
	scc_reset(info);

	/*
	 * Setup SCC to interrupt on ZeroCount condition. The ISR sets
	 * irq_occurred to 1.
	 */
	info->diagnostics_mode = TRUE;
	info->irq_occurred = FALSE;

	scc_OutRegA( info, WR15, 0 );		/* no external/status ints on channel A */

	scc_OutRegB( info, WR11, 0x0e );	/* TRxC=BRG,output */
	scc_OutRegB( info, WR14, 2 );		/* Disable BRG, source = PCLK */
	scc_OutRegB( info, WR4, 0x44);		/* 16X Clock Mode, Async */
	scc_OutRegB( info, WR12, 126 );		/* Lower Byte Baud Const (300bps) */
	scc_OutRegB( info, WR13, 1 );		/* Upper Byte Baud Const (300bps) */
	scc_OutRegB( info, WR14, 3 );		/* Enable BRG, source = PCLK */
	scc_OutRegB( info, WR15, 2 );		/* enable zero count interrupt */
	scc_OutRegB( info, WR0, 0x10);		/* reset ext/status */
	scc_OutRegB( info, WR0, 0x10);		/* reset ext/status */
	scc_OutRegB( info, WR1, 1 );		/* external int enable */
	scc_OutRegB( info, WR9, 0x0c );		/* master interrupt enable */

	spin_unlock_irqrestore(&info->irq_spinlock,flags);

	EndTime=100;
	while (EndTime-- && !info->irq_occurred)
		msleep_interruptible(10);

	spin_lock_irqsave(&info->irq_spinlock,flags);
	scc_reset(info);
	spin_unlock_irqrestore(&info->irq_spinlock,flags);

	info->diagnostics_mode = FALSE;

	if ( !info->irq_occurred )
		return FALSE;
	else
		return TRUE;

}	/* end of mgscc_irq_test() */

/* mgscc_adapter_test()
 *
 *	Perform the register, IRQ, tests for the SCC.
 *
 * Arguments:		info	pointer to device instance data
 * Return Value:	0 if success, otherwise -ENODEV
 */
int mgscc_adapter_test( struct mgscc_struct *info )
{
	if ( debug_level >= DEBUG_LEVEL_INFO )
		printk( "%s(%d):Testing device %s\n",
			__FILE__,__LINE__,info->device_name );

	if ( !mgscc_register_test( info ) ) {
		info->init_error = DiagStatus_AddressFailure;
		printk( "%s(%d):Register test failure for device %s Addr=%04X\n",
			__FILE__,__LINE__,info->device_name, (unsigned short)(info->io_base) );
		return -ENODEV;
	}

	if ( !mgscc_irq_test( info ) ) {
		info->init_error = DiagStatus_IrqFailure;
		printk( "%s(%d):Interrupt test failure for device %s IRQ=%d\n",
			__FILE__,__LINE__,info->device_name, (unsigned short)(info->irq_level) );
		return -ENODEV;
	}

	if ( debug_level >= DEBUG_LEVEL_INFO )
		printk( "%s(%d):device %s passed diagnostics\n",
			__FILE__,__LINE__,info->device_name );

	return 0;

}	/* end of mgscc_adapter_test() */

void mgscc_trace_block(struct mgscc_struct *info,const char* data, int count, int xmit)
{
	int i;
	int linecount;
	if (xmit)
		printk("%s tx data:\n",info->device_name);
	else
		printk("%s rx data:\n",info->device_name);

	while(count) {
		if (count > 16)
			linecount = 16;
		else
			linecount = count;

		for(i=0;i<linecount;i++)
			printk("%02X ",(unsigned char)data[i]);
		for(;i<17;i++)
			printk("   ");
		for(i=0;i<linecount;i++) {
			if (data[i]>=040 && data[i]<=0176)
				printk("%c",data[i]);
			else
				printk(".");
		}
		printk("\n");

		data  += linecount;
		count -= linecount;
	}
}	/* end of mgscc_trace_block() */

/* mgscc_tx_timeout()
 *
 *	called when HDLC frame times out
 *	update stats and do tx completion processing
 *
 * Arguments:	context		pointer to device instance data
 * Return Value:	None
 */
void mgscc_tx_timeout(unsigned long context)
{
	struct mgscc_struct *info = (struct mgscc_struct*)context;
	unsigned long flags;

	if ( debug_level >= DEBUG_LEVEL_INFO )
		printk( "%s(%d):mgscc_tx_timeout(%s)\n",
			__FILE__,__LINE__,info->device_name);

	if(info->tx_active && info->params.mode == MGSL_MODE_HDLC)
		info->icount.txtimeout++;

	spin_lock_irqsave(&info->irq_spinlock,flags);
	info->tx_active = 0;
	info->xmit_cnt = info->xmit_head = info->xmit_tail = 0;
	spin_unlock_irqrestore(&info->irq_spinlock,flags);

#ifdef CONFIG_HDLC
	if (info->netcount)
		hdlcdev_tx_done(info);
	else
#endif
		mgscc_bh_transmit(info);

}	/* end of mgscc_tx_timeout() */

#ifdef CONFIG_HDLC

/**
 * called by generic HDLC layer when protocol selected (PPP, frame relay, etc.)
 * set encoding and frame check sequence (FCS) options
 *
 * dev       pointer to network device structure
 * encoding  serial encoding setting
 * parity    FCS setting
 *
 * returns 0 if success, otherwise error code
 */
static int hdlcdev_attach(struct net_device *dev, unsigned short encoding,
			  unsigned short parity)
{
	struct mgscc_struct *info = dev_to_port(dev);
	unsigned char  new_encoding;
	unsigned short new_crctype;

	/* return error if TTY interface open */
	if (info->count)
		return -EBUSY;

	switch (encoding)
	{
	case ENCODING_NRZ:        new_encoding = HDLC_ENCODING_NRZ; break;
	case ENCODING_NRZI:       new_encoding = HDLC_ENCODING_NRZI_SPACE; break;
	case ENCODING_FM_MARK:    new_encoding = HDLC_ENCODING_BIPHASE_MARK; break;
	case ENCODING_FM_SPACE:   new_encoding = HDLC_ENCODING_BIPHASE_SPACE; break;
	case ENCODING_MANCHESTER: new_encoding = HDLC_ENCODING_BIPHASE_LEVEL; break;
	default: return -EINVAL;
	}

	switch (parity)
	{
	case PARITY_NONE:            new_crctype = HDLC_CRC_NONE; break;
	case PARITY_CRC16_PR1_CCITT: new_crctype = HDLC_CRC_16_CCITT; break;
	case PARITY_CRC32_PR1_CCITT: new_crctype = HDLC_CRC_32_CCITT; break;
	default: return -EINVAL;
	}

	info->params.encoding = new_encoding;
	info->params.crc_type = new_crctype;;

	/* if network interface up, reprogram hardware */
	if (info->netcount)
		mgscc_program_hw(info);

	return 0;
}

/**
 * called by generic HDLC layer to send frame
 *
 * skb  socket buffer containing HDLC frame
 * dev  pointer to network device structure
 *
 * returns 0 if success, otherwise error code
 */
static int hdlcdev_xmit(struct sk_buff *skb, struct net_device *dev)
{
	struct mgscc_struct *info = dev_to_port(dev);
	struct net_device_stats *stats = hdlc_stats(dev);
	unsigned long flags;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk(KERN_INFO "%s:hdlc_xmit(%s)\n",__FILE__,dev->name);	

	/* stop sending until this frame completes */
	netif_stop_queue(dev);

	/* copy data to device buffers */
	info->xmit_cnt = skb->len;
	mgscc_load_tx_buffer(info, skb->data, skb->len);

	/* update network statistics */
	stats->tx_packets++;
	stats->tx_bytes += skb->len;

	/* done with socket buffer, so free it */
	dev_kfree_skb(skb);

	/* save start time for transmit timeout detection */
	dev->trans_start = jiffies;

	/* start hardware transmitter if necessary */
	spin_lock_irqsave(&info->irq_spinlock,flags);
	if (!info->tx_active)
	 	scc_start_transmitter(info);
	spin_unlock_irqrestore(&info->irq_spinlock,flags);

	return 0;
}

/**
 * called by network layer when interface enabled
 * claim resources and initialize hardware
 *
 * dev  pointer to network device structure
 *
 * returns 0 if success, otherwise error code
 */
static int hdlcdev_open(struct net_device *dev)
{
	struct mgscc_struct *info = dev_to_port(dev);
	int rc;
	unsigned long flags;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s:hdlcdev_open(%s)\n",__FILE__,dev->name);

	/* generic HDLC layer open processing */
	if ((rc = hdlc_open(dev)))
		return rc;

	/* arbitrate between network and tty opens */
	spin_lock_irqsave(&info->netlock, flags);
	if (info->count != 0 || info->netcount != 0) {
		printk(KERN_WARNING "%s: hdlc_open returning busy\n", dev->name);
		spin_unlock_irqrestore(&info->netlock, flags);
		return -EBUSY;
	}
	info->netcount=1;
	spin_unlock_irqrestore(&info->netlock, flags);

	/* claim resources and init adapter */
	if ((rc = startup(info)) != 0) {
		spin_lock_irqsave(&info->netlock, flags);
		info->netcount=0;
		spin_unlock_irqrestore(&info->netlock, flags);
		return rc;
	}

	/* assert DTR and RTS, apply hardware settings */
	info->serial_signals |= SerialSignal_RTS + SerialSignal_DTR;
	mgscc_program_hw(info);

	/* enable network layer transmit */
	dev->trans_start = jiffies;
	netif_start_queue(dev);

	/* inform generic HDLC layer of current DCD status */
	spin_lock_irqsave(&info->irq_spinlock, flags);
	scc_get_serial_signals(info);
	spin_unlock_irqrestore(&info->irq_spinlock, flags);
	hdlc_set_carrier(info->serial_signals & SerialSignal_DCD, dev);

	return 0;
}

/**
 * called by network layer when interface is disabled
 * shutdown hardware and release resources
 *
 * dev  pointer to network device structure
 *
 * returns 0 if success, otherwise error code
 */
static int hdlcdev_close(struct net_device *dev)
{
	struct mgscc_struct *info = dev_to_port(dev);
	unsigned long flags;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s:hdlcdev_close(%s)\n",__FILE__,dev->name);

	netif_stop_queue(dev);

	/* shutdown adapter and release resources */
	shutdown(info);

	hdlc_close(dev);

	spin_lock_irqsave(&info->netlock, flags);
	info->netcount=0;
	spin_unlock_irqrestore(&info->netlock, flags);

	return 0;
}

/**
 * called by network layer to process IOCTL call to network device
 *
 * dev  pointer to network device structure
 * ifr  pointer to network interface request structure
 * cmd  IOCTL command code
 *
 * returns 0 if success, otherwise error code
 */
static int hdlcdev_ioctl(struct net_device *dev, struct ifreq *ifr, int cmd)
{
	const size_t size = sizeof(sync_serial_settings);
	sync_serial_settings new_line;
	sync_serial_settings __user *line = ifr->ifr_settings.ifs_ifsu.sync;
	struct mgscc_struct *info = dev_to_port(dev);
	unsigned int flags;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("%s:hdlcdev_ioctl(%s)\n",__FILE__,dev->name);

	/* return error if TTY interface open */
	if (info->count)
		return -EBUSY;

	if (cmd != SIOCWANDEV)
		return hdlc_ioctl(dev, ifr, cmd);

	switch(ifr->ifr_settings.type) {
	case IF_GET_IFACE: /* return current sync_serial_settings */

		ifr->ifr_settings.type = IF_IFACE_SYNC_SERIAL;
		if (ifr->ifr_settings.size < size) {
			ifr->ifr_settings.size = size; /* data size wanted */
			return -ENOBUFS;
		}

		flags = info->params.flags & (HDLC_FLAG_RXC_RXCPIN | HDLC_FLAG_RXC_DPLL |
					      HDLC_FLAG_RXC_BRG    | HDLC_FLAG_RXC_TXCPIN |
					      HDLC_FLAG_TXC_TXCPIN | HDLC_FLAG_TXC_DPLL |
					      HDLC_FLAG_TXC_BRG    | HDLC_FLAG_TXC_RXCPIN);

		switch (flags){
		case (HDLC_FLAG_RXC_RXCPIN | HDLC_FLAG_TXC_TXCPIN): new_line.clock_type = CLOCK_EXT; break;
		case (HDLC_FLAG_RXC_BRG    | HDLC_FLAG_TXC_BRG):    new_line.clock_type = CLOCK_INT; break;
		case (HDLC_FLAG_RXC_RXCPIN | HDLC_FLAG_TXC_BRG):    new_line.clock_type = CLOCK_TXINT; break;
		case (HDLC_FLAG_RXC_RXCPIN | HDLC_FLAG_TXC_RXCPIN): new_line.clock_type = CLOCK_TXFROMRX; break;
		default: new_line.clock_type = CLOCK_DEFAULT;
		}

		new_line.clock_rate = info->params.clock_speed;
		new_line.loopback   = info->params.loopback ? 1:0;

		if (copy_to_user(line, &new_line, size))
			return -EFAULT;
		return 0;

	case IF_IFACE_SYNC_SERIAL: /* set sync_serial_settings */

		if(!capable(CAP_NET_ADMIN))
			return -EPERM;
		if (copy_from_user(&new_line, line, size))
			return -EFAULT;

		switch (new_line.clock_type)
		{
		case CLOCK_EXT:      flags = HDLC_FLAG_RXC_RXCPIN | HDLC_FLAG_TXC_TXCPIN; break;
		case CLOCK_TXFROMRX: flags = HDLC_FLAG_RXC_RXCPIN | HDLC_FLAG_TXC_RXCPIN; break;
		case CLOCK_INT:      flags = HDLC_FLAG_RXC_BRG    | HDLC_FLAG_TXC_BRG;    break;
		case CLOCK_TXINT:    flags = HDLC_FLAG_RXC_RXCPIN | HDLC_FLAG_TXC_BRG;    break;
		case CLOCK_DEFAULT:  flags = info->params.flags &
					     (HDLC_FLAG_RXC_RXCPIN | HDLC_FLAG_RXC_DPLL |
					      HDLC_FLAG_RXC_BRG    | HDLC_FLAG_RXC_TXCPIN |
					      HDLC_FLAG_TXC_TXCPIN | HDLC_FLAG_TXC_DPLL |
					      HDLC_FLAG_TXC_BRG    | HDLC_FLAG_TXC_RXCPIN); break;
		default: return -EINVAL;
		}

		if (new_line.loopback != 0 && new_line.loopback != 1)
			return -EINVAL;

		info->params.flags &= ~(HDLC_FLAG_RXC_RXCPIN | HDLC_FLAG_RXC_DPLL |
					HDLC_FLAG_RXC_BRG    | HDLC_FLAG_RXC_TXCPIN |
					HDLC_FLAG_TXC_TXCPIN | HDLC_FLAG_TXC_DPLL |
					HDLC_FLAG_TXC_BRG    | HDLC_FLAG_TXC_RXCPIN);
		info->params.flags |= flags;

		info->params.loopback = new_line.loopback;

		if (flags & (HDLC_FLAG_RXC_BRG | HDLC_FLAG_TXC_BRG))
			info->params.clock_speed = new_line.clock_rate;
		else
			info->params.clock_speed = 0;

		/* if network interface up, reprogram hardware */
		if (info->netcount)
			mgscc_program_hw(info);
		return 0;

	default:
		return hdlc_ioctl(dev, ifr, cmd);
	}
}

/**
 * called by network layer when transmit timeout is detected
 *
 * dev  pointer to network device structure
 */
static void hdlcdev_tx_timeout(struct net_device *dev)
{
	struct mgscc_struct *info = dev_to_port(dev);
	struct net_device_stats *stats = hdlc_stats(dev);
	unsigned long flags;

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("hdlcdev_tx_timeout(%s)\n",dev->name);	

	stats->tx_errors++;
	stats->tx_aborted_errors++;

	spin_lock_irqsave(&info->irq_spinlock,flags);
	scc_stop_transmitter(info);
	spin_unlock_irqrestore(&info->irq_spinlock,flags);

	netif_wake_queue(dev);
}

/**
 * called by device driver when transmit completes
 * reenable network layer transmit if stopped
 *
 * info  pointer to device instance information
 */
static void hdlcdev_tx_done(struct mgscc_struct *info)
{
	if (netif_queue_stopped(info->netdev))
		netif_wake_queue(info->netdev);
}

/**
 * called by device driver when frame received
 * pass frame to network layer
 *
 * info  pointer to device instance information
 * buf   pointer to buffer contianing frame data
 * size  count of data bytes in buf
 */
static void hdlcdev_rx(struct mgscc_struct *info, char *buf, int size)
{
	struct sk_buff *skb = dev_alloc_skb(size);
	struct net_device *dev = info->netdev;
	struct net_device_stats *stats = hdlc_stats(dev);

	if (debug_level >= DEBUG_LEVEL_INFO)
		printk("hdlcdev_rx(%s)\n",dev->name);

	if (skb == NULL) {
		printk(KERN_NOTICE "%s: can't alloc skb, dropping packet\n", dev->name);
		stats->rx_dropped++;
		return;
	}

	memcpy(skb_put(skb, size),buf,size);

	skb->protocol = hdlc_type_trans(skb, info->netdev);

	stats->rx_packets++;
	stats->rx_bytes += size;

	netif_rx(skb);

	info->netdev->last_rx = jiffies;
}

/**
 * called by device driver when adding device instance
 * do generic HDLC initialization
 *
 * info  pointer to device instance information
 *
 * returns 0 if success, otherwise error code
 */
static int hdlcdev_init(struct mgscc_struct *info)
{
	int rc;
	struct net_device *dev;
	hdlc_device *hdlc;

	/* allocate and initialize network and HDLC layer objects */

	if (!(dev = alloc_hdlcdev(info))) {
		printk(KERN_ERR "%s:hdlc device allocation failure\n",__FILE__);
		return -ENOMEM;
	}

	/* for network layer reporting purposes only */
	dev->base_addr = info->io_base;
	dev->irq       = info->irq_level;

	/* network layer callbacks and settings */
	dev->do_ioctl       = hdlcdev_ioctl;
	dev->open           = hdlcdev_open;
	dev->stop           = hdlcdev_close;
	dev->tx_timeout     = hdlcdev_tx_timeout;
	dev->watchdog_timeo = 10*HZ;
	dev->tx_queue_len   = 50;

	/* generic HDLC layer callbacks and settings */
	hdlc         = dev_to_hdlc(dev);
	hdlc->attach = hdlcdev_attach;
	hdlc->xmit   = hdlcdev_xmit;

	/* register objects with HDLC layer */
	if ((rc = register_hdlc_device(dev))) {
		printk(KERN_WARNING "%s:unable to register hdlc device\n",__FILE__);
		free_netdev(dev);
		return rc;
	}

	info->netdev = dev;
	return 0;
}

/**
 * called by device driver when removing device instance
 * do generic HDLC cleanup
 *
 * info  pointer to device instance information
 */
static void hdlcdev_exit(struct mgscc_struct *info)
{
	unregister_hdlc_device(info->netdev);
	free_netdev(info->netdev);
	info->netdev = NULL;
}

#endif /* CONFIG_HDLC */



static int __devinit mgscc_init_one (struct pci_dev *dev,
				     const struct pci_device_id *ent)
{
	struct mgscc_struct *info;

	if (pci_enable_device(dev)) {
		printk("error enabling pci device %p\n", dev);
		return -EIO;
	}

	if (!(info = mgscc_allocate_device())) {
		printk("can't allocate device instance data.\n");
		return -EIO;
	}

        /* Copy user configuration info to device instance data */

	info->io_base = pci_resource_start(dev, 2);
	info->ctrl_b = info->io_base + 0;
	info->data_b = info->io_base + 1;
	info->ctrl_a = info->io_base + 2;
	info->data_a = info->io_base + 3;

	info->irq_level = dev->irq;

        /* Because veremap only works on page boundaries we must map
	 * a larger area than is actually implemented for the LCR
	 * memory range. We map a full page starting at the page boundary.
	 */
	info->phys_lcr_base = pci_resource_start(dev, 0);
	info->lcr_offset    = info->phys_lcr_base & (PAGE_SIZE-1);
	info->phys_lcr_base &= ~(PAGE_SIZE-1);

	info->bus_type = MGSL_BUS_TYPE_PCI;
	info->io_addr_size = 4;
	info->irq_flags = SA_SHIRQ;

	/* Store the PCI9050 misc control register value because a flaw
	 * in the PCI9050 prevents LCR registers from being read if
	 * BIOS assigns an LCR base address with bit 7 set.
	 *
	 * Only the misc control register is accessed for which only
	 * write access is needed, so set an initial value and change
	 * bits to the device instance data as we write the value
	 * to the actual misc control register.
	 */
	info->misc_ctrl_value = 0x087e4546;

	mgscc_add_device(info);

	return 0;
}

static void __devexit mgscc_remove_one (struct pci_dev *dev)
{
}
