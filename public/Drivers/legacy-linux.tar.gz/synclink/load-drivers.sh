#!/bin/sh

# Sample script to load the SyncLink and supporting device drivers
#
# $Id: load-drivers.sh,v 1.15 2005/05/25 14:59:56 paulkf Exp $
#
# Set the device options and select which supporting drivers to load
# by modifying the script variables below.

#--------------------------------------------------------------------------
# Set flags to specifiy which drivers to load, by default, none are loaded
# unless specified as arguments to this script
#
# valid arguments are
#
#	synclink or /dev/ttySLx 
#		drivers for SyncLink Wan Adapter
#
#	synclinkmp or /dev/ttySLMxpy
#		drivers for SyncLink MultiPort Adapter
#
#	synclinkscc or /dev/ttySLSx
#		drivers for SyncLink SCC Adapter
#
#	synclink_cs or /dev/ttySLPx
#		drivers for SyncLink PC Card
#
#	all		all of the above
#--------------------------------------------------------------------------
LOAD_SYNCLINK_WAN=0
LOAD_SYNCLINK_GT=0
LOAD_SYNCLINK_MULTIPORT=0
LOAD_SYNCLINK_SCC=0
LOAD_SYNCLINK_PCCARD=0

SCRIPT_ARGS=

for arg in "$@"; do
	case "$arg" in
		synclink | /dev/ttySL[0-9] ) 
			LOAD_SYNCLINK_WAN=1 
			;;
		synclink_gt | /dev/ttySLG[0-9] ) 
			LOAD_SYNCLINK_GT=1 
			;;
		synclinkmp | /dev/ttySLM[0-9]p[0-9] ) 
			LOAD_SYNCLINK_MULTIPORT=1 
			;;
		synclinkscc | /dev/ttySLS[0-9] )
			LOAD_SYNCLINK_SCC=1 
			;;
		synclink_cs | /dev/ttySLP[0-9] )
			LOAD_SYNCLINK_PCCARD=1 
			;;
		all)
			LOAD_SYNCLINK_WAN=1
			LOAD_SYNCLINK_GT=1
			LOAD_SYNCLINK_MULTIPORT=1 
			LOAD_SYNCLINK_SCC=1 
			LOAD_SYNCLINK_PCCARD=1 
			;;
		*)
			SCRIPT_ARGS="$SCRIPT_ARGS $arg"
	esac
done

# locate the necessary module utilities
# these locations may be distribution specific

MODPROBE=/sbin/modprobe
if [ ! -f $MODPROBE ]; then
    MODPROBE=modprobe
fi

LSMOD=/bin/lsmod
if [ ! -f $LSMOD ]; then
    LSMOD=lsmod
fi

#--------------------------------------------------------------------------
# This section sets variables specifying arguments to load to the
# drivers as they are loaded
#--------------------------------------------------------------------------

# set this variable to "Y" to load the HDLC line discipline driver (n_hdlc.o)
#
# Use this if you are doing custom HDLC applications *or* want
# to run the mgsltest diagnostics program.

LOAD_N_HDLC="Y"


# n_hdlc driver options (see README.TXT for details)
#
# Debug levels other than 0 (disabled) should only be used for diagnosing
# problems because the debugging output will fill the system log and
# degrade performance.

N_HDLC_DEBUG_LEVEL="0"
N_HDLC_MAX_FRAME_SIZE="4096"


# SyncLink driver options (see README.TXT for details)
#
# Debug level is global for all device instances in a driver.
# Debug levels other than 0 (disabled) should only be used for diagnosing
# problems because the debugging output will fill the system log and
# degrade performance.
#
# Options other than debug level require an entry for each installed
# adapter seperated by commas. For example, if two adapters are installed
# then the MAX_FRAME_SIZE options might be set to "4096,1024"
#
# The IO/IRQ/DMA settings should *only* be used for ISA adapters.

SYNCLINK_DEBUG_LEVEL="0"

#SYNCLINK_MAX_FRAME_SIZE="4096"
#SYNCLINK_IO="0x310"
#SYNCLINK_IRQ="11"
#SYNCLINK_DMA="3"

# enable syncppp driver support for 1st 4 devices
# (this covers 4 ports on a multiport adapter or 1st
# 4 adapters for single port adapters)
SYNCPPP_SUPPORT="1,1,1,1"

# The following control allocation of additional transmit buffers
# within the driver to facilitate 'streaming' of transmit data
# while operating in a 'Raw Sync' mode. These are applicable 
# only for the SyncLink WAN adapter.
#
# SYNCLINK_TXDMABUFS -  default is 1, allocates additional transmit
#			dma buffers for outbound data.
#
#			NOTE: each additional transmit dma buffer
#			reduces the number of receive dma buffers
#			available.
# SYNCLINK_TXHOLDBUFS	default is 0, range is 1-5. Allocates
#			additional transmit holding buffers from
#			system memory (does not impact receive
#			dma buffers). As a transmit dma buffer
#			becomes available, a frame contained
#			in one of these holding buffers will
#			be automatically loaded.
#SYNCLINK_TXDMABUFS="2"
#SYNCLINK_TXHOLDBUFS="3"

#--------------------------------------------------------------------------
# This section builds command line args for the drivers, based on the
# above configuration items
#--------------------------------------------------------------------------

# n_hdlc module options

N_HDLC_OPTIONS=""
if [ $N_HDLC_DEBUG_LEVEL ] ; then
    N_HDLC_OPTIONS="${N_HDLC_OPTIONS} debuglevel=${N_HDLC_DEBUG_LEVEL}"
fi
if [ $N_HDLC_MAX_FRAME_SIZE ] ; then
    N_HDLC_OPTIONS="${N_HDLC_OPTIONS} maxframe=${N_HDLC_MAX_FRAME_SIZE}"
fi

# addapter driver module options

SYNCLINK_OPTIONS=""
if [ -f /etc/synclink.conf ] ; then
    . /etc/synclink.conf
    SYNCLINK_OPTIONS="$SCRIPT_ARGS $SYNCLINK_OPTIONS"
fi
if [ $SYNCPPP_SUPPORT ] ; then
    SYNCLINK_OPTIONS="${SYNCLINK_OPTIONS} dosyncppp=${SYNCPPP_SUPPORT}"
fi
if [ $SYNCLINK_DEBUG_LEVEL ] ; then
    SYNCLINK_OPTIONS="${SYNCLINK_OPTIONS} debug_level=${SYNCLINK_DEBUG_LEVEL}"
fi
if [ $SYNCLINK_MAX_FRAME_SIZE ] ; then
    SYNCLINK_OPTIONS="${SYNCLINK_OPTIONS} maxframe=${SYNCLINK_MAX_FRAME_SIZE}"
fi
if [ $SYNCLINK_IO ] ; then
    SYNCLINK_OPTIONS="${SYNCLINK_OPTIONS} io=${SYNCLINK_IO}"
fi
if [ $SYNCLINK_IRQ ] ; then
    SYNCLINK_OPTIONS="${SYNCLINK_OPTIONS} irq=${SYNCLINK_IRQ}"
fi
if [ $SYNCLINK_DMA ] ; then
    SYNCLINK_OPTIONS="${SYNCLINK_OPTIONS} dma=${SYNCLINK_DMA}"
fi
if [ $SYNCLINK_TXDMABUFS ]; then
    SYNCLINK_OPTIONS="${SYNCLINK_OPTIONS} txdmabufs=${SYNCLINK_TXDMABUFS}"
fi
if [ $SYNCLINK_TXHOLDBUFS ]; then
    SYNCLINK_OPTIONS="${SYNCLINK_OPTIONS} txholdbufs=${SYNCLINK_TXHOLDBUFS}"
fi


#--------------------------------------------------------------------------
# common routine to load the specified adapter
# driver and create the device nodes required
#
# Args: name prefix [adapters] [ports] [group] [mode]
#
# where:
#	name		driver module name (required)
#	prefix		device name prefix (required)
#	adapters	number of adapters (optional)
#				default=4
#	ports		number of ports (optional)
#				default depends on adapter:
#					0 for SyncLink WAN, SCC
#					4 for SyncLink MultiPort
#	group		group owner for device nodes (optional)
#				default=root
#	mode		access permissions for device nodes (optional)
#				default=666 (rw for all)
#
#--------------------------------------------------------------------------
load_and_mknode() {
    DRIVER=$1
    DEVICE_PREFIX=$2
    NUM_ADAPTERS=$3
    NUM_PORTS=$4
    DEVICE_GROUP=$5
    DEVICE_MODE=$6

    if [ -z $DRIVER ] ; then
        echo "Driver name not specified\n"
        return 1;
    fi
    if [ -z $DEVICE_PREFIX ] ; then
        echo "Device name prefix name not specified\n"
        return 1;
    fi

    #
    # set defaults if some arguments were not specified
    #
    if [ -z $DEVICE_GROUP ]; then
        DEVICE_GROUP=root
    fi
    if [ -z $DEVICE_MODE ]; then
        DEVICE_MODE=666
    fi
    if [ $DRIVER = "synclinkmp" ]; then
        #
        # for SyncLink MultiPort, default is 1 adapter, 4 ports
        #
        if [ -z $NUM_ADAPTERS ]; then
            NUM_ADAPTERS=1
        fi
        if [ -z $NUM_PORTS ]; then
           NUM_PORTS=4
        fi
    else
        #
        # other SyncLink adapters are single port, default to
	# 4 adapters, no ports
        #
        if [ -z $NUM_ADAPTERS ]; then
            NUM_ADAPTERS=4
        fi
        if [ -z $NUM_PORTS ]; then
           NUM_PORTS=0
        fi
    fi
   
    #
    # load the driver module specified by
    # the first arg
    #
    if ! $LSMOD | grep -i "$DRIVER" > /dev/null ; then
        $MODPROBE $DRIVER $SYNCLINK_OPTIONS || {
    	    echo "Can't load $DRIVER driver."
	    return 1
        }
    fi

    #
    # Create a list of device names for our adapters
    #
    DEVNAMES=
    adapter=0;
    while [ $adapter -lt $NUM_ADAPTERS ] ; do
        if [ $NUM_PORTS -ne 0 ]; then
            port=0
            while [ $port -lt $NUM_PORTS ] ; do
                DEVNAMES="${DEVNAMES} /dev/${DEVICE_PREFIX}${adapter}p${port}"
                port=$((port+1))
            done
        else
            DEVNAMES="${DEVNAMES} /dev/${DEVICE_PREFIX}${adapter}"
        fi
        adapter=$((adapter+1))
    done

    # Create device special files using the dynamically
    # assigned device major number. Device minor numbers
    # start at 64. Remove any existing device nodes
    # and create new ones based on the drivers assigned
    # major value.
    # 
    echo "Removing existing device nodes ..."   
    rm -f ${DEVNAMES}
        
    echo "Creating new device nodes ..."

    ttymajor=`cat /proc/devices | awk "\\$2==\"$DEVICE_PREFIX\" {print \\$1}"`
    ttyminor=64

    for device in ${DEVNAMES} ; do 
        mknod ${device} c $ttymajor $ttyminor
        ttyminor=$(($ttyminor + 1))
    done

    # give appropriate group/permissions
    chgrp ${DEVICE_GROUP} ${DEVNAMES}
    chmod ${DEVICE_MODE}  ${DEVNAMES}

}




#--------------------------------------------------------------------------
# load configured optional drivers
#--------------------------------------------------------------------------

if [ $LOAD_N_HDLC = "Y" ] ; then
    if ! $LSMOD | grep -i "n_hdlc" > /dev/null ; then
	$MODPROBE n_hdlc $N_HDLC_OPTIONS || {
	    echo "Can't load n_hdlc driver."
	    exit 1
	}
    fi
fi

if [ $LOAD_SYNCLINK_WAN -ne 0 ]; then
	load_and_mknode synclink ttySL
fi

if [ $LOAD_SYNCLINK_GT -ne 0 ]; then
	load_and_mknode synclink_gt ttySLG
fi

if [ $LOAD_SYNCLINK_MULTIPORT -ne 0 ]; then
	load_and_mknode synclinkmp ttySLM
fi

if [ $LOAD_SYNCLINK_SCC -ne 0 ]; then
	load_and_mknode synclinkscc ttySLS
fi

if [ $LOAD_SYNCLINK_PCCARD -ne 0 ]; then
	load_and_mknode synclink_cs ttySLP
fi

exit 0;





