#!/bin/sh

LSMOD=/sbin/lsmod
RMMOD=/sbin/rmmod

# script to unload the SyncLink device driver and 
# HDLC line discipline driver
#
# $Id: unload-drivers.sh,v 1.4 2005/05/25 14:59:56 paulkf Exp $

( $LSMOD | grep -i "synclinkmp" >/dev/null) 	&& ${RMMOD} synclinkmp
( $LSMOD | grep -i "synclinkscc">/dev/null)	&& ${RMMOD} synclinkscc 
( $LSMOD | grep -i "synclink_gt">/dev/null) 	&& ${RMMOD} synclink_gt
( $LSMOD | grep -i "synclink"	>/dev/null) 	&& ${RMMOD} synclink
( $LSMOD | grep -i "n_hdlc"	>/dev/null)	&& ${RMMOD} n_hdlc
