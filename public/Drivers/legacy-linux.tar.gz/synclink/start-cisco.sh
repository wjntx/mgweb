#!/bin/sh

# Sample script to start a Cisco HDLC connection
#
# Invokation: ./start-cisco.sh [device name]
#
# Modify variables below to set hardware options and
# network addresses.
#
# $Id: start-cisco.sh,v 1.10 2006/06/13 14:33:07 paulkf Exp $
#
# Cisco HDLC is a proprietary point to point network protocol 
# implemented by the syncppp driver. For more details refer
# to the README.Cisco file in the SyncLink software directory.


# locate the necessary utilities
# these locations may be distribution specific

IFCONFIG=/sbin/ifconfig
LSMOD=lsmod

# set the network interface parameters

IPADDR=192.168.60.1
NETMASK=255.255.255.0
BROADCAST=192.168.20.255

# The syncppp driver supports both Cisco HDLC and PPP
# Set PROTO to cisco for Cisco HDLC (default)
# Set PROTO to ppp for PPP

PROTO=cisco

# If this port needs to generate an output clock on the
# AUXCLK signal, set GENCLOCK to the data rate in bits per
# second. If data clocks are provided by an external
# device, then set GENCLOCK to zero (default).
#
# Generating a clock is usually only necessary when connecting
# two ports back to back through a NULL modem (cross over cable).
# In this case, one side of the connection generates the clock
# which must be routed to the RxC and TxC input signals on
# both sides of the connection.

GENCLOCK=0

# set the SyncLink device name and network interface name
# Note: the device instance number is determined when loading
# the driver. 
#
# Naming conventions:
#
#	Adapter		Device Name	Network Interface Name
#
# SyncLink GT/GT2/GT4   /dev/ttySLG0	mgslg0
#			/dev/ttySLG1	mgslg1
#				etc.
#
# SyncLink WAN Adapter	/dev/ttySL0	mgsl0
#			/dev/ttySL1	mgsl1
#				etc.
#
# SyncLink MultiPort	/dev/ttySLM0p0	mgslm0p0
#	Adapter		/dev/ttySLM0p1	mgslm0p1
#			/dev/ttySLM0p2	mgslm0p2
#			/dev/ttySLM0p2	mgslm0p2
#			/dev/ttySLM1p0	mgslm0p0
#				etc.
#
# SyncLink SCC Adapter	/dev/ttySLS0	mgsls0
#			/dev/ttySLS1	mgsls1
#				etc.
#
# SyncLink PC Card	/dev/ttySLP0	mgslp0
#			/dev/ttySLP1	mgslp1
#				etc.

# Device name is 1st argument to this script.
# Default to 1st Synclink adapter if not specified.

PORT=$1
if [ -z $PORT ] ; then
    PORT=/dev/ttySLG0
    echo "Device name not specified, defaulting to $PORT"
fi

# Derive the network interface name from the device name.
# The derived name can be overriden by specifying the network
# device name as the second argument to this script.

NETIF=$2

if [ -z $NETIF ] ; then
    NETIF=mgsl`echo $PORT | awk -F "ttySL" "/ttySL/ {print tolower(\\$2)}"`
else
    echo "Network interface name manually specified as $NETIF"
fi

if [ -z $NETIF ] ; then
    echo "Net I/F name was not specified and can't be derived from device name."
    exit 1
fi


# load necessary drivers using the sample driver load script

echo "Loading necessary drivers..."
./load-drivers.sh $PORT || exit 1

LOADED_DRIVER=`$LSMOD | awk "\\$1==\"syncppp\" {print \\$1}"`
if [ -z $LOADED_DRIVER ] ; then
    echo "syncppp driver not loaded."
    exit 1
fi


#
# Program the hardware options with mgslutil program
#

if [ "$PROTO" = "cisco" ]; then
    PORTOPTIONS="cisco"
else
    PORTOPTIONS="-cisco"
fi

# Uncomment one of the following lines to select the
# serial interface type. This option is only useful for
# adapters that have a programmable interface such as the
# SyncLink PC Card

#SERIAL_IF=rs232
#SERIAL_IF=v35
#SERIAL_IF=rs422

PORTOPTIONS="$PORTOPTIONS $SERIAL_IF hdlc nrz -loopback clock $GENCLOCK rxc"

if [ "$GENCLOCK" = "0" ]; then
    # External clocks, use TxC input as transmit clock
    PORTOPTIONS="$PORTOPTIONS txc"
else
    # Generating clock output on AUXCLK, use Baud Rate Generator
    # (generated clock source) directly as the transmit clock.
    # This is necessary because the multiport adapter can't generate
    # AUXCLK output and use the TxC input at the same time.
    PORTOPTIONS="$PORTOPTIONS txbrg"
fi

./mgslutil $PORT $PORTOPTIONS



# enable the network interface
#
# Note: This next line is just a sample. Some distributions use
# special scripts for handling network interfaces. For example,
# RedHat uses the if-up and if-down scripts.

echo "Enabling the network interface ${NETIF}..."
$IFCONFIG $NETIF $IPADDR netmask $NETMASK broadcast $BROADCAST up

