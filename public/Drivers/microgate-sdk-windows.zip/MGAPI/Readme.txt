

                   R E L E A S E   I N F O R M A T I O N

    MicroGate(R) MicroGate Serial API Software Development Kit for Windows


This software package contains development files, run time files, sample code
and documentation for developing serial applications on Windows for 
SyncLink serial hardware.

The file serial-api-windows.pdf documents software and hardware installation
as well as application development. This file requires a PDF reader, which
is freely available from www.adobe.com.

Refer to the Hardware User's Guide for your specific hardware for configuration
and installation details specific to your hardware model.


