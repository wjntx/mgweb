﻿// 2-wire sample
//
// primary station usage:
// 2wire mghdlc1
//
// secondary station usage:
// 2wire mghdlc2 s
//
// 2-wire/bussed serial connections use a single wire pair to carry
// send and receive data. Clocks are recovered from the data signal.
// Two or more devices are connected to the wire pair.
// Only one device at a time sends while multiple devices receive.
// The transmit data output MUST be disabled to allow other devices to send.

using System;
using System.Collections.Generic;
using System.Threading;
using System.ComponentModel;
using System.IO;
using Port = Microgate.SerialApi.Port;

namespace two_wire
{
	class two_wire
	{
		static bool run = true;
		static Port port;

 		static void CancelKeyHandler(object sender, ConsoleCancelEventArgs e)
		{
			if (e.SpecialKey == ConsoleSpecialKey.ControlC) {
				Console.WriteLine("Ctrl-C pressed");
				run = false;
				port.disable_transmitter();
				port.disable_receiver();
				e.Cancel = true;
			}
		}

		static void run_primary(Port port) {
			Console.WriteLine("Running as primary station.");
			Console.WriteLine("Press enter to send data.");
			Console.ReadLine();

			// prepare send buffer
			byte[] buf = new byte[1024];
			int i;
			for (i = 0 ; i < buf.Length ; i++)
				buf[i] = (byte)(i & 0xff);

			i = 1;
			while (run) {
				// enable outputs (RTS on) and disable receiver
				port.rts = true;
				port.disable_receiver();

				Console.WriteLine(">>> {0:D9} send {1} bytes", i, buf.Length);
				port.write(buf);
				port.flush();

				// disable outputs (RTS off) and enable receiver
				port.rts = false;
				port.enable_receiver();

				Console.WriteLine("wait for response");
				byte[] response = port.read();
				if (response == null)
					break;
				Console.WriteLine("<<< {0:D9} received {1} byte response",
					i, response.Length);
				i += 1;
			}
		}

		static void run_secondary(Port port) {
			Console.WriteLine("Running as secondary station.");
			var response = new byte[] {0xff, 0x01};

			int i = 1;
			while (run) {
				// disable outputs (RTS off) and enable receiver
				port.rts = false;
				port.enable_receiver();

				Console.WriteLine("wait for data");
				byte[] buf = port.read();
				if (buf == null)
					break;
				Console.WriteLine("<<< {0:D9} received {1} bytes", i, buf.Length);

				// enable outputs (RTS on) and disable receiver
				port.rts = true;
				port.disable_receiver();

				Console.WriteLine(">>> {0:D9} send {1} byte response", i, response.Length);
				port.write(response);
				port.flush();

				i += 1;
			}
		}

		static void Main(string[] args)
		{
			// port name format
			// single port adapter: MGHDLCx, x=adapter number
			// multiport adapter: MGMPxPy, x=adapter number, y=port number
			Port port;
			if (args.Length < 1) {
				// no port name on command line, use first enumerated port
				string[] names = Port.enumerate();
				if (names.Length == 0) {
					Console.WriteLine("No ports available.");
					System.Environment.Exit(1);
				}
				port = new Port(names[0]);
			} else {
				port = new Port(args[0]);
			}
			Console.WriteLine("2-wire HDLC/SDLC sample running on {0}", port.name);
			try {
				port.open();
			}
			catch (FileNotFoundException) {
				Console.WriteLine("port not found");
				System.Environment.Exit(1);
			}
			catch (UnauthorizedAccessException) {
				Console.WriteLine("access denied or port in use");
				System.Environment.Exit(1);
			}
			catch (Win32Exception) {
				Console.WriteLine("open error");
				System.Environment.Exit(1);
			}
			two_wire.port = port;

			// If default 14.7456MHz base clock does not allow exact
			// internal clock generation of desired rate, uncomment these lines and
			// select a new base clock sourced from the frequency synthesizer.
			// PCI Express/USB only. See API manual for details.
			// uint fsynth_rate = 16000000;
			// if (port.set_fsynth_rate(fsynth_rate))
			// 	Console.WriteLine("base clock set to {0}", fsynth_rate);
			// else {
			// 	Console.WriteLine("{0} not supported by fsynth", fsynth_rate);
			// 	System.Environment.Exit(1);
			// }

			// FM0, FM1 or MANCHESTER encodings guarantee data transition
			// every bit to assist clock recovery.
			// Transmit preamble pattern is sent before data to assist
			// clock recovery.
			// Flags are sent when transmitter is idle to maintain
			// clock recovery as long as transmitter is enabled.

			var settings = new Port.Settings();
			settings.protocol = Port.HDLC;
			settings.encoding = Port.MANCHESTER;
			settings.crc = Port.CRC16;
			settings.transmit_clock = Port.INTERNAL;
			settings.receive_clock = Port.RECOVERED;
			settings.internal_clock_rate = 9600;
			settings.transmit_preamble_pattern = 0x7e;
			settings.transmit_preamble_bits = 8;
			port.apply_settings(settings);

			port.transmit_idle_pattern = 0x7e;

			// set rts_output_enable
			port.rts_output_enable = true;
			// To make RTS output enable persistent uncomment these lines.
			// Calling set_defaults requires administrative privilege.
			//Port.Defaults defaults = port.get_defaults();
			//defaults.rts_output_enable = true;
			//port.set_defaults(defaults);

			Console.CancelKeyPress += new ConsoleCancelEventHandler(CancelKeyHandler);
			Console.WriteLine("press Ctrl-C to stop program");

			if (args.Length < 2)
				run_primary(port);
			else
				run_secondary(port);

			// disable RTS output enable
			port.rts_output_enable = false;
			// To make RTS output enable persistent uncomment these lines.
			// Calling set_defaults requires administrative privilege.
			//defaults.rts_output_enable = false;
			//port.set_defaults(defaults);

			port.close();
		}
	}
}
