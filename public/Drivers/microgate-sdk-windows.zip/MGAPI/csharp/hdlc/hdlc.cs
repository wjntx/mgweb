﻿// HDLC/SDLC protocol sample
// - send data in main thread
// - receive data in receive thread
//
// == Single Port Use ==
// Connect data and clock outputs to data and clock inputs with
// loopback plug or external cabling. Alternatively, set
// settings.internal_loopback = True.
//
// == Two Port Use ==
// Connect ports with crossover cable that:
// - connects data output of each port to data input of other port
// - connects clock output of one port to clock inputs of both ports
// Run sample on both ports.

using System;
using System.Collections.Generic;
using System.Threading;
using System.ComponentModel;
using System.IO;
using Port = Microgate.SerialApi.Port;

namespace hdlc
{
	class hdlc
	{
		static bool run = true;

 		static void CancelKeyHandler(object sender, ConsoleCancelEventArgs e)
		{
			if (e.SpecialKey == ConsoleSpecialKey.ControlC) {
				Console.WriteLine("Ctrl-C pressed");
				run = false;
				e.Cancel = true;
			}
		}

		public static void ReceiveFunction(object data)
		{
			var port = (Port)data;

			int i = 1;
			while (run) {
				byte[] buf = port.read();
				if (buf == null)
					break;
				Console.WriteLine("<<< {0:D9}: received {1} bytes", i, buf.Length);
				i += 1;
			}
		}

		static void Main(string[] args)
		{
			// port name format
			// single port adapter: MGHDLCx, x=adapter number
			// multiport adapter: MGMPxPy, x=adapter number, y=port number
			Port port;
			if (args.Length < 1) {
				// no port name on command line, use first enumerated port
				string[] names = Port.enumerate();
				if (names.Length == 0) {
					Console.WriteLine("No ports available.");
					System.Environment.Exit(1);
				}
				port = new Port(names[0]);
			} else {
				port = new Port(args[0]);
			}
			Console.WriteLine("HDLC/SDLC sample running on {0}", port.name);
			try {
				port.open();
			}
			catch (FileNotFoundException) {
				Console.WriteLine("port not found");
				System.Environment.Exit(1);
			}
			catch (UnauthorizedAccessException) {
				Console.WriteLine("access denied or port in use");
				System.Environment.Exit(1);
			}
			catch (Win32Exception) {
				Console.WriteLine("open error");
				System.Environment.Exit(1);
			}

			// If default 14.7456MHz base clock does not allow exact
			// internal clock generation of desired rate, uncomment these lines and
			// select a new base clock sourced from the frequency synthesizer.
			// PCI Express/USB only. See API manual for details.
			// uint fsynth_rate = 16000000;
			// if (port.set_fsynth_rate(fsynth_rate))
			// 	Console.WriteLine("base clock set to {0}", fsynth_rate);
			// else {
			// 	Console.WriteLine("{0} not supported by fsynth", fsynth_rate);
			// 	System.Environment.Exit(1);
			// }

			var settings = new Port.Settings();
			settings.protocol = Port.HDLC;
			settings.encoding = Port.NRZ;
			settings.crc = Port.CRC16;
			settings.transmit_clock = Port.TXC_INPUT;
			settings.receive_clock = Port.RXC_INPUT;
			settings.internal_clock_rate = 9600;
			port.apply_settings(settings);

			port.transmit_idle_pattern = 0x7e;

			Console.CancelKeyPress += new ConsoleCancelEventHandler(CancelKeyHandler);
			Console.WriteLine("press Ctrl-C to stop program");

			port.enable_receiver();
			var receiveThread = new Thread(ReceiveFunction);
			receiveThread.Start(port);

			// prepare send buffer
			var buf = new byte[100];
			int i;
			for (i = 0 ; i < buf.Length ; i++)
				buf[i] = (byte)(i & 0xff);

			i = 1;
			while (run) {
				Console.WriteLine(">>> {0:D9}: send {1} bytes", i, buf.Length);;
				port.write(buf);
				port.flush();
				i += 1;
			}
			port.close();
		}
	}
}
