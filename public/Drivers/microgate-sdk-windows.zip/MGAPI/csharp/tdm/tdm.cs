﻿// Time Division Multiplexing (TDM) sample
//
// Data is sent continuously in main thread.
// Data is received continuously in receive thread.
//
// Use a single port with external cabling to loop back
// signals as described below or connect two ports (both running
// this sample) with external cabling that connects the outputs of
// one port to the inputs of the other port as described below.
//
// WARNING:
// The loopback plug supplied with the SyncLink device is not compatible with
// this sample code. The following connections are required:
//
// Outputs     Inputs
// TxD     --> RxD (send data output to receive data input)
// RTS     --> DCD (sync pulse output to sync pulse input)
// AUXCLK  --> RxC (send clock output to receive clock input)

using System;
using System.Collections.Generic;
using System.Threading;
using System.ComponentModel;
using System.IO;
using Port = Microgate.SerialApi.Port;

namespace tdm
{
	class tdm
	{
		static bool run = true;

		static Port.Settings settings;
		static byte[] send_buf;

 		static void CancelKeyHandler(object sender, ConsoleCancelEventArgs e)
		{
			if (e.SpecialKey == ConsoleSpecialKey.ControlC) {
				Console.WriteLine("Ctrl-C pressed");
				run = false;
				e.Cancel = true;
			}
		}

		// get_slot()/set_slot() access individual slots in buffer
		//
		// - slot may not be integer number of bytes in length
		// - slot is stored in integer number of bytes in buffer
		// - slot is stored in little endian order in buffer
		// - unused most significant bits of slot buffer storage are zero
		//
		// example:
		// 12-bit slot value 0x123 uses 2 buffer bytes: byte[0]=0x23, byte[1]=0x01
		// with the unused most significant 4 bits of byte[1] set to 0

		static uint buffer_bytes_per_slot(uint bits_per_slot) {
			// Return number of bytes needed to store one slot.
			uint buffer_bytes_per_slot = bits_per_slot/8;
			if ((bits_per_slot % 8) != 0)
				buffer_bytes_per_slot += 1;
			return buffer_bytes_per_slot;
		}

		static uint get_slot(byte[] buf, uint slot_index, uint bits_per_slot) {
			// Return slot value from buffer.
			uint bytes_per_slot = buffer_bytes_per_slot(bits_per_slot);
			uint first_byte = bytes_per_slot * slot_index;
			uint value = 0;
			for (uint i = 0 ; i < bytes_per_slot ; i++)
				value += ((uint)buf[first_byte + i] << (int)(i * 8));
			return value;
		}

		static void set_slot(byte[] buf, uint slot_index, uint bits_per_slot, uint value) {
			// Set slot value in buffer.
			uint bytes_per_slot = buffer_bytes_per_slot(bits_per_slot);
			uint first_byte = bytes_per_slot * slot_index;
			for (uint i = 0 ; i < bytes_per_slot ; i++) {
				buf[first_byte + i] = (byte)((value >> (int)(i * 8)) & 0xff);
			}
		}

		public static void ReceiveFunction(object data)
		{
			var port = (Port)data;

			int i = 1;
			while (run) {
				// get tdm_frame_count frames
				byte[] buf = port.read();
				if (buf == null)
					break;
				Console.WriteLine("<<< {0:D9}: received {1} bytes", i, buf.Length);
				// verify received data matches sent data
				for (uint frame = 0 ; frame < settings.tdm_frame_count ; frame++) {
					for (uint slot = 0 ; slot < settings.tdm_slot_count ; slot++) {
						uint index = frame * settings.tdm_slot_count + slot;
						uint received = get_slot(buf, index, settings.tdm_slot_bits);
						uint sent = get_slot(send_buf, index, settings.tdm_slot_bits);
						if (received != sent) {
							Console.WriteLine(
								"<<< ERROR frame #{0} slot #{1} sent={2:x} received={3:x}",
								frame + 1, slot + 1, sent, received);
						}
					}
				}
				i += 1;
			}
		}

		static void Main(string[] args)
		{
			// port name format
			// single port adapter: MGHDLCx, x=adapter number
			// multiport adapter: MGMPxPy, x=adapter number, y=port number
			Port port;
			if (args.Length < 1) {
				// no port name on command line, use first enumerated port
				string[] names = Port.enumerate();
				if (names.Length == 0) {
					Console.WriteLine("No ports available.");
					System.Environment.Exit(1);
				}
				port = new Port(names[0]);
			} else {
				port = new Port(args[0]);
			}
			Console.WriteLine("HDLC/SDLC sample running on {0}", port.name);
			try {
				port.open();
			}
			catch (FileNotFoundException) {
				Console.WriteLine("port not found");
				System.Environment.Exit(1);
			}
			catch (UnauthorizedAccessException) {
				Console.WriteLine("access denied or port in use");
				System.Environment.Exit(1);
			}
			catch (Win32Exception) {
				Console.WriteLine("open error");
				System.Environment.Exit(1);
			}

			// If default 14.7456MHz base clock does not allow exact
			// internal clock generation of desired rate, uncomment these lines and
			// select a new base clock sourced from the frequency synthesizer.
			// PCI Express/USB only. See API manual for details.
			// uint fsynth_rate = 16000000;
			// if (port.set_fsynth_rate(fsynth_rate))
			// 	Console.WriteLine("base clock set to {0}", fsynth_rate);
			// else {
			// 	Console.WriteLine("{0} not supported by fsynth", fsynth_rate);
			// 	System.Environment.Exit(1);
			// }

			settings = new Port.Settings();
			settings.protocol = Port.TDM;
			settings.tdm_sync_delay = 0;
			settings.tdm_sync_short = false;
			settings.tdm_sync_invert = false;
			settings.tdm_frame_count = 10;
			settings.tdm_slot_bits = 32;
			settings.tdm_slot_count = 4;
			settings.msb_first = true;
			// encoding sets data signal polarity: NRZ=normal, NRZB=inverted
			settings.encoding = Port.NRZ;
			settings.crc = Port.OFF;
			settings.transmit_clock = Port.INTERNAL;
			settings.transmit_clock_invert = false;
			settings.receive_clock = Port.RXC_INPUT;
			settings.receive_clock_invert = false;
			settings.internal_clock_rate = 9600;
			port.apply_settings(settings);

			Console.CancelKeyPress += new ConsoleCancelEventHandler(CancelKeyHandler);
			Console.WriteLine("press Ctrl-C to stop program");

			port.enable_receiver();
			var receiveThread = new Thread(ReceiveFunction);
			receiveThread.Start(port);

			// prepare bytearray containing configured number of frames
			// tdm_frame_count = count of frames returned by read()
			// tdm_slot_count = slots per frame
			// tdm_slot_bits = bits per slot (round to integer count of bytes)
			//
			// write() sends one or more frames (total size must be <= 64K bytes).
			// tdm_frame_count only applies to read().
			// This sample sends tdm_frame_count frames per write() to keep
			// write() and read() loop counts equal.
			// send_size MUST be <= port.max_data_size

			uint send_size = settings.tdm_frame_count * settings.tdm_slot_count *
						buffer_bytes_per_slot(settings.tdm_slot_bits);
			send_buf = new byte[send_size];
			for (uint slot = 0; slot < settings.tdm_frame_count * settings.tdm_slot_count ; slot++)
				set_slot(send_buf, slot, settings.tdm_slot_bits, 0x12345678);

			int i = 1;
			while (run) {
				Console.WriteLine(">>> {0:D9}: send {1} bytes", i, send_buf.Length);;
				port.write(send_buf);
				port.flush();
				i += 1;
			}
			port.close();
		}
	}
}
