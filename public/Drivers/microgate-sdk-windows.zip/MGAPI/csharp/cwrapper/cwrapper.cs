﻿//
// HDLC/SDLC protocol sample
//
// Run on a port with loopback plug or loopback cable attached or
// enable internal loopback in ConfigurePort.
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Microgate;

namespace hdlc
{
	class cwrapper
	{
		private static bool exitProgram = false;

		static uint ConfigurePort(IntPtr handle)
		{
			uint rc;
			SerialApi.MGSL_PARAMS cfg = new SerialApi.MGSL_PARAMS();

			rc = SerialApi.MgslGetParams(handle, ref cfg);
			if (rc != 0)
			{
				Console.WriteLine("MgslGetParams() error={0}", rc);
				return rc;
			}

			// SDLC/HDLC serial protocol
			// loopback disabled
			// receive clock source  = external receive clock input
			// transmit clock source = external transmit clock input
			// NRZ serial encoding
			// output 19200Hz clock on AUXCLK output
			// use CRC16 to check frame contents
			// no HDLC address filtering (receive all)
			cfg.Mode = SerialApi.MGSL_MODE_HDLC;
			cfg.Loopback = 0;
			cfg.Flags = SerialApi.HDLC_FLAG_RXC_RXCPIN + SerialApi.HDLC_FLAG_TXC_TXCPIN;
			cfg.Encoding = SerialApi.HDLC_ENCODING_NRZ;
			cfg.ClockSpeed = 19200;
			cfg.CrcType = SerialApi.HDLC_CRC_16_CCITT;
			cfg.Addr = 0xff;

			rc = SerialApi.MgslSetParams(handle, ref cfg);
			if (rc != 0)
			{
				Console.WriteLine("MgslSetParams() error={0}", rc);
				return rc;
			}

			// set transmit idle pattern
			rc = SerialApi.MgslSetIdleMode(handle, SerialApi.HDLC_TXIDLE_ONES);
			if (rc != 0)
			{
				Console.WriteLine("MgslSetIdleMode() error={0}", rc);
			}

			// set blocked mode for MgslRead
			rc = SerialApi.MgslSetOption(handle, SerialApi.MGSL_OPT_RX_POLL, 0);
			if (rc != 0)
			{
				Console.WriteLine("MgslSetOption(MGSL_OPT_RX_POLL) error={0}", rc);
			}

			// ignore receive error indications
			rc = SerialApi.MgslSetOption(handle, SerialApi.MGSL_OPT_RX_ERROR_MASK, 1);
			if (rc != 0)
			{
				Console.WriteLine("MgslSetOption(MGSL_OPT_RX_ERROR_MASK) error={0}", rc);
			}

			// set blocked mode for MgslWrite and MgslWaitAllSent
			rc = SerialApi.MgslSetOption(handle, SerialApi.MGSL_OPT_TX_POLL, 0);
			if (rc != 0)
			{
				Console.WriteLine("MgslSetOption(MGSL_OPT_TX_POLL) error={0}", rc);
			}

			return rc;
		}

		// receive thread function
		public static void ReceiveFunction(object data)
		{
			IntPtr handle = (IntPtr)data;

			// turn on receiver
			SerialApi.MgslEnableReceiver(handle, 1);

			// receive until ctrl-c
			byte[] buf = new byte[4096];
			for (int i = 1; exitProgram == false; i++)
			{
				int count = SerialApi.MgslRead(handle, buf, buf.Length);
				if (count == 0)
				{
					Console.WriteLine("SerialApi.Read error, exit receive thread");
					break;
				}
				Console.WriteLine("<<< {0:D9}: received {1} bytes", i, count);
			}
		}

		// program entry point and send thread
		static void Main(string[] args)
		{
			uint rc;
			IntPtr handle;

			if (args.Length == 0)
			{
				Console.Write("\nYou must specify device name as argument.\n" +
					"Examples:\n" +
					"C:>hdlc MGMP4P2  (adapter #4 port #2 of multiport adapter)\n" +
					"C:>hdlc MGHDLC1  (single port adapter adapter #1)\n" +
					"Available device names are listed in the SyncLink branch\n" +
					"of the Windows device manager.\n\n");
				return;
			}

			Console.WriteLine("SDLC/HDLC sample running on {0}", args[0]);

			rc = SerialApi.MgslOpenByName(args[0], out handle);
			if (rc != 0)
			{
				Console.WriteLine("MgslOpenByName() error={0}", rc);
				return;
			}

			rc = ConfigurePort(handle);
			if (rc != 0)
			{
				Console.WriteLine("Configure() error={0}", rc);
				goto done;
			}

			Console.WriteLine("ctrl-c to exit");
			Console.CancelKeyPress += delegate(object sender, ConsoleCancelEventArgs e)
			{
				Console.WriteLine("ctrl-c pressed");
				e.Cancel = true;
				exitProgram = true;
				// cancel blocked MgslRead/MgslWrite calls
				SerialApi.MgslCancelReceive(handle);
				SerialApi.MgslCancelTransmit(handle);
			};

			// Start a thread that calls a parameterized static method.
			Thread receiveThread = new Thread(ReceiveFunction);
			receiveThread.Start(handle);

			// initialize send buffer
			byte[] buf = new byte[1024];
			for (int i = 0; i < buf.Length; i++)
			{
				buf[i] = (byte)i;
			}

			for (int i=0 ; exitProgram == false ; i++)
			{
				Console.WriteLine(">>> {0:D9}: send {1} bytes", i, buf.Length);
				int count = SerialApi.MgslWrite(handle, buf, buf.Length);
				if (count == 0)
				{
					Console.WriteLine("SerialApi.Write error");
					break;
				}
			}

			Console.WriteLine("wait for all data sent...");
			int error = SerialApi.MgslWaitAllSent(handle);
			if (error == 0)
			{
				Console.WriteLine("all data sent");
			}
			else
			{
				Console.WriteLine("MgslWaitAllSent error {0}", error);
			}

		done:
			rc = SerialApi.MgslClose(handle);
			if (rc != 0)
			{
				Console.WriteLine("MgslClose() error={0}", rc);
			}
		}
	}
}
