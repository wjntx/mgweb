﻿//
// C# wrapper for Microgate serial API
//
// This creates MgApi.dll that must be present for C# application.
// The application must include a reference to this assembly.
//

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;
using Microsoft.Win32;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;

namespace Microgate
{
	public unsafe class SerialApi
	{
		public const uint MGSL_MAX_PORTS = 200;
		public const uint HDLC_MAX_FRAME_SIZE = 65535;
		public const uint MAX_ASYNC_TRANSMIT = 4096;

		public static uint MGSL_MAKE_PORT_ID(uint AdapterNumber, uint PortNumber)
		{
			return ((AdapterNumber) + ((PortNumber) << 16));
		}

		public static uint MGSL_GET_ADAPTER(uint PortID)
		{
			return ((PortID) & 0xffff);
		}

		public static uint MGSL_GET_PORT(uint PortID)
		{
			return ((PortID) >> 16);
		}

		/*
		 * Trace event structure
		 *
		 * Time Stamp Format
		 *
		 * Bits <32..27>	Hour		5 Bits, range 0-23
		 * Bits <26..21>	Minutes		6 Bits, range 0-59
		 * Bits <20..15>	Seconds		6 Bits, range 0-59
		 * Bits <09..00>	Milliseconds	10 bits, range 0-999
		 */

		[StructLayout(LayoutKind.Sequential)]
		public struct MGSL_TRACE_EVENT_HEADER
		{
			public uint TimeStamp;
			public uint EventType;
			public ushort DataLength;
		};

		public struct MGSL_TRACE_EVENT
		{
			public uint TimeStamp;
			public uint EventType;
			public ushort DataLength;
			public fixed byte EventData[65535];
		}

		/*
		 * Trace levels for use with MgslSetTraceLevel
		 */
		public const uint TraceLevel_None     = 0x0000;
		public const uint TraceLevel_API      = 0x0001;
		public const uint TraceLevel_Status   = 0x0002;
		public const uint TraceLevel_Transmit = 0x0004;
		public const uint TraceLevel_Receive  = 0x0008;
		public const uint TraceLevel_Raw      = 0x0010;
		public const uint TraceLevel_Data     = 0x0020;
		public const uint TraceLevel_DataLink = 0x0040;
		public const uint TraceLevel_Error    = 0x0100;
		public const uint TraceLevel_Info     = 0x0200;
		public const uint TraceLevel_Detail   = 0x0400;

		public const uint EventType_None      = 0;

		public const uint TransmitEvent_Enable    = 1;
		public const uint TransmitEvent_Disable   = 2;
		public const uint TransmitEvent_Start     = 3;
		public const uint TransmitEvent_StatusIrq = 4;
		public const uint TransmitEvent_DataIrq   = 5;
		public const uint TransmitEvent_DmaIrq    = 6;

		public const uint ReceiveEvent_Enable     = 7;
		public const uint ReceiveEvent_Disable    = 8;
		public const uint ReceiveEvent_StatusIrq  = 9;
		public const uint ReceiveEvent_DataIrq    = 10;
		public const uint ReceiveEvent_DmaIrq     = 11;

		public const uint StatusEvent_StatusChange = 12;

		public const uint ApiEvent_SetParamsCall           = 13;
		public const uint ApiEvent_SetParamsReturn         = 14;
		public const uint ApiEvent_GetParamsCall           = 15;
		public const uint ApiEvent_GetParamsReturn         = 16;
		public const uint ApiEvent_SetSerialSignalsCall    = 17;
		public const uint ApiEvent_SetSerialSignalsReturn  = 18;
		public const uint ApiEvent_GetSerialSignalsCall    = 19;
		public const uint ApiEvent_GetSerialSignalsReturn  = 20;
		public const uint ApiEvent_WaitEventCall           = 21;
		public const uint ApiEvent_WaitEventReturn         = 22;
		public const uint ApiEvent_WaitEventComplete       = 23;
		public const uint ApiEvent_CancelWaitEventCall     = 24;
		public const uint ApiEvent_CancelWaitEventReturn   = 25;
		public const uint ApiEvent_EnableTransmitterCall   = 26;
		public const uint ApiEvent_EnableTransmitterReturn = 27;
		public const uint ApiEvent_TransmitCall            = 28;
		public const uint ApiEvent_TransmitReturn          = 29;
		public const uint ApiEvent_TransmitComplete        = 30;
		public const uint ApiEvent_CancelTransmitCall      = 31;
		public const uint ApiEvent_CancelTransmitReturn    = 32;
		public const uint ApiEvent_SetIdleModeCall         = 33;
		public const uint ApiEvent_SetIdleModeReturn       = 34;
		public const uint ApiEvent_EnableReceiverCall      = 35;
		public const uint ApiEvent_EnableReceiverReturn    = 36;
		public const uint ApiEvent_ReceiveCall             = 37;
		public const uint ApiEvent_ReceiveReturn           = 38;
		public const uint ApiEvent_ReceiveComplete         = 39;
		public const uint ApiEvent_CancelReceiveCall       = 40;
		public const uint ApiEvent_CancelReceiveReturn     = 41;
		public const uint ApiEvent_ResetTraceBuffersCall   = 42;
		public const uint ApiEvent_ResetTraceBuffersReturn = 43;
		public const uint ApiEvent_SetTraceLevelCall       = 44;
		public const uint ApiEvent_SetTraceLevelReturn     = 45;
		public const uint ApiEvent_GetTraceLevelCall       = 46;
		public const uint ApiEvent_GetTraceLevelReturn     = 47;
		public const uint DataEvent_TransmitData           = 48;
		public const uint DataEvent_ReceiveData            = 49;
		public const uint EventType_BufferOverflow         = 50;
		public const uint EventType_FormatRaw              = 51;
		public const uint ApiEvent_GetAssignedResourcesCall = 52;
		public const uint ApiEvent_GetAssignedResourcesReturn = 53;
		public const uint ApiEvent_LoopModeSendDoneCall       = 54;
		public const uint ApiEvent_LoopModeSendDoneReturn     = 55;
		public const uint EventType_DLEvent                   = 56;
		public const uint EventType_DLState                   = 57;
		public const uint EventType_DLFrame                   = 58;
		public const uint EventType_DLTxActive                = 59;
		public const uint EventType_DLTxIdle                  = 60;
		public const uint EventType_DLTxLoopComplete          = 61;
		public const uint EventType_DLGaLoopComplete          = 62;
		public const uint EventType_DLTxTimeout               = 63;
		public const uint ApiEvent_DlAllocateCall             = 64;
		public const uint ApiEvent_DlAllocateReturn           = 65;
		public const uint ApiEvent_DlCallCall                 = 66;
		public const uint ApiEvent_DlCallReturn               = 67;
		public const uint ApiEvent_DlCancelWaitCall           = 68;
		public const uint ApiEvent_DlCancelWaitReturn         = 69;
		public const uint ApiEvent_DlFreeCall                 = 70;
		public const uint ApiEvent_DlFreeReturn               = 71;
		public const uint ApiEvent_DlGetParamsCall            = 72;
		public const uint ApiEvent_DlGetParamsReturn          = 73;
		public const uint ApiEvent_DlGetPhysParamsCall        = 74;
		public const uint ApiEvent_DlGetPhysParamsReturn      = 75;
		public const uint ApiEvent_DlGetStatsCall             = 76;
		public const uint ApiEvent_DlGetStatsReturn           = 77;
		public const uint ApiEvent_DlResetStatsCall           = 78;
		public const uint ApiEvent_DlResetStatsReturn         = 79;
		public const uint ApiEvent_DlSetParamsCall            = 80;
		public const uint ApiEvent_DlSetParamsReturn          = 81;
		public const uint ApiEvent_DlSetPhysParamsCall        = 82;
		public const uint ApiEvent_DlSetPhysParamsReturn      = 83;
		public const uint ApiEvent_DlWaitCall                 = 84;
		public const uint ApiEvent_DlWaitComplete             = 85;
		public const uint ApiEvent_DlWaitReturn               = 86;
		public const uint ApiEvent_DiSetParamsCall            = 87;
		public const uint ApiEvent_DiSetParamsReturn          = 88;
		public const uint ApiEvent_DiGetParamsCall            = 89;
		public const uint ApiEvent_DiGetParamsReturn          = 90;
		public const uint ApiEvent_DiSetSerialSignalsCall     = 91;
		public const uint ApiEvent_DiSetSerialSignalsReturn   = 92;
		public const uint ApiEvent_DiGetSerialSignalsCall     = 93;
		public const uint ApiEvent_DiGetSerialSignalsReturn   = 94;
		public const uint ApiEvent_DiMonitorEventsCall        = 95;
		public const uint ApiEvent_DiMonitorEventsReturn      = 96;
		public const uint ApiEvent_DiEventReady               = 97;
		public const uint ApiEvent_DiEnableTransmitterCall    = 98;
		public const uint ApiEvent_DiEnableTransmitterReturn  = 99;
		public const uint ApiEvent_DiTransmitCall             = 100;
		public const uint ApiEvent_DiTransmitReturn           = 101;
		public const uint ApiEvent_DiTransmitComplete         = 102;
		public const uint ApiEvent_DiCancelTransmitCall       = 103;
		public const uint ApiEvent_DiCancelTransmitReturn     = 104;
		public const uint ApiEvent_DiSetIdleModeCall          = 105;
		public const uint ApiEvent_DiSetIdleModeReturn        = 106;
		public const uint ApiEvent_DiEnableReceiverCall       = 107;
		public const uint ApiEvent_DiEnableReceiverReturn     = 108;
		public const uint ApiEvent_DiReceiveCall              = 109;
		public const uint ApiEvent_DiReceiveReturn            = 110;
		public const uint ApiEvent_DiReceiveReady             = 111;
		public const uint ApiEvent_DiResetTraceBuffersCall    = 112;
		public const uint ApiEvent_DiResetTraceBuffersReturn  = 113;
		public const uint ApiEvent_DiSetTraceLevelCall        = 114;
		public const uint ApiEvent_DiSetTraceLevelReturn      = 115;
		public const uint ApiEvent_DiGetTraceLevelCall        = 116;
		public const uint ApiEvent_DiGetTraceLevelReturn      = 117;
		public const uint ApiEvent_DiLoopModeSendDoneCall     = 118;
		public const uint ApiEvent_DiLoopModeSendDoneReturn   = 119;
		public const uint ApiEvent_DiDlAllocateCall           = 120;
		public const uint ApiEvent_DiDlAllocateReturn         = 121;
		public const uint ApiEvent_DiDlCallCall               = 122;
		public const uint ApiEvent_DiDlCallReturn             = 123;
		public const uint ApiEvent_DiDlFreeCall               = 124;
		public const uint ApiEvent_DiDlFreeReturn             = 125;
		public const uint ApiEvent_DiDlGetParamsCall          = 126;
		public const uint ApiEvent_DiDlGetParamsReturn        = 127;
		public const uint ApiEvent_DiDlGetPhysParamsCall      = 128;
		public const uint ApiEvent_DiDlGetPhysParamsReturn    = 129;
		public const uint ApiEvent_DiDlGetStatsCall           = 130;
		public const uint ApiEvent_DiDlGetStatsReturn         = 131;
		public const uint ApiEvent_DiDlResetStatsCall         = 132;
		public const uint ApiEvent_DiDlResetStatsReturn       = 133;
		public const uint ApiEvent_DiDlSetParamsCall          = 134;
		public const uint ApiEvent_DiDlSetParamsReturn        = 135;
		public const uint ApiEvent_DiDlSetPhysParamsCall      = 136;
		public const uint ApiEvent_DiDlSetPhysParamsReturn    = 137;
		public const uint ApiEvent_DiDlWaitCall               = 138;
		public const uint ApiEvent_DiDlWaitReturn             = 139;
		public const uint ApiEvent_DiDlReady                  = 140;
		public const uint ApiEvent_DlSetAddrListCall          = 141;
		public const uint ApiEvent_DlSetAddrListReturn        = 142;
		public const uint ApiEvent_DiDlSetAddrListCall        = 143;
		public const uint ApiEvent_DiDlSetAddrListReturn      = 144;
		public const uint ApiEvent_SetOptionCall              = 145;
		public const uint ApiEvent_SetOptionReturn            = 146;
		public const uint ApiEvent_GetOptionCall              = 147;
		public const uint ApiEvent_GetOptionReturn            = 148;
		public const uint ApiEvent_DiSetOptionCall            = 149;
		public const uint ApiEvent_DiSetOptionReturn          = 150;
		public const uint ApiEvent_DiGetOptionCall            = 151;
		public const uint ApiEvent_DiGetOptionReturn          = 152;
		public const uint ApiEvent_SetGpioCall                = 153;
		public const uint ApiEvent_SetGpioReturn              = 154;
		public const uint ApiEvent_GetGpioCall                = 155;
		public const uint ApiEvent_GetGpioReturn              = 156;
		public const uint ApiEvent_WaitGpioCall               = 157;
		public const uint ApiEvent_WaitGpioReturn             = 158;
		public const uint ApiEvent_WaitGpioComplete           = 159;
		public const uint ApiEvent_CancelWaitGpioCall         = 160;
		public const uint ApiEvent_CancelWaitGpioReturn       = 161;
		public const uint ApiEvent_ReadCall                   = 162;
		public const uint ApiEvent_ReadReturn                 = 163;
		public const uint ApiEvent_WriteCall                  = 164;
		public const uint ApiEvent_WriteReturn                = 165;
		public const uint ApiEvent_WaitAllSentCall            = 166;
		public const uint ApiEvent_WaitAllSentReturn          = 167;
		public const uint ApiEvent_ReadWithStatusCall         = 168;
		public const uint ApiEvent_ReadWithStatusReturn       = 169;

		public const uint EventType_UserBase                  = 0x80000000;
		public const uint EventType_UserMessage               = 0x80000001;

		public const uint MGSL_INTERFACE_MASK      = 0xf;
		public const uint MGSL_INTERFACE_DISABLE   = 0;
		public const uint MGSL_INTERFACE_RS232     = 1;
		public const uint MGSL_INTERFACE_V35       = 2;
		public const uint MGSL_INTERFACE_RS422     = 3;
		public const uint MGSL_INTERFACE_RS530A    = 4;
		public const uint MGSL_RTS_DRIVER_CONTROL  = 0x0010;
		public const uint MGSL_NO_TERMINATION      = 0x0020;

		public const uint MICROGATE_VENDOR_ID       = 0x13c0;
		public const uint SYNCLINK_DEVICE_ID        = 0x0010;
		public const uint SYNCLINK_SCC_DEVICE_ID    = 0x0020;
		public const uint SYNCLINK_SCA_DEVICE_ID    = 0x0030;
		public const uint SYNCLINK_T1_DEVICE_ID     = 0x0040;
		public const uint SYNCLINK_PCCARD_DEVICE_ID = 0x0050;
		public const uint SYNCLINK_MSC_DEVICE_ID    = 0x0060;
		public const uint SYNCLINK_GT_DEVICE_ID     = 0x0070;
		public const uint SYNCLINK_GT4_DEVICE_ID    = 0x0080;
		public const uint SYNCLINK_AC_DEVICE_ID     = 0x0090;
		public const uint SYNCLINK_GT2_DEVICE_ID    = 0x00A0;
		public const uint SYNCLINK_USB_DEVICE_ID    = 0x00B0;
		public const uint MGSL_MAX_SERIAL_NUMBER    = 30;

		public const uint ASYNC_PARITY_NONE = 0;
		public const uint ASYNC_PARITY_EVEN = 1;
		public const uint ASYNC_PARITY_ODD  = 2;

		public const ushort HDLC_FLAG_SHARE_ZERO  = 0x0010;
		public const ushort HDLC_FLAG_AUTO_CTS    = 0x0020;
		public const ushort HDLC_FLAG_AUTO_DCD    = 0x0040;
		public const ushort HDLC_FLAG_AUTO_RTS    = 0x0080;
		public const ushort HDLC_FLAG_RXC_DPLL    = 0x0100;
		public const ushort HDLC_FLAG_RXC_BRG     = 0x0200;
		public const ushort HDLC_FLAG_RXC_TXCPIN  = 0x8000;
		public const ushort HDLC_FLAG_RXC_RXCPIN  = 0x0000;
		public const ushort HDLC_FLAG_TXC_DPLL    = 0x0400;
		public const ushort HDLC_FLAG_TXC_BRG     = 0x0800;
		public const ushort HDLC_FLAG_TXC_TXCPIN  = 0x0000;
		public const ushort HDLC_FLAG_TXC_RXCPIN  = 0x0008;
		public const ushort HDLC_FLAG_DPLL_DIV8   = 0x1000;
		public const ushort HDLC_FLAG_DPLL_DIV16  = 0x2000;
		public const ushort HDLC_FLAG_DPLL_DIV32  = 0x0000;
		public const ushort HDLC_FLAG_RXC_INV     = 0x0002;
		public const ushort HDLC_FLAG_TXC_INV     = 0x0004;

		public const ushort HDLC_CRC_NONE      = 0;
		public const ushort HDLC_CRC_16_CCITT  = 1;
		public const ushort HDLC_CRC_32_CCITT  = 2;
		public const ushort HDLC_CRC_MODE      = 0x00ff;
		public const ushort HDLC_CRC_RETURN_CRCERR_FRAME = 0x8000;
		public const ushort HDLC_CRC_RETURN_CRC = 0x4000;

		public const uint HDLC_TXIDLE_FLAGS          = 0;
		public const uint HDLC_TXIDLE_ALT_ZEROS_ONES = 1;
		public const uint HDLC_TXIDLE_ZEROS          = 2;
		public const uint HDLC_TXIDLE_ONES           = 3;
		public const uint HDLC_TXIDLE_ALT_MARK_SPACE = 4;
		public const uint HDLC_TXIDLE_SPACE          = 5;
		public const uint HDLC_TXIDLE_MARK           = 6;
		public const uint HDLC_TXIDLE_CUSTOM_8       = 0x10000000;
		public const uint HDLC_TXIDLE_CUSTOM_16      = 0x20000000;

		public const byte HDLC_ENCODING_NRZ                = 0;
		public const byte HDLC_ENCODING_NRZB               = 1;
		public const byte HDLC_ENCODING_NRZI_MARK          = 2;
		public const byte HDLC_ENCODING_NRZI_SPACE         = 3;
		public const byte HDLC_ENCODING_NRZI               = 3;
		public const byte HDLC_ENCODING_BIPHASE_MARK       = 4;
		public const byte HDLC_ENCODING_BIPHASE_SPACE      = 5;
		public const byte HDLC_ENCODING_BIPHASE_LEVEL      = 6;
		public const byte HDLC_ENCODING_DIFF_BIPHASE_LEVEL = 7;

		public const byte HDLC_PREAMBLE_LENGTH_8BITS  = 0;
		public const byte HDLC_PREAMBLE_LENGTH_16BITS = 1;
		public const byte HDLC_PREAMBLE_LENGTH_32BITS = 2;
		public const byte HDLC_PREAMBLE_LENGTH_64BITS = 3;

		public const byte HDLC_PREAMBLE_PATTERN_NONE  = 0;
		public const byte HDLC_PREAMBLE_PATTERN_ZEROS = 1;
		public const byte HDLC_PREAMBLE_PATTERN_FLAGS = 2;
		public const byte HDLC_PREAMBLE_PATTERN_10    = 3;
		public const byte HDLC_PREAMBLE_PATTERN_01    = 4;
		public const byte HDLC_PREAMBLE_PATTERN_ONES  = 5;

		public const uint MGSL_MODE_ASYNC         = 1;
		public const uint MGSL_MODE_HDLC          = 2;
		public const uint MGSL_MODE_MONOSYNC      = 3;
		public const uint MGSL_MODE_BISYNC        = 4;
		public const uint MGSL_MODE_EXTERNALSYNC  = 6;
		public const uint MGSL_MODE_RAW           = 6;
		public const uint MGSL_MODE_TDM           = 7;

		public const uint MGSL_BUS_TYPE_ISA    = 1;
		public const uint MGSL_BUS_TYPE_EISA   = 2;
		public const uint MGSL_BUS_TYPE_PCI    = 5;
		public const uint MGSL_BUS_TYPE_PCMCIA = 8;

		public const byte SerialSignal_DCD = 0x01;  /* Data Carrier Detect */
		public const byte SerialSignal_TXD = 0x02;  /* Transmit Data */
		public const byte SerialSignal_RI  = 0x04;  /* Ring Indicator */
		public const byte SerialSignal_RXD = 0x08;  /* Receive Data */
		public const byte SerialSignal_CTS = 0x10;  /* Clear to Send */
		public const byte SerialSignal_RTS = 0x20;  /* Request to Send */
		public const byte SerialSignal_DSR = 0x40;  /* Data Set Ready */
		public const byte SerialSignal_DTR = 0x80;  /* Data Terminal Ready */

		public const uint ERROR_IO_PENDING = 997;

		// definitions for building MGSL_OPT_TDM value

		// TDM sync to data delay [bits 19:18]
		public const uint TDM_SYNC_DELAY_NONE = 0;
		public const uint TDM_SYNC_DELAY_1BIT = 1 << 18;
		public const uint TDM_SYNC_DELAY_2BITS = 2 << 18;

		// TDM transmit sync width [bit 17]
		public const uint TDM_TX_SYNC_WIDTH_SLOT = 0;
		public const uint TDM_TX_SYNC_WIDTH_BIT = 1 << 17;

		// TDM Sync polarity [bit 16]
		public const uint TDM_SYNC_POLARITY_NORMAL = 0;
		public const uint TDM_SYNC_POLARITY_INVERT = 1 << 16;

		// TDM slot size [bits 2:0]
		public const uint TDM_SLOT_SIZE_8BITS = 1;
		public const uint TDM_SLOT_SIZE_12BITS = 2;
		public const uint TDM_SLOT_SIZE_16BITS = 3;
		public const uint TDM_SLOT_SIZE_20BITS = 4;
		public const uint TDM_SLOT_SIZE_24BITS = 5;
		public const uint TDM_SLOT_SIZE_28BITS = 6;
		public const uint TDM_SLOT_SIZE_32BITS = 7;

		[StructLayout(LayoutKind.Sequential)]
		public struct MGSL_PARAMS
		{
			public uint Mode;
			public byte Loopback;
			public ushort Flags;
			public byte Encoding;
			public uint ClockSpeed;
			public byte Addr;
			public ushort CrcType;
			public byte PreambleLength;
			public byte PreamblePattern;
			public uint DataRate;
			public byte DataBits;
			public byte StopBits;
			public byte Parity;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct MGSL_PORT
		{
			public uint PortID;
			public uint DeviceID;
			public uint BusType;
			public fixed byte DeviceName[25];
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct MGSL_RECEIVE_REQUEST
		{
			public uint Status;	/* returned request status */
			public uint DataLength;	/* returned data length */
			public fixed byte DataBuffer[1];
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct MGSL_PORT_CONFIG_EX
		{
			public uint Size;
			public uint BaseAddress;
			public uint IrqLevel;
			public uint DmaChannel;
			public uint BusType;
			public uint BusNumber;
			public uint DeviceID;
			public uint MaxFrameSize;
			public uint Flags;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct MGSL_ASSIGNED_RESOURCES
		{
			public uint BusType;
			public uint BusNumber;
			public uint DeviceNumber;
			public uint IrqLevel;
			public uint DmaChannel;
			public uint IoAddress1;
			public uint IoAddress2;
			public uint IoAddress3;
			public uint MemAddress1;
			public uint MemAddress2;
			public uint MemAddress3;
			public ushort DeviceId;
			public ushort SubsystemId;
			public fixed byte SerialNumber[30];
		}

		public static uint BUSNUM(uint a) { return ((a) & 0xffff); }
		public static uint DEVNUM(uint a) { return ((a) >> 16); }
		public static uint BUSDEV(uint a, uint b) { return ((uint)(a) + (((uint)(b)) << 16)); }

		[StructLayout(LayoutKind.Sequential)]
		public struct GPIO_DESC
		{
			public uint state;
			public uint smask;
			public uint dir;
			public uint dmask;
		}

		/*
		 * Option IDs used with MgslSetOption/MgslGetOption
		 */
		public const uint MGSL_OPT_RX_DISCARD_TOO_LARGE  = 1;
		public const uint MGSL_OPT_UNDERRUN_RETRY_LIMIT  = 2;
		public const uint MGSL_OPT_ENABLE_LOCALLOOPBACK  = 3;
		public const uint MGSL_OPT_ENABLE_REMOTELOOPBACK = 4;
		public const uint MGSL_OPT_JCR                   = 5;
		public const uint MGSL_OPT_INTERFACE             = 6;
		public const uint MGSL_OPT_RTS_DRIVER_CONTROL    = 7;
		public const uint MGSL_OPT_RX_ERROR_MASK         = 8;
		public const uint MGSL_OPT_CLOCK_SWITCH          = 9;
		public const uint MGSL_OPT_CLOCK_BASE_FREQ       = 10;
		public const uint MGSL_OPT_HALF_DUPLEX           = 11;
		public const uint MGSL_OPT_MSB_FIRST             = 12;
		public const uint MGSL_OPT_RX_COUNT              = 13;
		public const uint MGSL_OPT_TX_COUNT              = 14;
		public const uint MGSL_OPT_CUSTOM                = 15;
		public const uint MGSL_OPT_RX_POLL               = 16;
		public const uint MGSL_OPT_TX_POLL               = 17;
		public const uint MGSL_OPT_NO_TERMINATION        = 18;
		public const uint MGSL_OPT_TDM                   = 19;
		public const uint MGSL_OPT_AUXCLK_ENABLE         = 20;
		public const uint MGSL_OPT_UNDERRUN_COUNT        = 21;
		public const uint MGSL_OPT_TX_IDLE_COUNT         = 22;
		public const uint MGSL_OPT_DPLL_RESET            = 23;
		public const uint MGSL_OPT_RS422_OE              = 24;

		/*
		 * Returned status values for MgslReceive
		 */
		public const uint RxStatus_OK             = 0;
		public const uint RxStatus_CrcError       = 1;
		public const uint RxStatus_FifoOverrun    = 2;
		public const uint RxStatus_ShortFrame     = 3;
		public const uint RxStatus_Abort          = 4;
		public const uint RxStatus_BufferOverrun  = 5;
		public const uint RxStatus_Cancel         = 6;
		public const uint RxStatus_BufferTooSmall = 7;

		/*
		 * Returned status values for MgslTransmit
		 */
		public const uint TxStatus_OK         = 0;
		public const uint TxStatus_Underrun   = 1;
		public const uint TxStatus_Cancel     = 2;
		public const uint TxStatus_CtsFailure = 3;

		/*
		 * Event bit flags for use with MgslWaitEvent
		 */
		public const uint MgslEvent_DsrActive    = 0x0001;
		public const uint MgslEvent_DsrInactive  = 0x0002;
		public const uint MgslEvent_Dsr          = 0x0003;
		public const uint MgslEvent_CtsActive    = 0x0004;
		public const uint MgslEvent_CtsInactive  = 0x0008;
		public const uint MgslEvent_Cts          = 0x000c;
		public const uint MgslEvent_DcdActive    = 0x0010;
		public const uint MgslEvent_DcdInactive  = 0x0020;
		public const uint MgslEvent_Dcd          = 0x0030;
		public const uint MgslEvent_RiActive     = 0x0040;
		public const uint MgslEvent_RiInactive   = 0x0080;
		public const uint MgslEvent_Ri           = 0x00c0;
		public const uint MgslEvent_ExitHuntMode = 0x0100;
		public const uint MgslEvent_IdleReceived = 0x0200;

		/*
		 * Return diagnostics status for MgslOpenDiagnostics
		 */
		public const uint DiagStatus_OK                     = 0;
		public const uint DiagStatus_AddressFailure         = 1;
		public const uint DiagStatus_AddressConflict        = 2;
		public const uint DiagStatus_IrqFailure             = 3;
		public const uint DiagStatus_IrqConflict            = 4;
		public const uint DiagStatus_DmaFailure             = 5;
		public const uint DiagStatus_DmaConflict            = 6;
		public const uint DiagStatus_PciAdapterNotFound     = 7;
		public const uint DiagStatus_CantAssignPciResources = 8;
		public const uint DiagStatus_CantAssignPciMemAddr   = 9;
		public const uint DiagStatus_CantAssignPciIoAddr    = 10;
		public const uint DiagStatus_CantAssignPciIrq       = 11;
		public const uint DiagStatus_MemoryError            = 12;
		public const uint DiagStatus_MemAllocFailure        = 13;


		/* data link layer parameters */

		/* used with MgslDlGetParams() and MgslDlSetParams() */

		public const uint MGSL_MAX_ADDRESS = 16;

		[StructLayout(LayoutKind.Sequential)]
		public struct MGSL_DLPARAMS
		{
			public IntPtr Link;	/* link instance identifier */

			public uint Flags;	/* bitmask of link layer flags */

			public fixed byte LocalAddr[16];	/* local address */
			public uint LocalAddrLength;

			public fixed byte RemoteAddr[16];	/* remote address */
			public uint RemoteAddrLength;

			public fixed byte BcastAddr[16];	/* broadcast command address */
			public uint BcastAddrLength;

			public uint TransmitWindow;	/* maximum outstanding I-frames */
			public uint RetryLimit;		/* maximum number of retransmissions */
			public uint MaxInfoField;	/* max info field size in bytes */

			public uint ResponseTimer;	/* transmit/retransmit timer (seconds)*/
			public uint IdleTimer;		/* idle timeout (seconds) */

			public uint Reserved1;	/* must be zero */
			public uint Reserved2;	/* must be zero */
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct MGSL_DLPHYSPARAMS
		{
			public uint Flags;              /* bitmask of link layer flags */
			public uint TransmitTimeout;    /* transmit timeout (milliseconds) */
			public uint TxActiveIdle;       /* idle mode for transmit active */
			public ushort CtsTransmitDelay; /* cts transmit delay (milliseconds) */
			public ushort InterframeDelay;  /* interframe delay (milliseconds) */
			public ushort RtsDropDelay;     /* rts drop delay (milliseconds) */
			public ushort TurnaroundDelay;  /* turnaround delay (milliseconds) */
		}

		/* data link layer primitive */
		/* used with MgslDlCall and MgslDlWait */

		[StructLayout(LayoutKind.Sequential)]
		public struct MGSL_DLPRIMITIVE
		{
			public uint Link;
			public uint Type;
			public uint Flags;
			public uint Size;
			public fixed byte Buffer[1];
		}

		/* used with DLINDICATION_RAWDATA */
		[StructLayout(LayoutKind.Sequential)]
		public struct MGSL_RAWDATA
		{
			public fixed byte Address[16];
			public uint AddressLength;
			public uint DataLength;
			public fixed byte Data[1];
		}

		/* data link layer statistics */
		/* used with MgslDlGetStats() */

		[StructLayout(LayoutKind.Sequential)]
		public struct MGSL_DLSTATS
		{
			public IntPtr Link; /* link instance identifier */

			public uint State;  /* link layer connection state */
			public uint Status; /* bit mapped flags for link status */

			public uint RxREJ;  /* received reject frames */
			public uint RxFRMR; /* received frame rejects */
			public uint RxInvalidControl; /* rx FRMR with invalid/unsupported ctrl field */
			public uint RxInvalidInfo;    /* rx FRMR with info field not allowed */
			public uint RxInvalidISize;   /* rx FRMR with info field too big  */
			public uint RxInvalidNr;      /* rx FRMR with invalid NR sequence number */
			public uint RxRSET;           /* rx RSET frames */
			public uint RxTEST;           /* rx TEST frames */

			public uint TxREJ;            /* transmitted reject frames */
			public uint TxFRMR;           /* transmitted frame rejects */
			public uint TxInvalidControl; /* tx FRMR with invalid/unsupported ctrl field */
			public uint TxInvalidInfo;    /* tx FRMR with info field not allowed */
			public uint TxInvalidISize;   /* tx FRMR with info field too big  */
			public uint TxInvalidNr;      /* tx FRMR with invalid NR sequence number */
			public uint TxRSET;           /* tx RSET frames */
			public uint TxTEST;           /* tx TEST frames */

			public uint ResponseTimeouts;
			public uint IdleTimeouts;

			public uint TxPending;        /* I-frames pending transmission */
			public uint TxPendingAck;     /* I-frames pending acknowledgement */
			public uint TxAcked;          /* Acknowledged I-frames */

			public uint RxInfo;           /* received info frames */
			public uint RxInfoBytes;      /* received info field bytes */
			public uint RxUI;             /* received UI frames */
			public uint RxUIBytes;        /* received UI info field bytes */

			public uint Reserved1;        /* must be zero */
			public uint Reserved2;        /* must be zero */
		}

		/* data link address lists */
		public const uint ADDRESS_LOCAL  = 0;
		public const uint ADDRESS_REMOTE = 1;

		[StructLayout(LayoutKind.Sequential)]
		public struct MGSL_ADDRESS_LIST
		{
			public uint Link;    /* data link identifier */
			public uint ListID;  /* ADDRESS_REMOTE or ADDRESS_LOCAL */
			public uint Length;  /* length in bytes of each address */
			public uint Count;   /* count of addresses in data */
			public fixed byte Data[1]; /* variable length set of addresses */
		}

		/* data link layer states */
		public const uint DLSTATE_RELEASED       = 0;
		public const uint DLSTATE_WAIT_INIT      = 1;
		public const uint DLSTATE_INIT_MODE      = 2;
		public const uint DLSTATE_WAIT_ESTABLISH = 3;
		public const uint DLSTATE_WAIT_RELEASE   = 4;
		public const uint DLSTATE_ESTABLISHED    = 5;
		public const uint DLSTATE_TIMER_RECOVERY = 6;
		public const uint DLSTATE_COUNT          = 7;


		/* data link layer events */

		public const uint DLEVENT_ESTABLISH_REQ    = 0;
		public const uint DLEVENT_RELEASE_REQ      = 1;
		public const uint DLEVENT_INIT_MODE_REQ    = 2;
		public const uint DLEVENT_DATA_REQ         = 3;
		public const uint DLEVENT_UNITDATA_REQ     = 4;
		public const uint DLEVENT_IFRAME_QUEUED    = 5;
		public const uint DLEVENT_UIFRAME_QUEUED   = 6;
		public const uint DLEVENT_SNRM             = 7;
		public const uint DLEVENT_SNRME            = 8;
		public const uint DLEVENT_SARM             = 9;
		public const uint DLEVENT_SARME            = 10;
		public const uint DLEVENT_SABM             = 11;
		public const uint DLEVENT_SABME            = 12;
		public const uint DLEVENT_DISC             = 13;
		public const uint DLEVENT_UA               = 14;
		public const uint DLEVENT_DM               = 15;
		public const uint DLEVENT_UI               = 16;
		public const uint DLEVENT_FRMR             = 17;
		public const uint DLEVENT_RR               = 18;
		public const uint DLEVENT_REJ              = 19;
		public const uint DLEVENT_RNR              = 20;
		public const uint DLEVENT_IFRAME           = 21;
		public const uint DLEVENT_SIM              = 22;
		public const uint DLEVENT_RIM              = 23;
		public const uint DLEVENT_RSET             = 24;
		public const uint DLEVENT_SREJ             = 25;
		public const uint DLEVENT_RD               = 26;
		public const uint DLEVENT_UP               = 27;
		public const uint DLEVENT_XID              = 28;
		public const uint DLEVENT_TEST             = 29;
		public const uint DLEVENT_CFGR             = 30;
		public const uint DLEVENT_BCN              = 31;
		public const uint DLEVENT_RESPONSE_TIMEOUT = 32;
		public const uint DLEVENT_IDLE_TIMEOUT     = 33;
		public const uint DLEVENT_OWN_RCV_BUSY     = 34;
		public const uint DLEVENT_OWN_RCV_READY    = 35;
		public const uint DLEVENT_RETRY_LIMIT      = 36;
		public const uint DLEVENT_INVALID_CONTROL  = 37;
		public const uint DLEVENT_INVALID_INFO     = 38;
		public const uint DLEVENT_INVALID_ISIZE    = 39;
		public const uint DLEVENT_INVALID_NR       = 40;
		public const uint DLEVENT_COUNT            = 41;

		/* data link layer flag/status bits */

		public const uint DLFLAG_SNRM             = 0x00000001;
		public const uint DLFLAG_SNRME            = 0x00000002;
		public const uint DLFLAG_NRM              = (DLFLAG_SNRM+DLFLAG_SNRME);
		public const uint DLFLAG_SARM             = 0x00000004;
		public const uint DLFLAG_SARME            = 0x00000008;
		public const uint DLFLAG_ARM              = (DLFLAG_SARM+DLFLAG_SARME);
		public const uint DLFLAG_SABM             = 0x00000010;
		public const uint DLFLAG_SABME            = 0x00000020;
		public const uint DLFLAG_ABM              = (DLFLAG_SABM+DLFLAG_SABME);
		public const uint DLFLAG_SREJ             = 0x00000040;
		public const uint DLFLAG_RSET             = 0x00000080;
		public const uint DLFLAG_XID              = 0x00000100;
		public const uint DLFLAG_TEST             = 0x00000200;
		public const uint DLFLAG_UP               = 0x00000400;
		public const uint DLFLAG_SIM              = 0x00000800;
		public const uint DLFLAG_RD               = 0x00001000;
		public const uint DLFLAG_REJ              = 0x00002000;
		public const uint DLFLAG_BCN              = 0x00004000;
		public const uint DLFLAG_CFGR             = 0x00008000;
		public const uint DLFLAG_PRIMARY          = 0x00010000;
		public const uint DLFLAG_DEFAULT          = 0x00020000;
		public const uint DLFLAG_DUPLEX           = 0x00040000;
		public const uint DLFLAG_MULTI_SREJ       = 0x00080000;
		public const uint DLFLAG_ENABLE           = 0x00100000;
		public const uint DLFLAG_ACCEPT           = 0x00200000;
		public const uint DLFLAG_BROADCAST        = 0x00400000;
		public const uint DLFLAG_POLL             = 0x00800000;
		public const uint DLFLAG_CANCEL           = 0x01000000;
		public const uint DLFLAG_ERROR            = DLFLAG_CANCEL;
		public const uint DLFLAG_ALL_ADDRESS      = 0x02000000;
		public const uint DLFLAG_DEFAULT_COMMAND  = DLFLAG_ALL_ADDRESS;
		public const uint DLFLAG_DEFAULT_RESPONSE = 0x04000000;
		public const uint DLFLAG_INLINE_ADDRESS   = 0x08000000;
		public const uint DLFLAG_MANUAL_XID       = 0x10000000;
		public const uint DLFLAG_NO_PF            = 0x20000000;
		public const uint DLFLAG_AUTO_ADDRESS     = 0x40000000;

		public const uint DLPHYSFLAG_LOOP_CONTROLLER  = 0x00000001;
		public const uint DLPHYSFLAG_EXTENDED_ADDRESS = 0x00000002;

		public const uint DLSTATUS_SNRM               = 0x00000001;
		public const uint DLSTATUS_SNRME              = 0x00000002;
		public const uint DLSTATUS_NRM                = (DLSTATUS_SNRM+DLSTATUS_SNRME);
		public const uint DLSTATUS_SARM               = 0x00000004;
		public const uint DLSTATUS_SARME              = 0x00000008;
		public const uint DLSTATUS_ARM                = (DLSTATUS_SARM+DLSTATUS_SARME);
		public const uint DLSTATUS_SABM               = 0x00000010;
		public const uint DLSTATUS_SABME              = 0x00000020;
		public const uint DLSTATUS_ABM                = (DLSTATUS_SABM+DLSTATUS_SABME);
		public const uint DLSTATUS_PEER_RCV_BUSY      = 0x00000040;
		public const uint DLSTATUS_REJ_RECOVERY       = 0x00000080;
		public const uint DLSTATUS_OWN_RCV_BUSY       = 0x00000100;
		public const uint DLSTATUS_REESTABLISH        = 0x00000200;
		public const uint DLSTATUS_PENDING_RELEASE    = 0x00000400;
		public const uint DLSTATUS_ACK_PENDING        = 0x00000800;
		public const uint DLSTATUS_TX_POLL            = 0x00002000;
		public const uint DLSTATUS_RX_POLL            = 0x00004000;
		public const uint DLSTATUS_FRMR               = 0x00008000;
		public const uint DLSTATUS_REQUEST_DISC       = 0x00010000;
		public const uint DLSTATUS_ENABLE_CHECKPOINT  = 0x00020000;
		public const uint DLSTATUS_INHIBIT_CP         = 0x00040000;
		public const uint DLSTATUS_SREJ_RECOVERY      = 0x00080000;
		public const uint DLSTATUS_INHIBIT_SREJ       = 0x00100000;
		public const uint DLSTATUS_RIM                = 0x00200000;
		public const uint DLSTATUS_SIM                = 0x00400000;
		public const uint DLSTATUS_BEACON_TEST        = 0x00800000;
		public const uint DLSTATUS_MONITOR_MODE       = 0x01000000;
		public const uint DLSTATUS_WRAP               = 0x02000000;
		public const uint DLSTATUS_MODIFIED_LINK_TEST = 0x04000000;
		public const uint DLSTATUS_ENQUIRY_PENDING    = 0x08000000;

		public const uint MODESET_MASK = (DLFLAG_SABME + DLFLAG_SABM + DLFLAG_SNRME
			 + DLFLAG_SNRM + DLFLAG_SARME + DLFLAG_SARM);
		public const uint RXCOND_MASK = (DLSTATUS_PEER_RCV_BUSY + DLSTATUS_OWN_RCV_BUSY + DLSTATUS_REJ_RECOVERY);
		public const uint EXCEPTION_MASK = (RXCOND_MASK + DLSTATUS_ACK_PENDING +
			DLSTATUS_FRMR + DLSTATUS_REQUEST_DISC + DLSTATUS_ENABLE_CHECKPOINT +
			DLSTATUS_SREJ_RECOVERY + DLSTATUS_INHIBIT_CP);

		/* data link primitive types */
		/* used with Type member of MGSL_PRIMITIVE structure */

		public const uint DLERROR_CANCEL                = 0;
		public const uint DLERROR_INSUFFICIENT_BUFFER   = 1;
		public const uint DLERROR_OVERFLOW              = 2;
		public const uint DLCONFIRM_CONFIGURE           = 3;
		public const uint DLCONFIRM_ESTABLISH           = 4;
		public const uint DLCONFIRM_INIT_MODE           = 5;
		public const uint DLCONFIRM_RELEASE             = 6;
		public const uint DLCONFIRM_TEST                = 7;
		public const uint DLCONFIRM_XID                 = 8;
		public const uint DLINDICATION_BEACON           = 9;
		public const uint DLINDICATION_DATA             = 10;
		public const uint DLINDICATION_DATA_DONE        = 11;
		public const uint DLINDICATION_ESTABLISH        = 12;
		public const uint DLINDICATION_INIT_MODE        = 13;
		public const uint DLINDICATION_RAWDATA          = 14;
		public const uint DLINDICATION_RCV_BUSY         = 15;
		public const uint DLINDICATION_RELEASE          = 16;
		public const uint DLINDICATION_SEND_READY       = 17;
		public const uint DLINDICATION_UNITDATA         = 18;
		public const uint DLINDICATION_UNITDATA_DONE    = 19;
		public const uint DLINDICATION_XID              = 20;
		public const uint DLRESPONSE_XID                = 21;
		public const uint DLREQUEST_CONFIGURE           = 22;
		public const uint DLREQUEST_DATA                = 23;
		public const uint DLREQUEST_ESTABLISH           = 24;
		public const uint DLREQUEST_INIT_MODE           = 25;
		public const uint DLREQUEST_RAWDATA             = 26;
		public const uint DLREQUEST_RCV_BUSY            = 27;
		public const uint DLREQUEST_RELEASE             = 28;
		public const uint DLREQUEST_TEST                = 29;
		public const uint DLREQUEST_UNITDATA            = 30;
		public const uint DLREQUEST_XID                 = 31;

		public const uint CFGR_ON                       = 0x01;
		public const uint CFGR_OFF                      = 0x00;
		public const uint CFGR_CLEAR                    = 0x00;
		public const uint CFGR_BEACON_TEST              = 0x02;
		public const uint CFGR_MONITOR_MODE             = 0x04;
		public const uint CFGR_WRAP                     = 0x08;
		public const uint CFGR_SELF_TEST                = 0x0a;
		public const uint CFGR_LINK_TEST                = 0x0c;

		[StructLayout(LayoutKind.Sequential)]
		public struct DATALINK_TRACE_EVENT
		{
			public uint Link;
			public uint Va;
			public uint Vs;
			public uint Vr;
			public uint Event;
			public uint State;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct DATALINK_TRACE_FRAME
		{
			public uint Link;
			public byte Transmit;
			public byte Command;
			public fixed byte ControlField[2];
			public uint ControlLength;
		}


		/*
		** The following structures define the format of API trace data
		*/

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_CANCEL_RECEIVE_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_CANCEL_RECEIVE_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_CANCEL_TRANSMIT_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_CANCEL_TRANSMIT_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_CANCEL_WAIT_EVENT_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_CANCEL_WAIT_EVENT_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_ENABLE_RECEIVER_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint EnableFlag;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_ENABLE_RECEIVER_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_ENABLE_TRANSMITTER_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint EnableFlag;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_ENABLE_TRANSMITTER_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_GET_OPTION_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint Option;
			public uint *Value;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_GET_OPTION_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public uint Option;
			public uint Value;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_GET_PARAMS_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			MGSL_PARAMS *pParams;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_GET_PARAMS_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			MGSL_PARAMS Params;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_GET_SERIAL_SIGNALS_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			byte *pSerialSignals;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_GET_SERIAL_SIGNALS_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			byte SerialSignals;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_GET_TRACE_LEVEL_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint *pTraceLevel;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_GET_TRACE_LEVEL_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public uint TraceLevel;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_RECEIVE_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public MGSL_RECEIVE_REQUEST *pRcvReq;
			public MGSL_RECEIVE_REQUEST RcvReq;
			public NativeOverlapped *pOverlapped;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_RECEIVE_COMPLETE
		{
			public MGSL_RECEIVE_REQUEST RcvReq;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_RECEIVE_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public MGSL_RECEIVE_REQUEST RcvReq;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_RESET_TRACE_BUFFERS_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_RESET_TRACE_BUFFERS_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_SET_IDLE_MODE_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint IdleMode;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_SET_IDLE_MODE_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_SET_OPTION_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint Option;
			public uint Value;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_SET_OPTION_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_SET_SERIAL_SIGNALS_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public byte SerialSignals;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_SET_SERIAL_SIGNALS_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_SET_PARAMS_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public MGSL_PARAMS *pParams;
			public MGSL_PARAMS Params;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_SET_PARAMS_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_SET_TRACE_LEVEL_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint TraceLevel;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_SET_TRACE_LEVEL_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_TRANSMIT_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public byte *pBuffer;
			public uint BufferSize;
			public uint *pStatus;
			public NativeOverlapped *pOverlapped;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_TRANSMIT_COMPLETE
		{
			public uint Status;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_TRANSMIT_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public uint Status;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_WAIT_EVENT_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint EventMask;
			public uint *pEvents;
			public NativeOverlapped *pOverlapped;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_WAIT_EVENT_COMPLETE
		{
			public uint Events;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_WAIT_EVENT_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public uint Events;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_GET_ASSIGNED_RESOURCES_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public MGSL_ASSIGNED_RESOURCES *pResources;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_GET_ASSIGNED_RESOURCES_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public MGSL_ASSIGNED_RESOURCES Resources;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_LOOPMODE_SEND_DONE_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_LOOPMODE_SEND_DONE_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_SET_GPIO_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public GPIO_DESC *pGpio;
			public GPIO_DESC Gpio;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_SET_GPIO_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_GET_GPIO_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public GPIO_DESC *pGpio;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_GET_GPIO_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public GPIO_DESC Gpio;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_WAIT_GPIO_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint EventMask;
			public GPIO_DESC *pGpio;
			public GPIO_DESC Gpio;
			public NativeOverlapped *pOverlapped;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_WAIT_GPIO_COMPLETE
		{
			public GPIO_DESC Gpio;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_WAIT_GPIO_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public GPIO_DESC Gpio;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_CANCEL_WAIT_GPIO_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_CANCEL_WAIT_GPIO_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_ALLOCATE_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint* pLink;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_ALLOCATE_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public uint Link;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_CALL_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public MGSL_DLPRIMITIVE* pPrimitive;
			public MGSL_DLPRIMITIVE Primitive;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_CALL_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public MGSL_DLPRIMITIVE* pPrimitive;
			public uint Link;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_CANCEL_WAIT_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_CANCEL_WAIT_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_FREE_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint Link;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_FREE_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public uint Link;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_GET_PARAMS_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint Link;
			public MGSL_DLPARAMS *pParams;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_GET_PARAMS_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public MGSL_DLPARAMS *pParams;
			public MGSL_DLPARAMS Params;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_GET_PHYSPARAMS_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public MGSL_DLPHYSPARAMS *pParams;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_GET_PHYSPARAMS_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public MGSL_DLPHYSPARAMS *pParams;
			public MGSL_DLPHYSPARAMS Params;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_GET_STATS_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint Link;
			public MGSL_DLSTATS *pStats;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_GET_STATS_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public MGSL_DLSTATS *pStats;
			public MGSL_DLSTATS Stats;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_RESET_STATS_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint Link;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_RESET_STATS_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public uint Link;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_SET_ADDRLIST_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public MGSL_ADDRESS_LIST *pList;
			public MGSL_ADDRESS_LIST List;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_SET_ADDRLIST_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public MGSL_ADDRESS_LIST *pList;
			public uint Link;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_SET_PARAMS_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public MGSL_DLPARAMS *pParams;
			MGSL_DLPARAMS Params;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_SET_PARAMS_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public MGSL_DLPARAMS *pParams;
			public uint Link;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_SET_PHYSPARAMS_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public MGSL_DLPHYSPARAMS *pParams;
			public MGSL_DLPHYSPARAMS Params;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_SET_PHYSPARAMS_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public MGSL_DLPHYSPARAMS *pParams;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_WAIT_CALL
		{
			public uint ProcessId;
			public uint ThreadId;
			public MGSL_DLPRIMITIVE* pPrimitive;
			public uint Size;
			public NativeOverlapped *pOverlapped;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_WAIT_COMPLETE
		{
			public MGSL_DLPRIMITIVE Primitive;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct API_TRACE_DL_WAIT_RETURN
		{
			public uint ProcessId;
			public uint ThreadId;
			public uint ReturnCode;
			public MGSL_DLPRIMITIVE* pPrimitive;
			public MGSL_DLPRIMITIVE Primitive;
		}

		/* device access */

		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslOpenByName([MarshalAs(UnmanagedType.LPStr)] string name, out IntPtr pIntPtr);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslOpen(uint PortID, out IntPtr pIntPtr);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslOpenDiagnostics(uint PortID, out IntPtr pIntPtr, ref uint pStatus);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslOpenDiagnosticsByName([MarshalAs(UnmanagedType.LPStr)] string name,
			out IntPtr pIntPtr, ref uint pStatus, ref MGSL_ASSIGNED_RESOURCES pResources);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslOpenDiagnosticsEx(uint PortID, out IntPtr pIntPtr, ref uint pStatus,
			ref MGSL_ASSIGNED_RESOURCES pResources);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslOpenTraceHandleByName([MarshalAs(UnmanagedType.LPStr)] string name, out IntPtr pIntPtr);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslOpenTraceHandle(uint PortID, out IntPtr pIntPtr);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslClose(IntPtr hDevice);

		/* configuration */

		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslGetParams(IntPtr hDevice, ref MGSL_PARAMS pParams);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslSetParams(IntPtr hDevice, ref MGSL_PARAMS pParams);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslSetOption(IntPtr hDevice, uint option_id, uint value);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslGetOption(IntPtr hDevice, uint option_id, ref uint value);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslSetIdleMode(IntPtr hDevice, uint IdleMode);

		/* transmit */

		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslTransmit(IntPtr hDevice, byte* buf, uint size,
				uint* status, System.Threading.NativeOverlapped *ol);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslCancelTransmit(IntPtr hDevice);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslEnableTransmitter(IntPtr hDevice, uint EnableFlag);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern int MgslWrite(IntPtr hDevice, byte[] buf, int size);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern int MgslWaitAllSent(IntPtr hDevice);

		/* receive */

		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslReceive(IntPtr hDevice, MGSL_RECEIVE_REQUEST *req,
					System.Threading.NativeOverlapped *ol);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslCancelReceive(IntPtr hDevice);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslEnableReceiver(IntPtr hDevice, uint EnableFlag);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern int MgslRead(IntPtr hDevice, byte[] buf, int size);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern int MgslReadWithStatus(IntPtr hDevice, byte[] buf, int size, ref int status);

		/* signal monitor and control */

		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslSetSerialSignals(IntPtr hDevice, byte signals);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslGetSerialSignals(IntPtr hDevice, ref byte signals);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslWaitEvent(IntPtr hDevice, uint EventMask,
					uint *pEvents, NativeOverlapped *pOverlapped);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslCancelWaitEvent(IntPtr hDevice);

		/* General Purpose I/O Control/Status Functions */

		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslSetGpio(IntPtr hDevice, ref GPIO_DESC gpio);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslGetGpio(IntPtr hDevice, ref GPIO_DESC gpio);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslWaitGpio(IntPtr hDevice, GPIO_DESC *gpio, NativeOverlapped *ol);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslCancelWaitGpio(IntPtr hDevice);

		/* misc */
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslGetAssignedResources(IntPtr hDevice, ref MGSL_ASSIGNED_RESOURCES res);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslEnumeratePorts([Out] MGSL_PORT[] ports,
				uint size, out uint count);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslGetPortConfigEx(uint PortID, ref MGSL_PORT_CONFIG_EX Config);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslSetPortConfigEx(uint PortID, ref MGSL_PORT_CONFIG_EX Config);

		/* Trace Functions */

		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslResetTraceBuffers(IntPtr hDevice);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslSetTraceLevel(IntPtr hDevice, uint NewTraceLevel);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslGetTraceLevel(IntPtr hDevice, ref uint pTraceLevel);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslGetTraceEvent(IntPtr hDevice, MGSL_TRACE_EVENT *pEvent,
					NativeOverlapped *pOverlapped);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslCancelGetTraceEvent(IntPtr hDevice);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslPutTraceEvent(IntPtr hDevice, ref MGSL_TRACE_EVENT Event);

		/* link layer API function prototypes */

		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslDlAllocate(IntPtr hDevice, ref uint Link);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslDlCall(IntPtr hDevice, MGSL_DLPRIMITIVE* Primitive);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslDlCancelWait(IntPtr hDevice);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslDlFree(IntPtr hDevice, uint Link);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslDlGetParams(IntPtr hDevice, ref MGSL_DLPARAMS Params);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslDlGetPhysParams(IntPtr hDevice, ref MGSL_DLPHYSPARAMS Params);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslDlGetStats(IntPtr hDevice, ref MGSL_DLSTATS Stats);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslDlResetStats(IntPtr hDevice, uint Link);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslDlSetAddressList(IntPtr hDevice, ref MGSL_ADDRESS_LIST List);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslDlSetParams(IntPtr hDevice, ref MGSL_DLPARAMS Params);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslDlSetPhysParams(IntPtr hDevice, ref MGSL_DLPHYSPARAMS Params);
		[DllImport("mghdlc.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern uint MgslDlWait(IntPtr hDevice, MGSL_DLPRIMITIVE *Primitive, NativeOverlapped *ol);

		/*
		 * convert device name to port ID for use with MgslOpen()
		 * returns: port ID if success, or 0 on failure
		 */
		public static uint GetPortID(string name)
		{
			uint i, rc, count;
			uint port_id = 0;
			MGSL_PORT[] ports;

			/* get count of available ports */
			rc = MgslEnumeratePorts(null, 0, out count);
			if (rc != 0 || count == 0)
				return 0;

			/* allocate memory to hold port information */
			ports = new MGSL_PORT[count];

			/* get port information */
			rc = MgslEnumeratePorts(ports, (uint)(count * sizeof(MGSL_PORT)), out count);
			if (rc != 0 || count == 0)
				return 0;

			/* search for entry with matching name */
			for (i=0; i < count; i++) {
				string port_name;
				char[] port_chars = new char[25];
				uint j;
				fixed (byte* sendBuf = ports[i].DeviceName)
				{
					for (j=0 ; j < 25; j++)
						port_chars[j] = (char)sendBuf[j];
				}
				port_name = new string(port_chars);
				if (String.Compare(port_name.ToUpper(), name.ToUpper()) == 0) {
					port_id = ports[i].PortID;
					break;
				}
			}
			return port_id;
		}

		public class Port
		{
			// serial signal bit flags
			public const byte DCD = SerialSignal_DCD;  // Data Carrier Detect (output)
			public const byte TXD = SerialSignal_TXD;  // Transmit Data (output)
			public const byte RI = SerialSignal_RI;  // Ring Indicator (input)
			public const byte RXD = SerialSignal_RXD;  // Receive Data (input)
			public const byte CTS = SerialSignal_CTS;  // Clear to Send (input)
			public const byte RTS = SerialSignal_RTS;  // Request to Send (output)
			public const byte DSR = SerialSignal_DSR;  // Data Set Ready (input)
			public const byte DTR = SerialSignal_DTR;  // Data Terminal Ready (output)

			// Event bit flags for use with wait_event
			public const uint DSR_ON = MgslEvent_DsrActive;
			public const uint DSR_OFF = MgslEvent_DsrInactive;
			public const uint CTS_ON = MgslEvent_CtsActive;
			public const uint CTS_OFF = MgslEvent_CtsInactive;
			public const uint DCD_ON = MgslEvent_DcdActive;
			public const uint DCD_OFF = MgslEvent_DcdInactive;
			public const uint RI_ON = MgslEvent_RiActive;
			public const uint RI_OFF = MgslEvent_RiInactive;
			public const uint RECEIVE_ACTIVE = MgslEvent_ExitHuntMode;
			public const uint RECEIVE_IDLE = MgslEvent_IdleReceived;

			// serial protocols
			public const uint ASYNC = MGSL_MODE_ASYNC;
			public const uint HDLC = MGSL_MODE_HDLC;
			public const uint MONOSYNC = MGSL_MODE_MONOSYNC;
			public const uint BISYNC = MGSL_MODE_BISYNC;
			public const uint RAW = MGSL_MODE_EXTERNALSYNC;
			public const uint TDM = MGSL_MODE_TDM;

			// serial encodings
			public const byte NRZ = HDLC_ENCODING_NRZ;
			public const byte NRZB = HDLC_ENCODING_NRZB;
			public const byte NRZI_MARK = HDLC_ENCODING_NRZI_MARK;
			public const byte NRZI_SPACE = HDLC_ENCODING_NRZI_SPACE;
			public const byte NRZI = NRZI_SPACE;
			public const byte FM1 = HDLC_ENCODING_BIPHASE_MARK;
			public const byte FM0 = HDLC_ENCODING_BIPHASE_SPACE;
			public const byte MANCHESTER = HDLC_ENCODING_BIPHASE_LEVEL;
			public const byte DIFF_BIPHASE_LEVEL = HDLC_ENCODING_DIFF_BIPHASE_LEVEL;

			// clock sources
			public const int TXC_INPUT = 1;
			public const int RXC_INPUT = 2;
			public const int INTERNAL = 3;
			public const int RECOVERED = 4;

			// used with any setting requiring 0
			public const int OFF = 0;

			// asynchronous parity
			public const int EVEN = 1;
			public const int ODD = 2;

			// HDLC/SDLC frame check
			public const int CRC16 = 1;
			public const int CRC32 = 2;

			// serial interface selection
			public const int RS232 = 1;
			public const int V35 = 2;
			public const int RS422 = 3;
			public const int RS530A = 4;

			const uint ERROR_ACCESS_DENIED = 5;
			const uint ERROR_NOT_READY = 21;
			const uint ERROR_GEN_FAILURE = 31;
			const uint ERROR_OPEN_FAILED = 110;
			const uint ERROR_BUSY = 170;
			const uint ERROR_IO_PENDING = 997;
			const uint ERROR_BAD_DEVICE = 1200;
			const uint ERROR_DEVICE_IN_USE = 2404;

			IntPtr _handle = (IntPtr)0;
			bool _open = false;
			uint _tx_idle = HDLC_TXIDLE_FLAGS;
			string _name = null;
			uint _port_id = 0;
			bool _blocked_io = true;
			Defaults _defaults = new Defaults();
			Settings _settings = new Settings();
			GPIO[] gpio = new GPIO[32];
			uint _default_read_size = 4096;

			public Port(string name)
			{
				_name = name;
				Nullable<uint> id = name_to_id(name);
				if (id != null) {
					_port_id = id.Value;
				}
				for (int bit = 0; bit < 32 ; bit++) {
					gpio[bit] = new GPIO(this, bit);
				}
			}

			~Port()
			{
				if (is_open())
					close();
			}

			// Return list of available device names.
			public static string[] enumerate()
			{
				MGSL_PORT[] ports = new MGSL_PORT[MGSL_MAX_PORTS];
				uint size = (uint)(MGSL_MAX_PORTS * sizeof(MGSL_PORT));
				uint count = 0;
				MgslEnumeratePorts(ports, size, out count);
				string[] names = new string[count];
				for (int i = 0 ; i < count ; i++) {
					byte[] name = null;
					fixed (byte* p = ports[i].DeviceName) {
						int name_length;
						for (name_length = 0; name_length < 25; name_length++) {
							if (p[name_length] == 0)
								break;
						}
						name = new byte[name_length];
						for (int j = 0; j < name_length; j++) {
							name[j] = p[j];
						}
					}
					names[i] = System.Text.Encoding.Default.GetString(name);
				}
				return names;
			}

			// Convert port name to integer port identifier.
			private static Nullable<uint> name_to_id(string name)
			{
				MGSL_PORT[] ports = new MGSL_PORT[MGSL_MAX_PORTS];
				uint size = (uint)(MGSL_MAX_PORTS * sizeof(MGSL_PORT));
				uint count = 0;
				MgslEnumeratePorts(ports, size, out count);
				for (int i = 0; i < count; i++)
				{
					byte[] name_array = null;
					fixed (byte* p = ports[i].DeviceName) {
						int name_length;
						for (name_length = 0; name_length < 25; name_length++) {
							if (p[name_length] == 0)
								break;
						}
						name_array = new byte[name_length];
						for (int j = 0; j < name_length; j++)
							name_array[j] = p[j];
					}
					string namestr = System.Text.Encoding.Default.GetString(name_array);
					if (name.ToUpper() == namestr)
						return ports[i].PortID;
				}
				return null;
			}

			public static string events_str(uint events)
			{
				string s = "";
				if ((events & DSR_ON) != 0) {
					s += "DSR_ON ";
				} else if ((events & DSR_OFF) != 0) {
					s += "DSR_OFF ";
				}
				if ((events & CTS_ON) != 0) {
					s += "CTS_ON ";
				} else if ((events & CTS_OFF) != 0) {
					s += "CTS_OFF ";
				}
				if ((events & DCD_ON) != 0) {
					s += "DCD_ON ";
				} else if ((events & DCD_OFF) != 0) {
					s += "DCD_OFF ";
				}
				if ((events & RI_ON) != 0) {
					s += "RI_ON ";
				} else if ((events & RI_OFF) != 0) {
					s += "RI_OFF ";
				}
				if ((events & RECEIVE_ACTIVE) != 0) {
					s += "RECEIVE_ACTIVE ";
				}
				if ((events & RECEIVE_IDLE) != 0) {
					s += "RECEIVE_IDLE";
				}
				return s;
			}

			public class Defaults
			{
				public uint max_data_size = 4096;
				public uint interface_type = OFF;
				public bool rts_output_enable = false;
				public bool termination = true;

				public string interface_str()
				{
					switch (interface_type)
					{
						case OFF:
							return "OFF";
						case RS232:
							return "RS232";
						case V35:
							return "V35";
						case RS422:
							return "RS422";
						case RS530A:
							return "RS530A";
						default:
							return "Unknown=" + interface_type;
					}
				}

				public Defaults()
				{
				}

				public Defaults(Defaults d)
				{
					max_data_size = d.max_data_size;
					interface_type = d.interface_type;
					rts_output_enable = d.rts_output_enable;
					termination = d.termination;
				}

				public override string ToString()
				{
					return "Defaults object \n" +
						"max_data_size = " + max_data_size + "\n" +
						"interface_type = " + interface_str() + "\n" +
						"rts_output_enable = " + rts_output_enable + "\n" +
						"termination = " + termination + "\n";
				}
			}

			public class Settings
			{
				public uint protocol = HDLC;
				public byte encoding = NRZ;
				public bool msb_first = false;
				public bool internal_loopback = false;

				public ushort crc = CRC16;
				public bool discard_data_with_error = true;
				public bool discard_received_crc = true;

				public byte hdlc_address_filter = 0xff;

				public uint transmit_preamble_pattern = 0x7e;
				public uint transmit_preamble_bits = 0;

				public uint recovered_clock_divisor = 16;
				public uint internal_clock_rate = 0;

				public uint transmit_clock = TXC_INPUT;
				public bool transmit_clock_invert = false;
				public uint receive_clock = RXC_INPUT;
				public bool receive_clock_invert = false;

				public bool auto_cts = false;
				public bool auto_dcd = false;
				public bool auto_rts = false;

				public uint async_data_rate = 9600;
				public byte async_data_bits = 8;
				public byte async_stop_bits = 1;
				public byte async_parity = OFF;

				public uint tdm_sync_delay = 0;
				public bool tdm_sync_short = false;
				public bool tdm_sync_invert = false;
				public uint tdm_frame_count = 1;
				public uint tdm_slot_count = 2;
				public uint tdm_slot_bits = 8;

				public uint sync_pattern = 0;

				public Settings()
				{
				}

				// copy constructor
				public Settings(Settings s)
				{
					protocol = s.protocol;
					encoding = s.encoding;
					msb_first = s.msb_first;
					internal_loopback = s.internal_loopback;

					crc = s.crc;
					discard_data_with_error = s.discard_data_with_error;
					discard_received_crc = s.discard_received_crc;

					hdlc_address_filter = s.hdlc_address_filter;

					transmit_preamble_pattern = s.transmit_preamble_pattern;
					transmit_preamble_bits = s.transmit_preamble_bits;

					recovered_clock_divisor = s.recovered_clock_divisor;
					internal_clock_rate = s.internal_clock_rate;

					transmit_clock = s.transmit_clock;
					transmit_clock_invert = s.transmit_clock_invert;
					receive_clock = s.receive_clock;
					receive_clock_invert = s.receive_clock_invert;

					auto_cts = s.auto_cts;
					auto_dcd = s.auto_dcd;
					auto_rts = s.auto_rts;

					async_data_rate = s.async_data_rate;
					async_data_bits = s.async_data_bits;
					async_stop_bits = s.async_stop_bits;
					async_parity = s.async_parity;

					tdm_sync_delay = s.tdm_sync_delay;
					tdm_sync_short = s.tdm_sync_short;
					tdm_sync_invert = s.tdm_sync_invert;
					tdm_frame_count = s.tdm_frame_count;
					tdm_slot_count = s.tdm_slot_count;
					tdm_slot_bits = s.tdm_slot_bits;

					sync_pattern = s.sync_pattern;
				}

				public string protocol_str()
				{
					switch (protocol) {
					case ASYNC:
						return "ASYNC";
					case HDLC:
						return "HDLC";
					case MONOSYNC:
						return "MONOSYNC";
					case BISYNC:
						return "BISYNC";
					case RAW:
						return "RAW";
					case TDM:
						return "TDM";
					default:
						return "unknown protocol=" + protocol;
					}
				}

				public string encoding_str()
				{
					switch (encoding) {
					case NRZ:
						return "NRZ";
					case NRZB:
						return "NRZB";
					case NRZI_MARK:
						return "NRZI_MARK";
					case NRZI:
						return "NRZI";
					case FM1:
						return "FM1";
					case FM0:
						return "FM0";
					case MANCHESTER:
						return "MANCHESTER";
					case DIFF_BIPHASE_LEVEL:
						return "DIFF_BIPHASE_LEVEL";
					default:
						return "unknown " + encoding;
					}
				}

				public string clock_str(uint clock)
				{
					switch (clock) {
					case TXC_INPUT:
						return "TXC_INPUT";
					case RXC_INPUT:
						return "RXC_INPUT";
					case INTERNAL:
						return "INTERNAL";
					case RECOVERED:
						return "RECOVERED";
					default:
						return "unknown " + clock;
					}
				}

				public string crc_str()
				{
					switch (crc) {
					case OFF:
						return "OFF";
					case CRC16:
						return "CRC16";
					case CRC32:
						return "CRC32";
					default:
						return "unknown " + crc;
					}
				}

				public string parity_str()
				{
					switch (async_parity)
					{
					case OFF:
						return "OFF";
					case EVEN:
						return "EVEN";
					case ODD:
						return "ODD";
					default:
						return "unknown " + async_parity;
					}
				}

				public override string ToString()
				{
					return "Settings object\n" +
						"protocol = " + protocol_str() + "\n" +
						"encoding = " + encoding_str() + "\n" +
						"msb_first = " + msb_first + "\n" +
						"crc = " + crc_str() + "\n" +
						"discard_data_with_error = " + discard_data_with_error + "\n" +
						"discard_received_crc = " + discard_received_crc + "\n" +
						"hdlc_address_filter = " + hdlc_address_filter + "\n" +
						"auto_rts = " + auto_rts + "\n" +
						"auto_cts = " + auto_cts + "\n" +
						"auto_dcd = " + auto_dcd + "\n" +
						"internal_clock_rate = " + internal_clock_rate + "\n" +
						"transmit_clock = " + clock_str(transmit_clock) + "\n" +
						"transmit_clock_invert = " + transmit_clock_invert + "\n" +
						"receive_clock = " + clock_str(receive_clock) + "\n" +
						"receive_clock_invert = " + receive_clock_invert + "\n" +
						"transmit_preamble_pattern = " + transmit_preamble_pattern + "\n" +
						"transmit_preamble_bits = " + transmit_preamble_bits + "\n" +
						"async_data_rate = " + async_data_rate + "\n" +
						"async_data_bits = " + async_data_bits + "\n" +
						"async_stop_bits = " + async_stop_bits + "\n" +
						"async_parity = " + parity_str() + "\n" +
						"sync_pattern = " + String.Format("#{0.X}", sync_pattern) + "\n" +
						"tdm_sync_delay = " + tdm_sync_delay + "\n" +
						"tdm_sync_short = " + tdm_sync_short + "\n" +
						"tdm_sync_invert = " + tdm_sync_invert + "\n" +
						"tdm_frame_count = " + tdm_frame_count + "\n" +
						"tdm_slot_count = " + tdm_slot_count + "\n" +
						"tdm_slot_bits = " + tdm_slot_bits + "\n" +
						"internal_loopback = " + internal_loopback + "\n";
				}
			}

			public class GPIO
			{
				public Port _port = null;
				public int _bit = 0;

				public GPIO(Port port, int bit)
				{
					this._port = port;
					this._bit = bit;
				}

				~GPIO()
				{
					this._port = null;
				}

				public bool state
				{
					get {
						uint gpio = this._port.get_gpio();
						if ((gpio & (1 << this._bit)) != 0) {
							return true;
						} else {
							return false;
						}
					}

					set {
						uint mask = (uint)1 << this._bit;
						uint state;
						if (value)
							state = mask;
						else
							state = 0;
						this._port.set_gpio(mask, state);
					}
				}

				public bool output
				{
					get {
						uint gpio = this._port.get_gpio_direction();
						if ((gpio & ((uint)1 << this._bit)) != 0) {
							return true;
						} else {
							return false;
						}
					}

					set {
						uint mask = (uint)1 << this._bit;
						uint state;
						if (value)
							state = mask;
						else
							state = 0;
						this._port.set_gpio_direction(mask, state);
					}
				}
			}

			public bool is_open()
			{
				return this._open;
			}

			public void open()
			{
				if (is_open())
					return;
				uint error = MgslOpenByName(_name, out _handle);
				if (error != 0) {
					if (error == ERROR_BAD_DEVICE) {
						throw new FileNotFoundException();
					} else if (error == ERROR_ACCESS_DENIED ||
						error == ERROR_DEVICE_IN_USE ||
						error == ERROR_OPEN_FAILED) {
						throw new UnauthorizedAccessException();
					} else {
						throw new Win32Exception((int)error);
					}
				}
				_open = true;
				get_defaults();
				get_settings();
				blocked_io = true;
				ignore_read_errors = true;
				_reset_pio();
			}

			public void close()
			{
				if (is_open()) {
					_reset_pio();
					MgslClose(_handle);
					_open = false;

				}
			}

			public bool write(byte[] buf)
			{
				int bytes_sent = MgslWrite(_handle, buf, buf.Length);
				if (bytes_sent == buf.Length) {
					return true;
				}
				return false;
			}

			public bool flush()
			{
				int error = MgslWaitAllSent(_handle);
				if (error != 0)
					return false;
				return true;
			}

			public byte[] read(int size=0)
			{
				int status = 0;
				return read_with_status(ref status, size);
			}

			public byte[] read_with_status(ref int status, int size=0)
			{
				if (size == 0 ||
					_default_read_size == _defaults.max_data_size) {
					// size not specified or protocol framing sets size
					size = (int)_default_read_size;
				} else if (_default_read_size == 1) {
					Debug.Assert(size > 0 && size <= _defaults.max_data_size,
						"size must be 1 to max_data_size");
				}
				byte[] buf = new byte[size];
				int count = MgslReadWithStatus(_handle, buf, buf.Length, ref status);
				if (count != 0) {
					byte[] rbuf = new byte[count];
					Array.Copy(buf, rbuf, count);
					return rbuf;
				}
				return null;
			}

			public void disable_receiver()
			{
				MgslEnableReceiver(_handle, 0);
			}

			public void enable_receiver()
			{
				MgslEnableReceiver(_handle, 1);
			}

			public void force_idle_receiver()
			{
				MgslEnableReceiver(_handle, 2);
			}

			public void disable_transmitter()
			{
				MgslEnableTransmitter(_handle, 0);
			}

			public void enable_transmitter()
			{
				MgslEnableTransmitter(_handle, 1);
			}

			public uint wait(uint mask, int timeout=-1)
			{
				if (mask == 0) {
					return 0;
				}

				NativeOverlapped* ol;
				try {
					ol = (NativeOverlapped*)System.Runtime.InteropServices.Marshal.AllocHGlobal(sizeof(NativeOverlapped));
				}
				catch (OutOfMemoryException) {
					return 0;
				}
				ManualResetEvent mre = new ManualResetEvent(false);
				ol->EventHandle = mre.SafeWaitHandle.DangerousGetHandle();

				uint events = 0;
				uint rc = MgslWaitEvent(_handle, mask, &events, ol);
				if (rc == ERROR_IO_PENDING) {
					if (!mre.WaitOne(timeout, false)) {
						MgslCancelWaitEvent(_handle);
						mre.WaitOne(-1, false);
					}
				}

				System.Runtime.InteropServices.Marshal.FreeHGlobal((IntPtr)ol);
				return events;
			}

			public void cancel_read()
			{
				MgslCancelReceive(_handle);
			}

			public void cancel_wait()
			{
				MgslCancelWaitEvent(_handle);
			}

			public void cancel_write()
			{
				MgslCancelTransmit(_handle);
			}

			public void set_gpio(uint mask, uint states)
			{
				GPIO_DESC gpio = new GPIO_DESC();
				gpio.state = states;
				gpio.smask = mask;
				gpio.dmask = 0;  // unused
				gpio.dir = 0;  // unused
				MgslSetGpio(_handle, ref gpio);
			}

			public uint get_gpio()
			{
				GPIO_DESC gpio = new GPIO_DESC();
				MgslGetGpio(_handle, ref gpio);
				return gpio.state;
			}

			public void set_gpio_direction(uint mask, uint dir)
			{
				GPIO_DESC gpio = new GPIO_DESC();
				gpio.state = 0; // unused
				gpio.smask = 0; // unused
				gpio.dmask = mask;
				gpio.dir = dir;
				MgslSetGpio(_handle, ref gpio);
			}

			public uint get_gpio_direction()
			{
				GPIO_DESC gpio = new GPIO_DESC();
				MgslGetGpio(_handle, ref gpio);
				return gpio.dir;
			}

			public void set_option(uint option, uint value)
			{
				MgslSetOption(_handle, option, value);
			}

			public uint get_option(uint option)
			{
				uint value = 0;
				MgslGetOption(_handle, option, ref value);
				return value;
			}

			void _set_default_read_size()
			{
				if (_settings.protocol == HDLC || _settings.protocol == TDM) {
					// protocol framing determines returned read size
					_default_read_size = _defaults.max_data_size;
				} else {
					_default_read_size = 1;
				}
			}

			public void apply_settings(Settings settings)
			{
				_reset_pio();
				_settings = new Settings(settings);
				_set_default_read_size();

				_msb_first = settings.msb_first;

				// convert tdm settings to 32 bit tdm_options value

				uint tdm_options;
				switch (settings.tdm_sync_delay) {
				case 1:
					tdm_options = TDM_SYNC_DELAY_1BIT;
					break;
				case 2:
					tdm_options = TDM_SYNC_DELAY_2BITS;
					break;
				default:
					tdm_options = 0;
					break;
				}

				if (settings.tdm_sync_short) {
					tdm_options |= TDM_TX_SYNC_WIDTH_BIT;
				}
				if (settings.tdm_sync_invert) {
					tdm_options |= TDM_SYNC_POLARITY_INVERT;
				}

				// tdm_options[15:8] 8 bit frame count
				// valid tdm_frame_count: 1 to 256
				if (settings.tdm_frame_count != 0 && settings.tdm_frame_count < 257) {
					tdm_options |= (settings.tdm_frame_count - 1) << 8;
				}

				// tdm_options[7:3] 0=384 slots, 1-31 = 2-32 slots
				// valid tdm_slot_count: 384 and 2-32
				if (settings.tdm_slot_count > 1 && settings.tdm_slot_count < 33) {
					tdm_options |= (settings.tdm_slot_count - 1) << 3;
				}

				switch (settings.tdm_slot_bits) {
				case 8:
					tdm_options |= TDM_SLOT_SIZE_8BITS;
					break;
				case 12:
					tdm_options |= TDM_SLOT_SIZE_12BITS;
					break;
				case 16:
					tdm_options |= TDM_SLOT_SIZE_16BITS;
					break;
				case 20:
					tdm_options |= TDM_SLOT_SIZE_20BITS;
					break;
				case 24:
					tdm_options |= TDM_SLOT_SIZE_24BITS;
					break;
				case 28:
					tdm_options |= TDM_SLOT_SIZE_28BITS;
					break;
				default:
					tdm_options |= TDM_SLOT_SIZE_32BITS;
					break;
				}

				_tdm_options = tdm_options;

				// translate Settings object into base API calls

				MGSL_PARAMS mp;

				mp.Mode = settings.protocol;
				if (settings.internal_loopback)
					mp.Loopback = 1;
				else
					mp.Loopback = 0;

				mp.Flags = 0;

				if (settings.transmit_clock == RXC_INPUT)
					mp.Flags |= HDLC_FLAG_TXC_RXCPIN;
				else if (settings.transmit_clock == Port.INTERNAL)
					mp.Flags |= HDLC_FLAG_TXC_BRG;
				else if (settings.transmit_clock == Port.RECOVERED)
					mp.Flags |= HDLC_FLAG_TXC_DPLL;
				if (settings.transmit_clock_invert)
					mp.Flags |= HDLC_FLAG_TXC_INV;

				if (settings.receive_clock == Port.TXC_INPUT)
					mp.Flags |= HDLC_FLAG_RXC_TXCPIN;
				else if (settings.receive_clock == Port.INTERNAL)
					mp.Flags |= HDLC_FLAG_RXC_BRG;
				else if (settings.receive_clock == Port.RECOVERED)
					mp.Flags |= HDLC_FLAG_RXC_DPLL;
				if (settings.receive_clock_invert)
					mp.Flags |= HDLC_FLAG_RXC_INV;

				if (settings.auto_rts)
					mp.Flags |= HDLC_FLAG_AUTO_RTS;
				if (settings.auto_cts)
					mp.Flags |= HDLC_FLAG_AUTO_CTS;
				if (settings.auto_dcd)
					mp.Flags |= HDLC_FLAG_AUTO_DCD;

				mp.Encoding = settings.encoding;
				mp.ClockSpeed = settings.internal_clock_rate;

				mp.CrcType = settings.crc;
				if (!settings.discard_data_with_error)
					mp.CrcType |= HDLC_CRC_RETURN_CRCERR_FRAME;
				if (!settings.discard_received_crc)
					mp.CrcType |= HDLC_CRC_RETURN_CRC;

				mp.Addr = settings.hdlc_address_filter;

				if (settings.transmit_preamble_bits == 8)
					mp.PreambleLength = HDLC_PREAMBLE_LENGTH_8BITS;
				else if (settings.transmit_preamble_bits == 16)
					mp.PreambleLength = HDLC_PREAMBLE_LENGTH_16BITS;
				else if (settings.transmit_preamble_bits == 32)
					mp.PreambleLength = HDLC_PREAMBLE_LENGTH_32BITS;
				else if (settings.transmit_preamble_bits == 64)
					mp.PreambleLength = HDLC_PREAMBLE_LENGTH_64BITS;
				else {
					mp.PreambleLength = HDLC_PREAMBLE_LENGTH_8BITS;
					mp.PreamblePattern = HDLC_PREAMBLE_PATTERN_NONE;
				}

				if (settings.transmit_preamble_bits == 0) {
					mp.PreamblePattern = HDLC_PREAMBLE_PATTERN_NONE;
				} else {
					switch (settings.transmit_preamble_pattern) {
					case 0:
						mp.PreamblePattern = HDLC_PREAMBLE_PATTERN_ZEROS;
						break;
					case 0xff:
						mp.PreamblePattern = HDLC_PREAMBLE_PATTERN_ONES;
						break;
					case 0x55:
						mp.PreamblePattern = HDLC_PREAMBLE_PATTERN_10;
						break;
					case 0xaa:
						mp.PreamblePattern = HDLC_PREAMBLE_PATTERN_01;
						break;
					case 0x7e:
						mp.PreamblePattern = HDLC_PREAMBLE_PATTERN_FLAGS;
						break;
					default:
						mp.PreamblePattern = HDLC_PREAMBLE_PATTERN_NONE;
						break;
					}
				}

				mp.DataRate = settings.async_data_rate;
				mp.DataBits = settings.async_data_bits;
				mp.StopBits = settings.async_stop_bits;
				mp.Parity = settings.async_parity;

				if (settings.protocol == BISYNC)
					transmit_idle_pattern = settings.sync_pattern;
				else if (settings.protocol == MONOSYNC)
					transmit_idle_pattern = settings.sync_pattern;

				if ((settings.internal_clock_rate != 0) &&
					(base_clock_rate % (settings.internal_clock_rate * 16) !=0 )) {
					// x16 reference clock is not divisor of base clock
					// fall back to x8 reference clock
					mp.Flags |= HDLC_FLAG_DPLL_DIV8;
				}

				MgslSetParams(_handle, ref mp);
			}

			public Settings get_settings()
			{
				MGSL_PARAMS mp = new MGSL_PARAMS();
				uint error = MgslGetParams(_handle, ref mp);
				if (error != 0)
					return null;

				Settings settings = new Settings();
				settings.protocol = mp.Mode;
				if (mp.Loopback != 0)
					settings.internal_loopback = true;
				else
					settings.internal_loopback = false;

				ushort rxc_flags = (ushort)(mp.Flags & 0x8300);
				if ((rxc_flags & HDLC_FLAG_RXC_BRG) != 0)
					settings.receive_clock = Port.INTERNAL;
				else if ((rxc_flags & HDLC_FLAG_RXC_DPLL) != 0)
					settings.receive_clock = Port.RECOVERED;
				else if ((rxc_flags & HDLC_FLAG_RXC_TXCPIN) != 0)
					settings.receive_clock = Port.TXC_INPUT;
				else
					settings.receive_clock = Port.RXC_INPUT;

				if ((mp.Flags & HDLC_FLAG_RXC_INV) != 0)
					settings.receive_clock_invert = true;
				else
					settings.receive_clock_invert = false;

				ushort txc_flags = (ushort)(mp.Flags & 0x0c08);
				if ((txc_flags & HDLC_FLAG_TXC_BRG) != 0)
					settings.transmit_clock = Port.INTERNAL;
				else if ((txc_flags & HDLC_FLAG_TXC_DPLL) != 0)
					settings.transmit_clock = Port.RECOVERED;
				else if ((txc_flags & HDLC_FLAG_TXC_RXCPIN) != 0)
					settings.transmit_clock = Port.RXC_INPUT;
				else
					settings.transmit_clock = Port.TXC_INPUT;

				if ((mp.Flags & HDLC_FLAG_TXC_INV) != 0)
					settings.transmit_clock_invert = true;
				else
					settings.transmit_clock_invert = false;

				if ((mp.Flags & HDLC_FLAG_AUTO_RTS) != 0)
					settings.auto_rts = true;
				else
					settings.auto_rts = false;
				if ((mp.Flags & HDLC_FLAG_AUTO_CTS) != 0)
					settings.auto_cts = true;
				else
					settings.auto_cts = false;
				if ((mp.Flags & HDLC_FLAG_AUTO_DCD) != 0)
					settings.auto_dcd = true;
				else
					settings.auto_dcd = false;

				settings.encoding = mp.Encoding;
				settings.internal_clock_rate = mp.ClockSpeed;

				settings.crc = (ushort)(mp.CrcType & HDLC_CRC_MODE);
				if ((mp.CrcType & HDLC_CRC_RETURN_CRCERR_FRAME) != 0)
					settings.discard_data_with_error = false;
				else
					settings.discard_data_with_error = true;

				if ((mp.CrcType & HDLC_CRC_RETURN_CRC) != 0)
					settings.discard_received_crc = false;
				else
					settings.discard_received_crc = true;

				settings.hdlc_address_filter = mp.Addr;

				switch (mp.PreambleLength) {
				case HDLC_PREAMBLE_LENGTH_8BITS:
					settings.transmit_preamble_bits = 8;
					break;
				case HDLC_PREAMBLE_LENGTH_16BITS:
					settings.transmit_preamble_bits = 16;
					break;
				case HDLC_PREAMBLE_LENGTH_32BITS:
					settings.transmit_preamble_bits = 32;
					break;
				case HDLC_PREAMBLE_LENGTH_64BITS:
					settings.transmit_preamble_bits = 64;
					break;
				default:
					settings.transmit_preamble_bits = 0;
					break;
				}

				switch (mp.PreamblePattern) {
				case HDLC_PREAMBLE_PATTERN_ZEROS:
					settings.transmit_preamble_pattern = 0;
					break;
				case HDLC_PREAMBLE_PATTERN_ONES:
					settings.transmit_preamble_pattern = 0xff;
					break;
				case HDLC_PREAMBLE_PATTERN_10:
					settings.transmit_preamble_pattern = 0x55;
					break;
				case HDLC_PREAMBLE_PATTERN_01:
					settings.transmit_preamble_pattern = 0xaa;
					break;
				case HDLC_PREAMBLE_PATTERN_FLAGS:
					settings.transmit_preamble_pattern = 0x7e;
					break;
				default:
					settings.transmit_preamble_pattern = 0;
					settings.transmit_preamble_bits = 0;
					break;
				}

				settings.async_data_rate = mp.DataRate;
				settings.async_data_bits = mp.DataBits;
				settings.async_stop_bits = mp.StopBits;
				settings.async_parity = mp.Parity;

				// convert tdm settings to 32 tdm_options value
				uint tdm_options = _tdm_options;

				uint sync_delay = (tdm_options >> 18) & 3;
				if (sync_delay == TDM_SYNC_DELAY_1BIT)
					settings.tdm_sync_delay = 1;
				else if (sync_delay == TDM_SYNC_DELAY_2BITS)
					settings.tdm_sync_delay = 2;
				else
					settings.tdm_sync_delay = 0;

				if ((tdm_options & TDM_TX_SYNC_WIDTH_BIT) != 0)
					settings.tdm_sync_short = true;
				else
					settings.tdm_sync_short = false;

				if ((tdm_options & TDM_SYNC_POLARITY_INVERT) != 0)
					settings.tdm_sync_invert = true;
				else
					settings.tdm_sync_invert = false;

				settings.tdm_frame_count = ((tdm_options >> 8) & 0xff) + 1;

				uint slot_count = (tdm_options >> 3) & 0x1f;
				if (slot_count == 0)
					settings.tdm_slot_count = 384;
				else
					settings.tdm_slot_count = slot_count + 1;

				settings.tdm_slot_bits = 4 + ((tdm_options & 0x7) * 4);

				settings.msb_first = _msb_first;

				if (settings.protocol == BISYNC)
					settings.sync_pattern = transmit_idle_pattern;
				else if (settings.protocol == MONOSYNC)
					settings.sync_pattern = transmit_idle_pattern;

				_settings = new Settings(settings);
				_set_default_read_size();

				return settings;
			}

			public uint transmit_idle_pattern {
				get { return _tx_idle & 0xffff; }
				set {
					if (value == 0x7e)
						_tx_idle = HDLC_TXIDLE_FLAGS;
					else if (value == 0xaa)
						_tx_idle = HDLC_TXIDLE_ALT_ZEROS_ONES;
					else if (value == 0)
						_tx_idle = HDLC_TXIDLE_ZEROS;
					else if (value == 0xff)
						_tx_idle = HDLC_TXIDLE_ONES;
					else if (value < 0x100)
						_tx_idle = HDLC_TXIDLE_CUSTOM_8 + value;
					else
						_tx_idle = HDLC_TXIDLE_CUSTOM_16 + value;
					MgslSetIdleMode(_handle, _tx_idle);
				}
			}

			public byte signals {
				get {
					byte signals = 0;
					MgslGetSerialSignals(_handle, ref signals);
					return signals;
				}
				set { MgslSetSerialSignals(_handle, value); }
			}

			public bool dtr {
				get { return (signals & DTR) != 0; }
				set {
					if (value)
						signals |= DTR;
					else
						signals &= (~DTR & 0xff);
				}
			}

			public bool rts {
				get { return (signals & RTS) != 0; }
				set {
					if (value)
						signals |= RTS;
					else
						signals &= (~RTS & 0xff);
				}
			}

			public bool dsr { get { return (signals & DSR) != 0; } }
			public bool cts { get { return (signals & CTS) != 0; } }
			public bool dcd { get { return (signals & DCD) != 0; } }
			public bool ri { get { return (signals & RI) != 0; } }
			public bool txd { get { return (signals & TXD) != 0; } }
			public bool rxd { get { return (signals & RXD) != 0; } }

			public bool ll {
				get { return get_option(MGSL_OPT_ENABLE_LOCALLOOPBACK) != 0; }
				set { set_option(MGSL_OPT_ENABLE_LOCALLOOPBACK, value ? 1U : 0U); }
			}

			public bool rl {
				get { return get_option(MGSL_OPT_ENABLE_REMOTELOOPBACK) != 0; }
				set { set_option(MGSL_OPT_ENABLE_REMOTELOOPBACK, value ? 1U : 0U); }
			}

			public bool rx_discard_too_large {
				get { return get_option(MGSL_OPT_RX_DISCARD_TOO_LARGE) != 0; }
				set { set_option(MGSL_OPT_RX_DISCARD_TOO_LARGE, value ? 1U : 0U); }
			}

			public uint underrun_retry_limit {
				get { return get_option(MGSL_OPT_UNDERRUN_RETRY_LIMIT); }
				set { set_option(MGSL_OPT_UNDERRUN_RETRY_LIMIT, value); }
			}

			public uint jcr {
				get { return get_option(MGSL_OPT_JCR); }
				set { set_option(MGSL_OPT_JCR, value); }
			}

			public uint interface_type {
				get { return get_option(MGSL_OPT_INTERFACE); }
				set { set_option(MGSL_OPT_INTERFACE, value); }
			}

			public bool rts_output_enable {
				get { return get_option(MGSL_OPT_RTS_DRIVER_CONTROL) != 0; }
				set { set_option(MGSL_OPT_RTS_DRIVER_CONTROL, value ? 1U : 0U); }
			}

			public bool ignore_read_errors {
				get { return get_option(MGSL_OPT_RX_ERROR_MASK) != 0; }
				set { set_option(MGSL_OPT_RX_ERROR_MASK, value ? 1U : 0U); }
			}

			public uint base_clock_rate {
				get { return get_option(MGSL_OPT_CLOCK_BASE_FREQ); }
				set { set_option(MGSL_OPT_CLOCK_BASE_FREQ, value); }
			}

			public bool half_duplex {
				get { return get_option(MGSL_OPT_HALF_DUPLEX) != 0; }
				set { set_option(MGSL_OPT_HALF_DUPLEX, value ? 1U : 0U); }
			}

			bool _msb_first {
				get { return get_option(MGSL_OPT_MSB_FIRST) != 0; }
				set { set_option(MGSL_OPT_MSB_FIRST, value ? 1U : 0U); }
			}

			public uint receive_count {
				get { return get_option(MGSL_OPT_RX_COUNT); }
			}

			public uint transmit_count {
				get { return get_option(MGSL_OPT_TX_COUNT); }
			}

			public bool blocked_io {
				get { return _blocked_io; }
				set {
					_blocked_io = value;
					set_option(MGSL_OPT_RX_POLL, !value ? 1U : 0U);
					set_option(MGSL_OPT_TX_POLL, !value ? 1U : 0U);
				}
			}

			public bool termination {
				get { return !(get_option(MGSL_OPT_NO_TERMINATION) != 0); }
				set { set_option(MGSL_OPT_NO_TERMINATION, !value ? 1U : 0U); }
			}

			uint _tdm_options {
				get { return get_option(MGSL_OPT_TDM); }
				set { set_option(MGSL_OPT_TDM, value); }
			}

			public bool enable_clock_output {
				get { return get_option(MGSL_OPT_AUXCLK_ENABLE) != 0; }
				set { set_option(MGSL_OPT_AUXCLK_ENABLE, value ? 1U : 0U); }
			}

			public uint underrun_count {
				get { return get_option(MGSL_OPT_UNDERRUN_COUNT); }
				set { set_option(MGSL_OPT_UNDERRUN_COUNT, value); }
			}

			public uint transmit_idle_count {
				get { return get_option(MGSL_OPT_TX_IDLE_COUNT); }
				set { set_option(MGSL_OPT_TX_IDLE_COUNT, value); }
			}

			public uint output_control {
				get { return get_option(MGSL_OPT_RS422_OE); }
				set { set_option(MGSL_OPT_RS422_OE, value); }
			}

			public string name { get { return _name; } }

			public void set_defaults(Defaults defaults)
			{
				if (!is_open() || (_port_id == 0))
					return;
				_defaults = new Defaults(defaults);
				_set_default_read_size();

				MGSL_PORT_CONFIG_EX cfg = new MGSL_PORT_CONFIG_EX();
				uint error = MgslGetPortConfigEx(_port_id, ref cfg);
				if (error != 0)
					return;
				cfg.MaxFrameSize = defaults.max_data_size;
				cfg.Flags = defaults.interface_type;
				if (defaults.rts_output_enable)
					cfg.Flags |= MGSL_RTS_DRIVER_CONTROL;
				if (!defaults.termination)
					cfg.Flags |= MGSL_NO_TERMINATION;
				MgslSetPortConfigEx(_port_id, ref cfg);
			}

			public Defaults get_defaults()
			{
				if (!is_open() || (_port_id == 0))
					return null;
				MGSL_PORT_CONFIG_EX cfg = new MGSL_PORT_CONFIG_EX();
				uint error = MgslGetPortConfigEx(_port_id, ref cfg);
				if (error != 0)
					return null;
				Defaults defaults = new Defaults();
				defaults.max_data_size = cfg.MaxFrameSize;
				defaults.interface_type = cfg.Flags & MGSL_INTERFACE_MASK;
				defaults.rts_output_enable = (cfg.Flags & MGSL_RTS_DRIVER_CONTROL) != 0;
				defaults.termination = (cfg.Flags & MGSL_NO_TERMINATION) == 0;
				_defaults = new Defaults(defaults);
				_set_default_read_size();
				return defaults;
			}

			void _reset_pio()
			{
				// work around Windows driver bug where PIO mode is not cleared
				// when switching to protocol that does not support PIO mode.
				if (!is_open())
					return;
				MGSL_PARAMS old_params = new MGSL_PARAMS();
				MgslGetParams(_handle, ref old_params);
				bool old_blocked_io = blocked_io;

				MGSL_PARAMS new_params = new MGSL_PARAMS();
				new_params.Mode = RAW;
				MgslSetParams(_handle, ref new_params);
				blocked_io = false;
				try {
					read(256);
				} catch {
				}

				blocked_io = old_blocked_io;
				MgslSetParams(_handle, ref old_params);
			}

			// This code programs the frequency synthesizer on the SyncLink GT2e/GT4e
			// PCI express serial adapters and SyncLink USB device to a specified frequency
			// and selects the synthesizer output as the adapter base clock. ONLY the GT2e/GT4e
			// cards and SyncLink USB device have this feature. Copy and paste this code into
			// applications that require a non-standard base clock frequency.
			//
			// SyncLink GT family serial adapters have a fixed 14.7456MHz base clock.
			// The serial controller generates data clocks by dividing the base clock
			// by an integer. Only discrete data clock values can be generated
			// exactly from a given base clock frequency. When an exact data clock
			// value is required that cannot be derived by dividing 14.7456MHz by
			// and integer, a different base clock value must be used. One way to
			// do this is special ordering a different fixed base clock which is
			// installed at the factory.
			//
			// The SyncLink GT2e, GT4e and USB serial devices have both
			// a 14.7456MHz fixed base clock and a variable frequency synthesizer.
			// The serial controller can use either as the base clock.
			//
			// The frequency synthesizer is an Integrated Device Technologies (IDT)
			// ICS307-3 device. The reference clock input to the synthesizer is
			// the fixed 14.7456MHz clock.
			// GT2E/GT4E uses synthesizer CLK1 output
			// USB uses synthesizer CLK3 output
			// Refer to the appropriate hardware user's manual for more details.
			//
			// The synthesizer SPI programming interface is connected to the serial
			// controller general purpose I/O signals. The GPIO portion of the serial
			// API is used to program the synthesizer with a 132 bit word. This word
			// is calculated using the IDT Versaclock software available at www.idt.com
			//
			// Contact Microgate for help in producing a programming word for a specific
			// frequency output. Several common frequencies are included in this code.
			// Maximum supported base clock is 66MHz
			//
			// Note:
			// After programming the frequency synthesizer and selecting it
			// as the base clock, each individual port of a card must be configured with
			// MgslSetOption(fd, MGSL_OPT_CLOCK_BASE_FREQ, freq_value);
			//
			// This allows the device driver to correctly calculate divisors
			// for a specified data clock rate. All ports on a card share
			// a common base clock.

			// Each frequency table entry contains an output frequency
			// and the associated 132 bit synthesizer programming word
			// to produce the frequency.

			// The programming word comes from the Versaclock 2 software
			// parsed into 5 32-bit integers. The final 4 bits are placed
			// in the most significant 4 bits of the final 32-bit integer.
			public struct FREQ_TABLE_ENTRY
			{
				public int freq;  // frequency
				public uint[] data;  // synth programming data
				public FREQ_TABLE_ENTRY(int f, uint[] d)
				{
					freq = f;
					data = d;
				}
			}

			// GT2e/GT4e
			//
			// Base Clock = dedicated 14.7456MHz oscillator
			//
			// ICS307-3 (clock):
			// - reference clock = 14.7456MHz oscillator
			// - VDD = 3.3V
			// - CLK1 (pin 8) output drives FPGA fsynth input
			public static FREQ_TABLE_ENTRY[] gt4e_table = {
				new FREQ_TABLE_ENTRY(
					12288000, new uint[] {0x29BFDC00, 0x61200000, 0x00000000, 0x0000A5FF, 0xA0000000}),
				new FREQ_TABLE_ENTRY(
					14745600, new uint[] {0x38003C05, 0x24200000, 0x00000000, 0x000057FF, 0xA0000000}),
				new FREQ_TABLE_ENTRY(
					16000000, new uint[] {0x280CFC02, 0x64A00000, 0x00000000, 0x000307FD, 0x20000000}),
				new FREQ_TABLE_ENTRY(
					16384000, new uint[] {0x08001402, 0xA1200000, 0x00000000, 0x0000A5FF, 0xA0000000}),
				new FREQ_TABLE_ENTRY(
					19660800, new uint[] {0x08001403, 0xE1200000, 0x00000000, 0x0000A1FF, 0xA0000000}),
				new FREQ_TABLE_ENTRY(
					20000000, new uint[] {0x00001403, 0xE0C00000, 0x00000000, 0x00045E02, 0xF0000000}),
				new FREQ_TABLE_ENTRY(
					23040000, new uint[] {0x08001404, 0xA0A00000, 0x00000000, 0x0003A7FC, 0x60000000}),
				new FREQ_TABLE_ENTRY(
					24000000, new uint[] {0x00001404, 0xE1400000, 0x00000000, 0x0003D5FC, 0x20000000}),
				new FREQ_TABLE_ENTRY(
					28800000, new uint[] {0x18001405, 0x61A00000, 0x00000000, 0x0000EBFF, 0x60000000}),
				new FREQ_TABLE_ENTRY(
					30000000, new uint[] {0x20267C05, 0x64C00000, 0x00000000, 0x00050603, 0x30000000}),
				new FREQ_TABLE_ENTRY(
					32000000, new uint[] {0x21BFDC00, 0x5A400000, 0x00000000, 0x0004D206, 0x30000000}),
				new FREQ_TABLE_ENTRY(
					33200000, new uint[] {0x00001400, 0xD8C00000, 0x00000000, 0x0005E204, 0xB0000000}),
				new FREQ_TABLE_ENTRY(
					33320000, new uint[] {0x08001400, 0xD8A00000, 0x00000000, 0x0001C7FE, 0x60000000}),
				new FREQ_TABLE_ENTRY(
					38400000, new uint[] {0x00001406, 0xE1800000, 0x00000000, 0x00098009, 0xF0000000}),
				new FREQ_TABLE_ENTRY(
					50000000, new uint[] {0x00001400, 0x58C00000, 0x00000000, 0x0005E604, 0x70000000}),
				new FREQ_TABLE_ENTRY(
					64000000, new uint[] {0x21BFDC00, 0x12000000, 0x00000000, 0x000F5E14, 0xF0000000})
			};


			// SyncLink USB
			//
			// Base Clock = ICS307-3 CLK1 (pin 8) output (power up default = 14.7456MHz)
			//
			// ICS307-3 (xtal):
			// - reference clock = 14.7456MHz xtal
			// - VDD = 3.3V
			// - CLK3 (pin 14) output drives FPGA fsynth input
			// - CLK1 (pin 8)  output drives FPGA base clock input
			//
			// Note: CLK1 and CLK3 outputs must always be driven to prevent floating
			// clock inputs to the FPGA. When calculating programming word with Versaclock,
			// select same output on CLK1 and CLK3 or select CLK1 as multiple of CLK3.
			public static FREQ_TABLE_ENTRY[] usb_table = {
				new FREQ_TABLE_ENTRY(
					12288000, new uint[] {0x28401400, 0xE5200000, 0x00000000, 0x00009BFF, 0xA0000000}),
				new FREQ_TABLE_ENTRY(
					14745600, new uint[] {0x28481401, 0xE5200000, 0x00000000, 0x0000A5FF, 0xA0000000}),
				new FREQ_TABLE_ENTRY(
					16000000, new uint[] {0x284C1402, 0x64A00000, 0x00000000, 0x000307FD, 0x20000000}),
				new FREQ_TABLE_ENTRY(
					16384000, new uint[] {0x28501402, 0xE4A00000, 0x00000000, 0x0001F9FE, 0x20000000}),
				new FREQ_TABLE_ENTRY(
					19660800, new uint[] {0x38541403, 0x65A00000, 0x00000000, 0x0000B1FF, 0xA0000000}),
				new FREQ_TABLE_ENTRY(
					20000000, new uint[] {0x205C1404, 0x65400000, 0x00000000, 0x00068205, 0xF0000000}),
				new FREQ_TABLE_ENTRY(
					23040000, new uint[] {0x38601404, 0xE5A00000, 0x00000000, 0x0001B3FE, 0x60000000}),
				new FREQ_TABLE_ENTRY(
					24000000, new uint[] {0x20601404, 0xE5400000, 0x00000000, 0x0003D5FC, 0x20000000}),
				new FREQ_TABLE_ENTRY(
					28800000, new uint[] {0x38641405, 0x65A00000, 0x00000000, 0x0000EBFF, 0x60000000}),
				new FREQ_TABLE_ENTRY(
					30000000, new uint[] {0x20641405, 0x64C00000, 0x00000000, 0x00050603, 0x30000000}),
				new FREQ_TABLE_ENTRY(
					32000000, new uint[] {0x206C1406, 0x65400000, 0x00000000, 0x00049E03, 0xF0000000}),
				new FREQ_TABLE_ENTRY(
					33200000, new uint[] {0x20681405, 0xE4C00000, 0x00000000, 0x00061804, 0x70000000}),
				new FREQ_TABLE_ENTRY(
					33320000, new uint[] {0x21FBB800, 0x05400000, 0x00000000, 0x00038BFC, 0x20000000}),
				new FREQ_TABLE_ENTRY(
					38400000, new uint[] {0x20701406, 0xE5800000, 0x00000000, 0x00098009, 0xF0000000}),
				new FREQ_TABLE_ENTRY(
					45056000, new uint[] {0x28701406, 0xE4200000, 0x00000000, 0x000217FE, 0x20000000}),
				new FREQ_TABLE_ENTRY(
					50000000, new uint[] {0x20741407, 0x65400000, 0x00000000, 0x00068205, 0xF0000000}),
				new FREQ_TABLE_ENTRY(
					64000000, new uint[] {0x20781400, 0x4D400000, 0x00000000, 0x00049E03, 0xF0000000})
			};

			public bool set_fsynth_rate(uint rate)
			{
				MGSL_ASSIGNED_RESOURCES resources = new MGSL_ASSIGNED_RESOURCES();
				FREQ_TABLE_ENTRY[] freq_table;
				GPIO mux;
				GPIO clk;
				GPIO sel;
				GPIO dat;
				uint error = MgslGetAssignedResources(_handle, ref resources);
				if (error != 0)
					return false;

				// select table and GPIO bit positions for device type
				if (resources.DeviceId == SYNCLINK_USB_DEVICE_ID) {
					freq_table = usb_table;
					mux = gpio[23];
					clk = gpio[22];
					sel = gpio[21];
					dat = gpio[20];
				} else {
					freq_table = gt4e_table;
					mux = gpio[15];
					clk = gpio[14];
					sel = gpio[13];
					dat = gpio[12];
				}

				uint[] data = null;

				// search for entry for requested output frequency
				foreach (FREQ_TABLE_ENTRY entry in freq_table) {
					if (entry.freq == rate) {
						data = entry.data;
						break;
					}
				}

				if (data == null) {
					return false;
				}

				clk.state = false;

				uint dword_val = 0;
				// write 132 bit clock program word one bit at a time
				for (int i = 0 ; i < 132 ; i++) {
					if ((i % 32) == 0)
						dword_val = data[(int)(i/32)];
					if ((dword_val & (1 << 31)) != 0)
						dat.state = true;
					else
						dat.state = false;
					// pulse clock signal to load next bit
					clk.state = true;
					clk.state = false;
					dword_val <<= 1;
				}

				// pulse select signal to accept new word
				sel.state = true;
				sel.state = false;

				// set base clock input multiplexer
				// False = fixed frequency oscillator (default 14.7456MHz)
				// True  = frequency syntheziser output
				mux.state = true;

				// tell port the new rate
				base_clock_rate = rate;
				return true;
			}
		}
	}
}
