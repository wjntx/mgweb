﻿// bisync/monosync protocol sample
// - send data in main thread
// - receive data in receive thread
//
// Bisync and monosync protocols are identical except the length
// of the sync pattern (bisync=16 bits, monosync=8 bits). Edit the
// settings.protocol assignment below to select protocol.
//
// == Single Port Use ==
// Connect data and clock outputs to data and clock inputs with
// loopback plug or external cabling. Alternatively, set
// settings.internal_loopback = True.
//
// == Two Port Use ==
// Connect ports with crossover cable that:
// - connects data output of each port to data input of other port
// - connects clock output of one port to clock inputs of both ports
// Run sample on both ports.

using System;
using System.Collections.Generic;
using System.Threading;
using System.ComponentModel;
using System.IO;
using Port = Microgate.SerialApi.Port;

namespace bisync
{
	class bisync
	{
		static bool run = true;

 		static void CancelKeyHandler(object sender, ConsoleCancelEventArgs e)
		{
			if (e.SpecialKey == ConsoleSpecialKey.ControlC) {
				Console.WriteLine("Ctrl-C pressed");
				run = false;
				e.Cancel = true;
			}
		}

		// Sample sync pattern. Actual values are application dependent.
		// Bisync protocol uses 16-bit sync pattern (LSB first).
		// Monosync protocol uses 8-bit sync pattern (LSB only).
		const byte SYNC_LSB = 0x67;
		const byte SYNC_MSB = 0x98;

		// Sample block boundary patterns. Actual values are application dependent.
		// These application level definitions are not used by the API.
		const byte START_OF_BLOCK = 0x55;
		const byte END_OF_BLOCK = 0xaa;

		public static void trim_before(ref byte[] buf, int index)
		{
			int size = buf.Length - index;
			byte[] newbuf = new byte[size];
			Array.Copy(buf, index, newbuf, 0, size);
			buf = newbuf;
		}

		public static void append(ref byte[] buf1, byte[] buf2)
		{
			if (buf2.Length == 0)
				return;
			if (buf1 == null) {
				buf1 = new byte[buf2.Length];
				Array.Copy(buf2, buf1, buf2.Length);
			} else {
				int index = buf1.Length;
				Array.Resize(ref buf1, buf1.Length + buf2.Length);
				Array.Copy(buf2, 0, buf1, index, buf2.Length);
			}
		}

		// Assemble receive data into application defined block bounded by
		// start/end of block bytes. One block may span multiple read() calls.
		// Sample block format will differ from actual application.
		//
		// - enable receiver (hardware searches for sync pattern)
		// - after sync detection, read() returns data byte aligned to sync
		// - call read() in loop looking for start/end of block bytes
		// - on block completion, disable receiver
		//
		// This sample assumes blocks are not byte aligned to each other.
		// The receiver is disabled after receiving a block and enabled to receive
		// next block to force search for sync pattern (and byte alignment)
		// for each block.
		//
		// Actual applications may send multiple byte aligned blocks.
		// In this case the receiver remains enabled between blocks. The application
		// is responsible for determining when the receiver must resync between blocks.
		public static byte[] receive_block(Port port)
		{
			byte[] block = null;  // assembled data block
			bool sob = false;  // start of block flag

			// Larger value increases latency to detect sob/eob.
			// Smaller value increases processing overhead.
			int read_size = 8;

			port.enable_receiver();

			while (run) {
				byte[] buf = port.read(read_size);
				if (buf == null)
					return null;
				// Console.WriteLine("<<< read {0} bytes", buf.Length);

				if (!sob) {
					int sob_index = Array.FindIndex(buf, b => b == START_OF_BLOCK);
					if (sob_index == -1)
						continue;
					// Console.WriteLine("<<< start of block");
					sob = true;
					// discard leading bytes
					trim_before(ref buf, sob_index);
				}

				int eob_index = Array.FindIndex(buf, b => b == END_OF_BLOCK);
				if (eob_index != -1) {
					// Console.WriteLine("<<< end of block");
					// discard trailing bytes
					Array.Resize(ref buf, eob_index + 1);
					append(ref block, buf);
					port.disable_receiver();
					return block;
				}

				append(ref block, buf);
			}

			// error or control-break, disable receiver
			port.disable_receiver();
			return null;
		}

		public static void ReceiveFunction(object data)
		{
			var port = (Port)data;

			int i = 1;
			while (true) {
				byte[] buf = receive_block(port);
				if (buf == null)
					break;
				Console.WriteLine("<<< {0:D9}: received {1} byte block", i, buf.Length);
				i += 1;
			}
		}

		static void Main(string[] args)
		{
			// port name format
			// single port adapter: MGHDLCx, x=adapter number
			// multiport adapter: MGMPxPy, x=adapter number, y=port number
			Port port;
			if (args.Length < 1) {
				// no port name on command line, use first enumerated port
				string[] names = Port.enumerate();
				if (names.Length == 0) {
					Console.WriteLine("No ports available.");
					System.Environment.Exit(1);
				}
				port = new Port(names[0]);
			} else {
				port = new Port(args[0]);
			}
			Console.WriteLine("HDLC/SDLC sample running on {0}", port.name);
			try {
				port.open();
			}
			catch (FileNotFoundException) {
				Console.WriteLine("port not found");
				System.Environment.Exit(1);
			}
			catch (UnauthorizedAccessException) {
				Console.WriteLine("access denied or port in use");
				System.Environment.Exit(1);
			}
			catch (Win32Exception) {
				Console.WriteLine("open error");
				System.Environment.Exit(1);
			}

			// If default 14.7456MHz base clock does not allow exact
			// internal clock generation of desired rate, uncomment these lines and
			// select a new base clock sourced from the frequency synthesizer.
			// PCI Express/USB only. See API manual for details.
			// uint fsynth_rate = 16000000;
			// if (port.set_fsynth_rate(fsynth_rate))
			// 	Console.WriteLine("base clock set to {0}", fsynth_rate);
			// else {
			// 	Console.WriteLine("{0} not supported by fsynth", fsynth_rate);
			// 	System.Environment.Exit(1);
			// }

			var settings = new Port.Settings();
			settings.protocol = Port.BISYNC;
			// settings.protocol = Port.MONOSYNC;
			if (settings.protocol == Port.BISYNC) {
				Console.WriteLine("Using Bisync protocol.");
				settings.sync_pattern = (SYNC_MSB << 8) | SYNC_LSB;
			} else {
				Console.WriteLine("Using Monosync protocol.");
				settings.sync_pattern = SYNC_LSB;
			}
			settings.encoding = Port.NRZ;
			settings.crc = Port.OFF;
			settings.transmit_clock = Port.TXC_INPUT;
			settings.receive_clock = Port.RXC_INPUT;
			settings.internal_clock_rate = 2400;
			port.apply_settings(settings);

			Console.CancelKeyPress += new ConsoleCancelEventHandler(CancelKeyHandler);
			Console.WriteLine("press Ctrl-C to stop program");

			port.enable_receiver();
			var receiveThread = new Thread(ReceiveFunction);
			receiveThread.Start(port);

			// prepare data block
			var block = new byte[100];
			block[0] = START_OF_BLOCK;
			block[block.Length - 1] = END_OF_BLOCK;

			// prepare leading sync(s)
			byte[] leading_sync;
			if (settings.protocol == Port.BISYNC) {
				leading_sync = new byte[] {SYNC_LSB, SYNC_MSB};
			} else {
				leading_sync = new byte[] {SYNC_LSB};
			}

			// prepare write buffer
			// Application MUST prepend leading sync pattern to block.
			// Some applications may require multiple leading sync patterns.
			byte[] buf = new byte[leading_sync.Length + block.Length];
			Array.Copy(leading_sync, buf, leading_sync.Length);
			Array.Copy(block, 0, buf, leading_sync.Length, block.Length);

			int i = 1;
			while (run) {
				Console.WriteLine(">>> {0:D9}: send {1} bytes", i, buf.Length);;
				port.write(buf);
				port.flush();
				i += 1;
			}
			port.close();
		}
	}
}
