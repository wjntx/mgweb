﻿// signal control and monitoring sample
//
// The RTS output should be connected to the CTS input.

using System;
using System.Collections.Generic;
using System.Threading;
using System.ComponentModel;
using System.IO;
using Port = Microgate.SerialApi.Port;

namespace signals
{
	class signals
	{
		static void Main(string[] args)
		{
			// port name format
			// single port adapter: MGHDLCx, x=adapter number
			// multiport adapter: MGMPxPy, x=adapter number, y=port number
			Port port;
			if (args.Length < 1) {
				// no port name on command line, use first enumerated port
				string[] names = Port.enumerate();
				if (names.Length == 0) {
					Console.WriteLine("No ports available.");
					System.Environment.Exit(1);
				}
				port = new Port(names[0]);
			} else {
				port = new Port(args[0]);
			}
			Console.WriteLine("signals sample running on {0}", port.name);
			try {
				port.open();
			}
			catch (FileNotFoundException) {
				Console.WriteLine("port not found");
				System.Environment.Exit(1);
			}
			catch (UnauthorizedAccessException) {
				Console.WriteLine("access denied or port in use");
				System.Environment.Exit(1);
			}
			catch (Win32Exception) {
				Console.WriteLine("open error");
				System.Environment.Exit(1);
			}


			Console.WriteLine("turn on RTS");
			port.rts = true;

			Console.WriteLine("wait 1 second for CTS on");
			// This blocks for 1 second waiting for CTS on.
			// port.wait() called without timeout argument waits forever.
			// A blocked wait can be cancelled with port.cancel_wait().
			uint events = port.wait(Port.CTS_ON, 1000);
			if ((events & Port.CTS_ON) != 0)
				Console.WriteLine("CTS is on");
			else
				Console.WriteLine("wait timed out or cancelled");

			Console.WriteLine("turn off RTS");
			port.rts = false;

			Console.WriteLine("poll for CTS off for 1 second");
			for (int i = 0 ; i < 10 ; i++) {
				if (!port.cts)
					break;
				Thread.Sleep(100);
			}
			Console.WriteLine("CTS is off");

			port.close();
		}
	}
}
