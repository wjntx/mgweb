

                   R E L E A S E   I N F O R M A T I O N

            MicroGate(R) MicroGate Serial API Run-Time-Kit for Windows

This package contains supporting software and device drivers for using
SyncLink serial hardware with third party applications on the Windows operating system.

This package extracts to C:\MGRTK by default. Refer to the MGRTK\rtk-windows.pdf file
for installation and configuration details for the RTK and hardware. This requires
a PDF viewer freely available from www.adobe.com.

Refer to the third party application vendor documentation for details on
application installation, hardware configuration and support contacts.