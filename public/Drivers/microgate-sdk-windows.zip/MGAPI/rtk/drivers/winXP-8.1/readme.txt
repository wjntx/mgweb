===============================
LEGACY SOFTWARE DIGITAL SIGNING
===============================

Microgate digitally signs its software.
Windows uses digital signing to verify the software source.
Early versions of Windows display warnings if drivers are not signed.
Later versions of Windows do not allow unsigned drivers.

Driver signing technology has evolved.
Early versions of Windows do not recognize current software signing.
Later versions of Windows do not allow older software signing.

This legacy driver package is signed with early signing technology
compatible with early Windows versions. It is not compatible with
later versions of Windows.

Windows versions supported by legacy driver package:
Windows XP/Server 2003
Windows Vista/Server 2008
Unpatched Windows 7/Unpatched Server 2008R2

Note:
Windows 7 and Server 2008R2 can be updated to recognize current signing technology.
Only use this legacy driver package with Windows 7/Server 2008R2 installations that
have not been updated.