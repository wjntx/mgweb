/*
 * loop HDLC/SDLC data using Microgate Serial API
 *
 * Use a single port with a loopback plug installed or
 * alter configure_port function for internal loopback.
 */

#include "stdafx.h"

/* global set by ctrl-C handler */
int stop_program = 0;
HANDLE dev_handle;

void sigint_handler(int sigid)
{
	stop_program = 1;
	// cancel blocked MgslRead/MgslWrite calls
	MgslCancelReceive(dev_handle);
	MgslCancelTransmit(dev_handle);
}

int configure_port(HANDLE dev)
{
	MGSL_PARAMS params;
	int rc;

	/*
	 * configure port for HDLC mode
	 * internal loopback disabled
	 * receiver clock source = RxC clock input
	 * transmit clock source = TxC clock input
	 * encoding = NRZ
	 * output clock on AUXCLK output at 19200 bps
	 * Use ITU CRC-16 frame checking
	 * disable HDLC address filtering (0xff)
	 */
	memset(&params, 0, sizeof(params));
	params.Mode = MGSL_MODE_HDLC;
	params.Loopback = 0;
	params.Flags = HDLC_FLAG_RXC_RXCPIN + HDLC_FLAG_TXC_TXCPIN;
	params.Encoding = HDLC_ENCODING_NRZ;
	params.ClockSpeed = 19200;
	params.CrcType = HDLC_CRC_16_CCITT;
	params.Addr = 0xff;

	rc = MgslSetParams(dev, &params);
	if (rc != NO_ERROR) {
		printf("MgslSetParams error=%d\n", rc);
		return rc;
	}
	
	/* set transmit idle pattern (sent between frames) */
	rc = MgslSetIdleMode(dev, HDLC_TXIDLE_ONES);
	if (rc != NO_ERROR) {
		printf("MgslSetIdleMode() error=%d", rc);
		return rc;
	}

	/* set blocked mode for MgslRead */
	rc = MgslSetOption(dev, MGSL_OPT_RX_POLL, 0);
	if (rc != NO_ERROR) {
		printf("MgslSetOption(MGSL_OPT_RX_POLL) error=%d", rc);
		return rc;
	}

	/* set MgslRead to return only error free data */
	rc = MgslSetOption(dev, MGSL_OPT_RX_ERROR_MASK, 1);
	if (rc != NO_ERROR) {
		printf("MgslSetOption(MGSL_OPT_RX_ERROR_MASK) error=%d", rc);
		return rc;
	}

	/* set blocked mode for MgslWrite and MgslWaitAllSent */
	rc = MgslSetOption(dev, MGSL_OPT_TX_POLL, 0);
	if (rc != NO_ERROR)
		printf("MgslSetOption(MGSL_OPT_TX_POLL) error=%d", rc);

	return rc;
}

/*
 * display a buffer of data in hex format, 16 bytes per line
 */
void display_buf(unsigned char *buf, unsigned int size)
{
	unsigned int i;

	for (i = 0 ; i < size ; i++) {
		if (!(i % 16))
			printf("%04X: ", i);
		if (i % 16 == 15)
			printf("%02X\n", *buf++);
		else
			printf("%02X ", *buf++);
	}
	if (i % 16)
			printf("\n");
}

DWORD WINAPI receive_thread_func(LPVOID context)
{
	HANDLE dev = *((HANDLE*)context);
	DWORD rc;
	unsigned int i;
	unsigned int count;
	unsigned char buf[4096]; /* choose size to hold largest expected frame */

	/* receiver must be enabled to receive data */
	rc = MgslEnableReceiver(dev, TRUE);
	if (rc != NO_ERROR)
		return rc;

	i = 1;
	while (!stop_program) {
		// - MgslRead returns one HDLC frame.
		// - Buffer contains HDLC information field including
		//   application defined address and control fields.
		// - HDLC flags and CRC are discarded and NOT included in the buffer.
		count = MgslRead(dev, buf, sizeof(buf));
		if (!count)
			break;
		printf("<<< %09d receive %d bytes\n", i, count);
//		display_buf(buf, count);
		i++;
	}

	return 0;
}

void display_usage()
{
	printf("\nusage: loop <devicename>\n"
		   "Examples:\n"
           "C:>loop MGMP4P2  (adapter #4 port #2 of multiport adapter)\n"
		   "C:>loop MGHDLC1  (single port adapter adapter #1)\n"
		   "Device names are displayed in the SyncLink branch\n"
		   "of the Windows device manager.\n\n");
}

int _tmain(int argc, _TCHAR* argv[])
{
	HANDLE dev;
	HANDLE receive_thread;
	int rc;
	unsigned int i;
	unsigned char buf[1024];
	unsigned int size = sizeof(buf);
	char dev_name[MAX_PATH];

	if (argc < 2) {
		display_usage();
		return 1;
	}
	sprintf_s(dev_name, sizeof(dev_name), "%S", argv[1]); /* convert to char */
	printf("looping HDLC/SDLC data on %s\n", dev_name);

	rc = MgslOpenByName(dev_name, &dev);
	if (rc != NO_ERROR) {
		printf("MgslOpenByName error=%d\n", rc);
		return rc;
	}

	rc = configure_port(dev);
	if (rc != NO_ERROR)
		goto done;

	dev_handle = dev;
	signal(SIGINT, sigint_handler);
	printf("press Ctrl-C to stop program\n");

	receive_thread = CreateThread(NULL, 0, receive_thread_func, &dev, 0, NULL);

	/* initialize send buffer */
	for (i=0 ; i < size ; i++)
		buf[i] = (unsigned char)i;

	i = 1;
	while (!stop_program) {
		printf(">>> %09d sending %d bytes\n", i, size);
		// - MgslWrite sends one HDLC frame.
		// - Application buffer contains information field of the HDLC frame,
		//   including application defined address and control fields.
		// - HDLC formatting is done by hardware (add flags, CRC, zero insertion).
		// - Data is copied to API send buffers and sent as soon as possible,
		//   use MgslWaitAllSent to determine when all buffered data has been sent.
		rc = MgslWrite(dev, buf, size);
		if (!rc)
			printf("MgslWrite error=%d\n", GetLastError());
		i++;
	}

	printf("waiting for all data sent...\n");
	rc = MgslWaitAllSent(dev);
	if (!rc)
		printf("all data sent\n");
	else
		printf("MgslWaitAllSent error=%d\n", rc);

done:
	MgslClose(dev);
	return 0;
}
