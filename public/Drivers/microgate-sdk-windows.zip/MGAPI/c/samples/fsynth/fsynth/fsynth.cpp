/*
 * This code programs the frequency synthesizer on the SyncLink GT2e/GT4e
 * PCI express serial adapters and SyncLink USB device to a specified frequency
 * and selects the synthesizer output as the adapter base clock. ONLY the GT2e/GT4e
 * cards and SyncLink USB device have this feature. Copy and paste this code into
 * applications that require a non-standard base clock frequency.
 *
 * SyncLink GT family serial adapters have a fixed 14.7456MHz base clock.
 * The serial controller generates data clocks by dividing the base clock
 * by an integer. Only discrete data clock values can be generated
 * exactly from a given base clock frequency. When an exact data clock
 * value is required that cannot be derived by dividing 14.7456MHz by
 * and integer, a different base clock value must be used. One way to
 * do this is special ordering a different fixed base clock which is
 * installed at the factory.
 *
 * The SyncLink GT2e, GT4e and USB serial devices have both
 * a 14.7456MHz fixed base clock and a variable frequency synthesizer.
 * The serial controller can use either as the base clock.
 *
 * The frequency synthesizer is an Integrated Device Technologies (IDT)
 * ICS307-3 device. The reference clock input to the synthesizer is
 * the fixed 14.7456MHz clock.
 * GT2E/GT4E uses synthesizer CLK1 output
 * USB uses synthesizer CLK3 output
 * Refer to the appropriate hardware user's manual for more details.
 *
 * The synthesizer SPI programming interface is connected to the serial
 * controller general purpose I/O signals. The GPIO portion of the serial
 * API is used to program the synthesizer with a 132 bit word. This word
 * is calculated using the IDT Versaclock software available at www.idt.com
 *
 * Contact Microgate for help in producing a programming word for a specific
 * frequency output. Several common frequencies are included in this code.
 * Maximum supported base clock is 66MHz
 *
 * Note:
 * After programming the frequency synthesizer and selecting it
 * as the base clock, each individual port of a card must be configured with
 * MgslSetOption(fd, MGSL_OPT_CLOCK_BASE_FREQ, freq_value);
 *
 * This allows the device driver to correctly calculate divisors
 * for a specified data clock rate. All ports on a card share
 * a common base clock.
 */

#include "stdafx.h"

/*
 * set one or more GPIO outputs to a specified value
 *
 * bit   bit mask identifies which GPIO output to set
 * val   new value for outputs identified by bit
 */
void set_gpio(HANDLE dev, int bit, int val)
{
	GPIO_DESC gpio;

	gpio.state = (val << bit);
	gpio.smask = (1 << bit);
	gpio.dmask = 0; /* unused */
	gpio.dir   = 0; /* unused */
	
	MgslSetGpio(dev, &gpio);
}

/*
 * set_mux    select between fixed base clock (0) and freq synth (1)
 * set_clk    set SPI CLK pin value
 * set_select set SPI CS pin value
 * set_data   set SPI DI pin value
 */

/* GPIO bit positions for GT2E/GT4E cards */
#define GT4E_MUX  15
#define GT4E_CLK  14
#define GT4E_SEL  13
#define GT4E_DATA 12

/* GPIO bit positions for USB device */
#define USB_MUX   23
#define USB_CLK   22
#define USB_SEL   21
#define USB_DATA  20

/* GPIO bit positions (must be initialized for correct device type) */
int gpio_mux;
int gpio_clk;
int gpio_sel;
int gpio_data;

#define set_mux(dev, val)    set_gpio((dev), gpio_mux, (val))
#define set_clk(dev, val)    set_gpio((dev), gpio_clk, (val))
#define set_select(dev, val) set_gpio((dev), gpio_sel, (val))
#define set_data(dev, val)   set_gpio((dev), gpio_data, (val))

/*
 * Each frequency table entry contains an output frequency
 * and the associated 132 bit synthesizer programming word
 * to produce the frequency.
 *
 * The programming word comes from the Versaclock 2 software
 * parsed into 5 32-bit integers. The final 4 bits are placed
 * in the most significant 4 bits of the final 32-bit integer.
 */

struct freq_table_entry {
	unsigned int freq;    /* output frequency */
	unsigned int data[5]; /* device programming word */
};

/*
 * GT2e/GT4e
 *
 * Base Clock = dedicated 14.7456MHz oscillator
 *
 * ICS307-3 (clock):
 * - reference clock = 14.7456MHz oscillator
 * - VDD = 3.3V
 * - CLK1 (pin 8) output drives FPGA fsynth input
 */
struct freq_table_entry gt4e_table[] =
{
	{12288000, {0x29BFDC00, 0x61200000, 0x00000000, 0x0000A5FF, 0xA0000000}},
	{14745600, {0x38003C05, 0x24200000, 0x00000000, 0x000057FF, 0xA0000000}},
	{16000000, {0x280CFC02, 0x64A00000, 0x00000000, 0x000307FD, 0x20000000}},
	{16384000, {0x08001402, 0xA1200000, 0x00000000, 0x0000A5FF, 0xA0000000}},
	{19660800, {0x08001403, 0xE1200000, 0x00000000, 0x0000A1FF, 0xA0000000}},
	{20000000, {0x00001403, 0xE0C00000, 0x00000000, 0x00045E02, 0xF0000000}},
	{23040000, {0x08001404, 0xA0A00000, 0x00000000, 0x0003A7FC, 0x60000000}},
	{24000000, {0x00001404, 0xE1400000, 0x00000000, 0x0003D5FC, 0x20000000}},
	{28800000, {0x18001405, 0x61A00000, 0x00000000, 0x0000EBFF, 0x60000000}},
	{30000000, {0x20267C05, 0x64C00000, 0x00000000, 0x00050603, 0x30000000}},
	{32000000, {0x21BFDC00, 0x5A400000, 0x00000000, 0x0004D206, 0x30000000}},
	{33200000, {0x00001400, 0xD8C00000, 0x00000000, 0x0005E204, 0xB0000000}},
	{33320000, {0x08001400, 0xD8A00000, 0x00000000, 0x0001C7FE, 0x60000000}},
	{38400000, {0x00001406, 0xE1800000, 0x00000000, 0x00098009, 0xF0000000}},
	{50000000, {0x00001400, 0x58C00000, 0x00000000, 0x0005E604, 0x70000000}},
	{64000000, {0x21BFDC00, 0x12000000, 0x00000000, 0x000F5E14, 0xF0000000}},
	{0, {0, 0, 0, 0, 0}} /* final entry must have zero freq */
};

/*
 * SyncLink USB
 *
 * Base Clock = ICS307-3 CLK1 (pin 8) output (power up default = 14.7456MHz)
 *
 * ICS307-3 (xtal):
 * - reference clock = 14.7456MHz xtal
 * - VDD = 3.3V
 * - CLK3 (pin 14) output drives FPGA fsynth input
 * - CLK1 (pin 8)  output drives FPGA base clock input
 *
 * Note: CLK1 and CLK3 outputs must always be driven to prevent floating
 * clock inputs to the FPGA. When calculating programming word with Versaclock,
 * select same output on CLK1 and CLK3 or select CLK1 as multiple of CLK3.
 */
struct freq_table_entry usb_table[] =
{
	{12288000, {0x28401400, 0xE5200000, 0x00000000, 0x00009BFF, 0xA0000000}},
	{14745600, {0x28481401, 0xE5200000, 0x00000000, 0x0000A5FF, 0xA0000000}},
	{16000000, {0x284C1402, 0x64A00000, 0x00000000, 0x000307FD, 0x20000000}},
	{16384000, {0x28501402, 0xE4A00000, 0x00000000, 0x0001F9FE, 0x20000000}},
	{19660800, {0x38541403, 0x65A00000, 0x00000000, 0x0000B1FF, 0xA0000000}},
	{20000000, {0x205C1404, 0x65400000, 0x00000000, 0x00068205, 0xF0000000}},
	{23040000, {0x38601404, 0xE5A00000, 0x00000000, 0x0001B3FE, 0x60000000}},
	{24000000, {0x20601404, 0xE5400000, 0x00000000, 0x0003D5FC, 0x20000000}},
	{28800000, {0x38641405, 0x65A00000, 0x00000000, 0x0000EBFF, 0x60000000}},
	{30000000, {0x20641405, 0x64C00000, 0x00000000, 0x00050603, 0x30000000}},
	{32000000, {0x206C1406, 0x65400000, 0x00000000, 0x00049E03, 0xF0000000}},
	{33200000, {0x20681405, 0xE4C00000, 0x00000000, 0x00061804, 0x70000000}},
	{33320000, {0x21FBB800, 0x05400000, 0x00000000, 0x00038BFC, 0x20000000}},
	{38400000, {0x20701406, 0xE5800000, 0x00000000, 0x00098009, 0xF0000000}},
	{45056000, {0x28701406, 0xE4200000, 0x00000000, 0x000217FE, 0x20000000}},
	{50000000, {0x20741407, 0x65400000, 0x00000000, 0x00068205, 0xF0000000}},
	{64000000, {0x20781400, 0x4D400000, 0x00000000, 0x00049E03, 0xF0000000}},
	{0, {0, 0, 0, 0, 0}} /* final entry must have zero freq */
};

struct freq_table_entry *freq_table;

void display_usage()
{
	printf("Usage: fsynth devicename\n"
		   "devicename is text identifier of port (ex:MGHDLC1)\n"
		   "if devicename is *, first available device is used\n\n");
	exit(1);
}

/*
 * program frequency synthesizer with data for specified output frequency
 *
 * Notes:
 * - programming data for freq must be generated with Versaclock software
 *   and converted into a table entry for the device type
 * - if programming data not found for freq, nothing is done
 *
 */
void set_clock_word(HANDLE dev, unsigned int freq)
{
	int i;
	unsigned int dword_val = 0;
	struct freq_table_entry *entry;
	unsigned int *data = NULL;

	/* search for entry for requested output frequency */

	for (entry = freq_table ; entry->freq ; entry++) {
		if (entry->freq == freq) {
			printf("Found programming information for output frequency = %luHz\n", freq);
			data = entry->data;
			break;
		}
	}
	if (!data) {
		printf("No programming information for output frequency = %luHz\n", freq);
		printf("Use Versaclock software to create programming information.\n");
		printf("Operation aborted.\n");
		return;
	}

	set_clk(dev, 0);

	/* write 132 bit clock program word */

	for (i = 0 ; i < 132 ; i++) {
		if (!(i % 32))
			dword_val = data[i/32];
		set_data(dev, (dword_val & (1 << 31)) ? 1 : 0);
		set_clk(dev, 1);
		set_clk(dev, 0);
		dword_val <<= 1;
	}

	set_select(dev, 1);
	set_select(dev, 0);
}

/*
 * select the frequency table and GPIO pins appropriate for the specified device
 * (USB or GT2e/GT4e)
 */
int select_configuration(char *name)
{
	ULONG i;
	ULONG rc;
	ULONG count;
	ULONG device_id;
	int size;
	MGSL_PORT *ports;

	rc = MgslEnumeratePorts(NULL, 0, &count);
	if (rc != NO_ERROR) {
		fprintf(stderr, "MgslEnumeratePorts() failed, rc=%d\n", rc);
		return 0;
	}

	if (!count) {
		fprintf(stderr, "No ports found\n");
		return 0;
	}

	size = count * sizeof(MGSL_PORT);
	ports = (MGSL_PORT *)malloc(size);
	if (ports == NULL) {
		fprintf(stderr, "malloc failed\n");
		return 0;
	}

	rc = MgslEnumeratePorts(ports, size, &count);
	if (rc != NO_ERROR) {
		fprintf(stderr, "MgslEnumeratePorts() failed, rc=%d\n", rc);
		goto error;
	}

	for (i=0; i < count; i++) {
		if (!_stricmp(ports[i].DeviceName, name)) {
			device_id = ports[i].DeviceID;
			goto found;
		}
	}
	printf("unable to determine device type (device name not found)\n");

error:
	free(ports);
	return 0;

found:
	/* assign correct GPIO pins and freq table for device type */
	switch (device_id) {
	case SYNCLINK_USB_DEVICE_ID:
		gpio_mux   = USB_MUX;
		gpio_clk   = USB_CLK;
		gpio_sel   = USB_SEL;
		gpio_data  = USB_DATA;
		freq_table = usb_table;
		printf("using USB hardware configuration\n");
		break;
	default:
		gpio_mux   = GT4E_MUX;
		gpio_clk   = GT4E_CLK;
		gpio_sel   = GT4E_SEL;
		gpio_data  = GT4E_DATA;
		freq_table = gt4e_table;
		printf("using GT2e/GT4e hardware configuration\n");
	}
	free(ports);
	return 1;
}


int _tmain(int argc, _TCHAR* argv[])
{
	HANDLE dev;
	char dev_name[MAX_PATH];
	ULONG rc;

	/* edit this to select desired entry from frequency table */
	unsigned int rate = 38400000;
	
	if (argc < 2)
		display_usage();
	sprintf_s(dev_name, sizeof(dev_name), "%S", argv[1]); /* convert to char */
	printf("setting frequency synthesizer rate on %s\n", dev_name);

	/* select configuration based on hardware type */
	if (!select_configuration(dev_name)) {
		return 1;
	}

	rc = MgslOpenByName(dev_name, &dev);
	if (rc != NO_ERROR) {
		printf("MgslOpenByName() failed, rc=%d\r\n", rc);
		return 1;
	}

	/* program frequency synthesizer for desire rate */
	set_clock_word(dev, rate);

	/* select frequency synthesizer as the base clock */
	set_mux(dev, 1);

	/* set base clock value for port (repeat for all ports on adapters with multiple ports) */
	MgslSetOption(dev, MGSL_OPT_CLOCK_BASE_FREQ, rate);
	
	MgslClose(dev);
	return 0;
}

