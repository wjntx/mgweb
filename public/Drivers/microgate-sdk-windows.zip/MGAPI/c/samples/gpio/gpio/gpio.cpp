/*
 * Console application demonstrating general purpose I/O (GPIO) API calls
 *
 * Note: The availability of GPIO pins differs between SyncLink products.
 * Consult the hardware user's manual PDF for details.
 *
 * This program either toggles an output or monitors an input for changes
 * depending on the command line arguments.
 *
 * run with 'w' option to wait for and report transitions
 * on an input signal
 *
 * run with 't' option to toggle an output
 *
 * The specific bits used for output and input are specified by
 * the macros OUT_SIGNAL and IN_SIGNAL below. Modify the as appropriate for a
 * specific application and SyncLink product.
 */
#include "stdafx.h"

/* output signal pin number to toggle */
#define OUT_SIGNAL 5

/* input signal pin number to monitor */
#define IN_SIGNAL 12

/* bits that correspond to signals */
#define OUT_BIT (1 << (OUT_SIGNAL - 1))
#define IN_BIT  (1 << (IN_SIGNAL - 1))

void set_direction(HANDLE dev);
void toggle_gpio(HANDLE dev);
void wait_gpio(HANDLE dev);

/*
 * set I/O signals to inputs, except signal specified by OUT_SIGNAL
 */
void set_direction(HANDLE dev)
{
	GPIO_DESC gpio;
	ULONG rc;

	/* set to all inputs except specified output */
	memset(&gpio, 0, sizeof(gpio));
	gpio.dmask = 0xffffffff;
	gpio.dir   = OUT_BIT;
	printf("Set signal #%d as output, all others as input\n", OUT_SIGNAL);

	rc = MgslSetGpio(dev, &gpio);
	if (rc != NO_ERROR)
		fprintf(stderr, "MgslSetGpio failed, rc=%d\n", rc);
}

/*
 * toggle OUT_SIGNAL every 500ms
 * demonstrate setting signal state and polling signal states
 */
void toggle_gpio(HANDLE dev)
{
	GPIO_DESC gpio;
	GPIO_DESC gpio_get;
	ULONG rc;
	ULONG i;

	memset(&gpio, 0, sizeof(gpio));
	gpio.smask = OUT_BIT;

	for (i=1;;i++) {
		printf("%09d set output #%d to %d\n",
				i, OUT_SIGNAL, gpio.state & gpio.smask ? 1:0);
		rc = MgslSetGpio(dev, &gpio);
		if (rc != NO_ERROR) {
			fprintf(stderr, "MgslSetGpio failed, rc=%d\n", rc);
			break;
		}
		rc = MgslGetGpio(dev, &gpio_get);
		if (rc != NO_ERROR) {
			fprintf(stderr, "MgslGetGpio failed, rc=%d\n", rc);
			break;
		}
		if ((gpio.smask & gpio.state) != (gpio.smask & gpio_get.state)) {
			fprintf(stderr, "unable to set correct state\n");
			break;
		}
		gpio.state ^= gpio.smask;
		Sleep(500);
	}
}

/*
 * wait for and report transitions on IN_SIGNAL
 */
void wait_gpio(HANDLE dev)
{
	OVERLAPPED ol;
	GPIO_DESC gpio;
	ULONG rc;
	ULONG i;

	ol.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	if (ol.hEvent == NULL) {
		fprintf(stderr, "can't allocate event, error=%d\r\n", GetLastError());
		return;
	}

	memset(&gpio, 0, sizeof(gpio));
	gpio.smask = IN_BIT;

	for (i=1;;i++) {
		printf("%09d wait for input #%d to be %d...",
			i, IN_SIGNAL, gpio.smask & gpio.state ? 1:0);

		ResetEvent(ol.hEvent);

		rc = MgslWaitGpio(dev, &gpio, &ol);

		if (rc == NO_ERROR) {
			printf("input is already %d\n", gpio.smask & gpio.state ? 1:0);
		} else if (rc == ERROR_IO_PENDING) {
			rc = WaitForSingleObject(ol.hEvent, INFINITE);
			if (rc != WAIT_OBJECT_0) {
				fprintf(stderr, "WaitForSingleObject() failed, rc=%d\n", rc);
				break;
			}
			printf("wait complete\n");
		} else {
			fprintf(stderr, "MgslWaitGpio() failed rc=%d\n", rc);
			break;;
        }

		gpio.state ^= gpio.smask;
	}

	CloseHandle(ol.hEvent);
}

void display_usage()
{
	printf("Usage: gpio <w|t> devicename\n"
		   "w = wait and report input transitions\n"
		   "t = toggle output\n"
		   "devicename is text identifier of port (ex:MGHDLC1)\n"
		   "if devicename is *, first available device is used\n\n");
	exit(1);
}

/*
 * program entry point
 * arg[1] = role option 'w' or 't'
 * arg[2] = device name
 */
int _tmain(int argc, _TCHAR* argv[])
{
	ULONG rc;
	char dev_name[MAX_PATH];
	HANDLE dev;
	int role;

	if (argc < 3)
		display_usage();

	if (!wcscmp(argv[1], TEXT("w")))
		role = 0;
	else if (!wcscmp(argv[1], TEXT("t")))
		role = 1;
	else
		display_usage();

	sprintf_s(dev_name, sizeof(dev_name), "%S", argv[2]); /* convert to char */
	printf("GPIO example program\n", dev_name);
	printf("device=%s role=%s\n", dev_name, role == 0 ? "wait":"toggle");

	rc = MgslOpenByName(dev_name, &dev);
	if (rc != NO_ERROR) {
		fprintf(stderr, "MgslOpenByName() failed, rc=%d\r\n", rc);
		return 1;
	}

	/* program GPIO pins as input or output */
	set_direction(dev);

	if (role == 0) {
		/* wait for changes on inputs */
		wait_gpio(dev);
	} else {
		/* toggle output states */
		toggle_gpio(dev);
	}

	MgslClose(dev);
	return 0;
}

