/*
 * 2-wire (bussed) HDLC/SDLC protocol sample
 *
 * This sample implements the special case of "2 wire" or bussed mode where
 * send and receive data signals use the same wires and there are no external clocks.
 * Send signals must be disabled when not sending to allow other stations to send.
 * The receive clock must be recovered from the receive data signal.
 * The application must implement a protocol to prevent multiple stations from
 * trying to send at the same time.
 *
 * Use a single port with a loopback plug installed or
 * alter configure_port function for internal loopback.
 */

#include "stdafx.h"

/* global set by ctrl-C handler */
int stop_program = 0;
HANDLE dev_handle;

void sigint_handler(int sigid)
{
	stop_program = 1;
	// cancel blocked MgslRead/MgslWrite calls
	MgslCancelReceive(dev_handle);
	MgslCancelTransmit(dev_handle);
}

int get_port_id(char *name)
{
	unsigned long i, rc, count;
	int port_id = 0;
	MGSL_PORT *ports;

	/* get count of available ports */
	rc = MgslEnumeratePorts(NULL, 0, &count);
	if (rc != NO_ERROR) {
		printf("MgslEnumeratePorts() error=%d\n", rc);
		return 0;
	}
	if (!count)
		return 0;

	/* allocate memory to hold port information */
	ports = (MGSL_PORT *)malloc(count * sizeof(MGSL_PORT));
	if (ports == NULL) {
		printf("memory allocation failed\n");
		return 0;
	}

	/* get port information */
	rc = MgslEnumeratePorts(ports, count * sizeof(MGSL_PORT), &count);
	if (rc != NO_ERROR) {
		printf("MgslEnumeratePorts() error=%d\n", rc);
		goto done;
	}

	/* search for entry with matching name */
	for (i=0; i < count; i++) {
		if (!_stricmp(ports[i].DeviceName, name)) {
			port_id = ports[i].PortID;
			break;
		}
	}

done:
	free(ports);
	return port_id;
}

/*
 * set RTS driver control default to preserve setting across system restarts
 *
 * This is equivalent to the setting of the same name in the 'Advanced' tab
 * of the device properties in the Windows device manager.
 *
 * This does not take effect until the system is restarted.
 * Use MgslSetOption() to immediately set RTS driver control option.
 *
 * dev_name : device name (MGHDLC1, MGMP3P2, etc)
 * enabled  : TRUE=enabled, FALSE=disabled (normal) 
 */
void set_rts_driver_control_default(char *dev_name, bool enabled)
{
	MGSL_PORT_CONFIG_EX cfg;
	ULONG rc;
	int port_id;
	
	/* convert device name to port ID used by MgslGetPortConfigEx */
	port_id = get_port_id(dev_name);
	if (port_id == 0) {
		printf("No such port %s\n", dev_name);
		return;
	}

	rc = MgslGetPortConfigEx(port_id, &cfg);
	if (rc != NO_ERROR)
		printf("MgslGetPortConfigEx error=%d\n", rc);
		
	if (enabled)
		cfg.Flags |= MGSL_RTS_DRIVER_CONTROL;
	else
		cfg.Flags &= ~MGSL_RTS_DRIVER_CONTROL;
	
	rc = MgslSetPortConfigEx(port_id, &cfg);
	if (rc != NO_ERROR)
		printf("MgslSetPortConfigEx error=%d\n", rc);
}

int configure_port(HANDLE dev)
{
	MGSL_PARAMS params;
	int rc;

	/*
	 * configure port for HDLC mode
	 * loopback disabled
	 * receiver clock source = DPLL clock recovery from receive data signal
	 * transmit clock source = internal baud rate generator
	 * encoding = biphase level (Manchester)
	 * transmit preamble is 8 bits of flag pattern (aids remote clock recovery)
	 * data rate = 19200 bps
	 * Use ITU CRC-16 frame checking
	 * disable HDLC address filtering (0xff)
	 *
	 * notes:
	 * 1. biphase type encodings (FM0,FM1,Manchester) are usually used for
	 *    DPLL clock recovery to guarantee transitions every cycle on data line
	 * 2. DPLL works by sampling receive data using a reference clock at x8 or x16
	 *    the data rate as selected by HDLC_FLAG_DPLL_DIV16 and HDCL_FLAG_DPLL_DIV8.
	 */
	memset(&params, 0, sizeof(params));
	params.Mode = MGSL_MODE_HDLC;
	params.Loopback = 0;
	params.Flags = HDLC_FLAG_RXC_DPLL + HDLC_FLAG_TXC_BRG + HDLC_FLAG_DPLL_DIV16;
	params.Encoding = HDLC_ENCODING_BIPHASE_LEVEL;
	params.PreamblePattern = HDLC_PREAMBLE_PATTERN_FLAGS;
	params.PreambleLength = HDLC_PREAMBLE_LENGTH_8BITS;
	params.ClockSpeed = 19200;
	params.CrcType = HDLC_CRC_16_CCITT;
	params.Addr = 0xff;

	rc = MgslSetParams(dev, &params);
	if (rc != NO_ERROR) {
		printf("MgslSetParams error=%d\n", rc);
		return rc;
	}
	
	/* set transmit idle pattern (sent between frames) */
	rc = MgslSetIdleMode(dev, HDLC_TXIDLE_ONES);
	if (rc != NO_ERROR) {
		printf("MgslSetIdleMode() error=%d", rc);
		return rc;
	}

	/*
	 * Enable driver outputs only when RTS is active.
	 * Even though RTS is not used externally during 2-wire mode,
	 * it is used internally as an output driver enable:
	 * Turn on RTS to send, turn off RTS to receive.
	 *
	 * This call selects the RTS driver control option at run time.
	 * This option can also be saved to take effect at driver load time
	 * and be preserved across reboots as demonstrated in the
	 * function set_rts_driver_control_default.
	 */
	rc = MgslSetOption(dev, MGSL_OPT_RTS_DRIVER_CONTROL, 1);
	if (rc != NO_ERROR) {
		printf("MgslSetOption(MGSL_OPT_RTS_DRIVER_CONTROL) error=%d\n", rc);
		return rc;
	}
		
	/* set blocked mode for MgslRead */
	rc = MgslSetOption(dev, MGSL_OPT_RX_POLL, 0);
	if (rc != NO_ERROR) {
		printf("MgslSetOption(MGSL_OPT_RX_POLL) error=%d", rc);
		return rc;
	}

	/* set MgslRead to return only error free data */
	rc = MgslSetOption(dev, MGSL_OPT_RX_ERROR_MASK, 1);
	if (rc != NO_ERROR) {
		printf("MgslSetOption(MGSL_OPT_RX_ERROR_MASK) error=%d", rc);
		return rc;
	}

	/* set blocked mode for MgslWrite and MgslWaitAllSent */
	rc = MgslSetOption(dev, MGSL_OPT_TX_POLL, 0);
	if (rc != NO_ERROR)
		printf("MgslSetOption(MGSL_OPT_TX_POLL) error=%d", rc);

	return rc;
}

DWORD WINAPI receive_thread_func(LPVOID context)
{
	HANDLE dev = *((HANDLE*)context);
	DWORD rc;
	unsigned int i;
	unsigned int count;
	unsigned int size = 1024;
	unsigned char buf[4096];

	/* receiver must be enabled to receive data */
	rc = MgslEnableReceiver(dev, TRUE);
	if (rc != NO_ERROR)
		goto done;

	i = 1;
	while (!stop_program) {
		// - MgslRead returns one HDLC frame.
		// - Buffer contains HDLC information field including
		//   application defined address and control fields.
		// - HDLC flags and CRC are discarded and NOT included in the buffer.
		count = MgslRead(dev, buf, sizeof(buf));
		if (!count)
			break;
		printf("<<< %09d receive %d bytes\n", i, count);
		i++;
	}

done:
	return rc;
}

void display_usage()
{
	printf("\nusage: loop <devicename>\n"
		   "Examples:\n"
           "C:>loop MGMP4P2  (adapter #4 port #2 of multiport adapter)\n"
		   "C:>loop MGHDLC1  (single port adapter adapter #1)\n"
		   "Device names are displayed in the SyncLink branch\n"
		   "of the Windows device manager.\n\n");
}

int _tmain(int argc, _TCHAR* argv[])
{
	HANDLE dev;
	HANDLE receive_thread;
	int rc;
	unsigned int i;
	unsigned int size = 1024;
	unsigned char buf[4096];
	char dev_name[MAX_PATH];

	if (argc < 2) {
		display_usage();
		return 1;
	}
	sprintf_s(dev_name, sizeof(dev_name), "%S", argv[1]); /* convert to char */
	printf("looping HDLC/SDLC data on %s\n", dev_name);

	rc = MgslOpenByName(dev_name, &dev);
	if (rc != NO_ERROR) {
		printf("MgslOpenByName error=%d\n", rc);
		return rc;
	}

	rc = configure_port(dev);
	if (rc != NO_ERROR)
		goto done;
	set_rts_driver_control_default(dev_name, true);

	dev_handle = dev;
	signal(SIGINT, sigint_handler);
	printf("press Ctrl-C to stop program\n");

	receive_thread = CreateThread(NULL, 0, receive_thread_func, &dev, 0, NULL);

	/* initialize send buffer */
	for (i=0 ; i < size ; i++)
		buf[i] = (unsigned char)i;

	i = 1;
	while (!stop_program) {
		printf(">>> %09d sending %d bytes\n", i, size);

		/* turn on RTS to enable outputs */
		rc = MgslSetSerialSignals(dev, SerialSignal_RTS);
		if (rc != NO_ERROR) {
			printf("MgslSetSerialSignals(RTS on) error=%d\n", rc);
			goto done;
		}

		// turn off receiver when sending so we don't receive our own data
		// NOTE: for this loopback sample, leave receiver on all the time
		//       since the intention is to receive our own data
//		rc = MgslEnableReceiver(dev, FALSE);
//		if (rc != NO_ERROR) {
//			printf("MgslEnableReceiver(off) error=%d\n", rc);
//			goto done;
//		}

		/* give data to API to send */
		rc = MgslWrite(dev, buf, size);
		if (!rc)
			printf("MgslWrite error=%d\n", GetLastError());

		/* wait for data to be completely sent */
		rc = MgslWaitAllSent(dev);
		if (rc)
			printf("MgslWaitAllSent error=%d\n", rc);

		// turn on receiver when not sending
		// NOTE: for this loopback sample, leave receiver on all the time
		//       since the intention is to receive our own data
//		rc = MgslEnableReceiver(dev, TRUE);
//		if (rc != NO_ERROR) {
//			printf("MgslEnableReceiver(on) error=%d\n", rc);
//			goto done;
//		}

		/* turn off RTS to disable outputs and allow remote to send */
		rc = MgslSetSerialSignals(dev, 0);
		if (rc != NO_ERROR) {
			printf("MgslSetSerialSignals(RTS on) error=%d\n", rc);
			goto done;
		}

		i++;
	}

done:
	/* restore RTS driver control option */
	MgslSetOption(dev, MGSL_OPT_RTS_DRIVER_CONTROL, 0);
	set_rts_driver_control_default(dev_name, false);
	MgslClose(dev);
	return 0;
}
