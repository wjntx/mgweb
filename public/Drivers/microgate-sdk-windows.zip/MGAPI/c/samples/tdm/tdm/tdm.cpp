/*
 * Time Division Multiplexing (TDM) protocol sample
 *
 * Use a single port with external loopback device or cable attached.
 *
 * NOTE:
 * The loopback plug supplied with the SyncLink device is not compatible with
 * this sample loopback code. The following connections are required:
 *
 * TxD    --> RxD (send data output to receive data input)
 * RTS    --> DCD (sync pulse output to sync pulse input)
 * AUXCLK --> RxC (send clock output to receive clock input)
 */

#include "stdafx.h"

/*
 * global options used in configure_port() function
 * edit these options to match a particular TDM format
 *
 * sync to data delay options (choose one)
 * TDM_SYNC_DELAY_NONE, TDM_SYNC_DELAY_1BIT, TDM_SYNC_DELAY_2BITS
 *
 * transmitter sync pulse length (choose one)
 * TDM_TX_SYNC_WIDTH_SLOT, TDM_TX_SYNC_WIDTH_BIT
 * Note: receiver always works with either slot or bit width syncs
 *
 * sync pulse polarity (choose one)
 * TDM_SYNC_POLARITY_NORMAL (low line signal)
 * TDM_SYNC_POLARITY_INVERT (high line signal)
 *
 * number of frames returned per MgslReceive call (1-256)
 * TDM_RX_FRAME_COUNT(frame_count)
 *
 * number of slots per frame (384 or 2-32)
 * TDM_SLOT_COUNT(slot_count)
 *
 * number of bits per slot (choose one, 8 to 32, increments of 4)
 * TDM_SLOT_SIZE_8BITS
 * TDM_SLOT_SIZE_12BITS
 * TDM_SLOT_SIZE_16BITS
 * TDM_SLOT_SIZE_20BITS
 * TDM_SLOT_SIZE_24BITS
 * TDM_SLOT_SIZE_28BITS
 * TDM_SLOT_SIZE_32BITS
 *
 * bit order (choose one)
 * BIT_ORDER_LSB_FIRST = least significant bit is sent first on line
 * BIT_ORDER_MSB_FIRST = most significant bit is sent first on line
 *
 * clock polarity (choose one)
 * CLOCK_POLARITY_NORMAL (sample on falling edge of line signal)
 * CLOCK_POLARITY_INVERT (sample on rising edge of line signal)
 *
 * data polarity (choose one)
 * DATA_POLARITY_NORMAL (1 = low line signal)
 * DATA_POLARITY_INVERT (1 = high line signal)
 *
 * tx_data_rate = transmit clock (AUXCLK) rate in bits per second
 *
 * tx_frame_count = frames sent by sample send program
 * (this last option only configures the sample program, not the device)
 */
#define BIT_ORDER_LSB_FIRST   0
#define BIT_ORDER_MSB_FIRST   1
#define CLOCK_POLARITY_NORMAL 0
#define CLOCK_POLARITY_INVERT 1
#define DATA_POLARITY_NORMAL  0
#define DATA_POLARITY_INVERT  1

unsigned int sync_delay = TDM_SYNC_DELAY_NONE;
unsigned int tx_sync_width = TDM_TX_SYNC_WIDTH_SLOT;
unsigned int sync_polarity = TDM_SYNC_POLARITY_NORMAL;
unsigned int rx_frame_count = 10;
unsigned int slot_count = 4;
unsigned int slot_size = TDM_SLOT_SIZE_32BITS;
unsigned int bit_order = BIT_ORDER_MSB_FIRST;
unsigned int clock_polarity = CLOCK_POLARITY_NORMAL;
unsigned int data_polarity = DATA_POLARITY_NORMAL;
unsigned int tx_data_rate = 19200;
unsigned int tx_frame_count = 10;

/*
 * convert slot size configuration macro into numerical value
 * of buffer bytes needed to store slot (round up half bytes)
 */
unsigned int buffer_bytes_per_slot(unsigned int slot_size_macro)
{
	return (slot_size_macro + 2) / 2;
}

/*
 * set value of specified slot in buf
 *
 * index = 0 to number of slots in buf minus 1
 *
 * - each slot uses an integer number of bytes in buf
 * - each slot is stored in little endian order
 * - unused most significant bits are zero
 *
 * example:
 * 12-bit slot value of 0x123 uses 2 bytes: byte[0]=0x23, byte[1]=0x01
 * with the most significant 4 bits of byte[1] always set to 0
 */
void set_slot_data(unsigned char *buf, unsigned int index, unsigned int data)
{
	unsigned int byte_count = buffer_bytes_per_slot(slot_size);
	unsigned int byte_index = byte_count * index;
	
	/* copy data to buffer */	
	buf[byte_index]         = data & 0xff;
	if (byte_count > 1)
		buf[byte_index + 1] = (data >> 8)  & 0xff;
	if (byte_count > 2)
		buf[byte_index + 2] = (data >> 16) & 0xff;
	if (byte_count > 3)
		buf[byte_index + 3] = (data >> 24) & 0xff;
}

/*
 * get value of specified slot in buf
 *
 * index = 0 to number of slots in buf minus 1
 *
 * - each slot uses an integer number of bytes in buf
 * - each slot is stored in little endian order
 * - unused most significant bits are zero
 *
 * example:
 * 12-bit slot value of 0x123 uses 2 bytes: byte[0]=0x23, byte[1]=0x01
 * with the most significant 4 bits of byte[1] always set to 0
 */
unsigned int get_slot_data(unsigned char *buf, unsigned int index)
{
	unsigned int byte_count = buffer_bytes_per_slot(slot_size);
	unsigned int byte_index = byte_count * index;
	unsigned int data;

	/* copy buffer to data */	
	data = buf[byte_index];
	if (byte_count > 1)
		data += buf[byte_index + 1] << 8;
	if (byte_count > 2)
		data += buf[byte_index + 2] << 16;
	if (byte_count > 3)
		data += buf[byte_index + 3] << 24;
		
	return data;
}

/* global set by ctrl-C handler */
int stop_program = 0;
HANDLE dev_handle;

void sigint_handler(int sigid)
{
	stop_program = 1;
	// cancel blocked MgslRead/MgslWrite calls
	MgslCancelReceive(dev_handle);
	MgslCancelTransmit(dev_handle);
}

/*
 * configure port for TDM using global options defined above
 *
 * Notes:
 * - Complete configuration uses several different API configuration calls.
 * - Configuration calls must be performed in the order shown below.
 */
int configure_port(HANDLE dev)
{
	MGSL_PARAMS params;
	unsigned int tdm_options;
	int rc;
	
	/* Note: set TDM options before call to MgslSetParams */
	tdm_options = sync_delay | tx_sync_width | sync_polarity |
		TDM_RX_FRAME_COUNT(rx_frame_count) |
		TDM_SLOT_COUNT(slot_count) | slot_size;
	rc = MgslSetOption(dev, MGSL_OPT_TDM, tdm_options);
	if (rc != NO_ERROR) {
		printf("MgslSetOption(MGSL_OPT_TDM) error=%d\n", rc);
		return rc;
	}

	/* select bit order (0=LSB first, 1=MSB first) */
	rc = MgslSetOption(dev, MGSL_OPT_MSB_FIRST, bit_order);
	if (rc != NO_ERROR) {
		printf("MgslSetOption(MGSL_OPT_MSB_FIRST) error=%d\n", rc);
		return rc;
	}
		
	/*
	 * configure port for TDM mode
	 * loopback disabled
	 * receiver clock source = RxC clock input
	 * transmit clock source = BRG (same as AUXCLK output)
	 * encoding = NRZ
	 * transmit clock output on AUXCLK output at 115200 bps
	 */
	memset(&params, 0, sizeof(params));
	params.Mode = MGSL_MODE_TDM;
	params.Loopback = 0;
	params.Addr = 0xff;
	if (clock_polarity == CLOCK_POLARITY_NORMAL) {
		params.Flags = HDLC_FLAG_RXC_RXCPIN | HDLC_FLAG_TXC_BRG;
	} else {
		/* inverted clock polarity */
		params.Flags = HDLC_FLAG_RXC_RXCPIN | HDLC_FLAG_RXC_INV |
	    	           HDLC_FLAG_TXC_BRG    | HDLC_FLAG_TXC_INV;
	}
	if (data_polarity == DATA_POLARITY_NORMAL)
		params.Encoding = HDLC_ENCODING_NRZ;
	else
		params.Encoding = HDLC_ENCODING_NRZB; /* inverse data polarity */
		
	params.ClockSpeed = tx_data_rate;

	rc = MgslSetParams(dev, &params);
	if (rc != NO_ERROR) {
		printf("MgslSetParams error=%d\n", rc);
		return rc;
	}

	/* set blocked mode for MgslRead */
	rc = MgslSetOption(dev, MGSL_OPT_RX_POLL, 0);
	if (rc != NO_ERROR) {
		printf("MgslSetOption(MGSL_OPT_RX_POLL) error=%d", rc);
		return rc;
	}

	/* set MgslRead to return only error free data */
	rc = MgslSetOption(dev, MGSL_OPT_RX_ERROR_MASK, 1);
	if (rc != NO_ERROR) {
		printf("MgslSetOption(MGSL_OPT_RX_ERROR_MASK) error=%d", rc);
		return rc;
	}

	/* set blocked mode for MgslWrite and MgslWaitAllSent */
	rc = MgslSetOption(dev, MGSL_OPT_TX_POLL, 0);
	if (rc != NO_ERROR)
		printf("MgslSetOption(MGSL_OPT_TX_POLL) error=%d", rc);

	return rc;
}

DWORD WINAPI receive_thread_func(LPVOID context)
{
	HANDLE dev = *((HANDLE*)context);
	DWORD rc;
	unsigned int i;
	unsigned int count;
	unsigned char buf[4096];

	/* receiver must be enabled to receive data */
	rc = MgslEnableReceiver(dev, TRUE);
	if (rc != NO_ERROR)
		goto done;

	i = 1;
	while (!stop_program) {
		// MgslRead returns the number of complete frames specified by the TDM configuration.
		// For this sample, that is 10 frames of 4 slots each using 32bit slots = 160 bytes.
		count = MgslRead(dev, buf, sizeof(buf));
		if (!count)
			break;
		printf("<<< %09d receive %d bytes\n", i, count);
		{
			unsigned int frame;
			unsigned int slot;
			/* display value of all slots of all frames in buffer */
			for (frame = 0 ; frame < rx_frame_count ; frame++) {
				for (slot = 0 ; slot < slot_count ; slot++) {
					printf("frame #%d, slot #%d = %08X\n", frame+1, slot+1,
						get_slot_data(buf, frame * slot_count + slot));
				}
			}
		}
		i++;
	}

done:
	return rc;
}

void display_usage()
{
	printf("\nusage: loop <devicename>\n"
		   "Examples:\n"
           "C:>loop MGMP4P2  (adapter #4 port #2 of multiport adapter)\n"
		   "C:>loop MGHDLC1  (single port adapter adapter #1)\n"
		   "Device names are displayed in the SyncLink branch\n"
		   "of the Windows device manager.\n\n");
}

int _tmain(int argc, _TCHAR* argv[])
{
	HANDLE dev;
	char dev_name[MAX_PATH];
	HANDLE receive_thread;
	int rc;
	unsigned int i;
	unsigned char buf[4096];
	unsigned int size;

	if (argc < 2) {
		display_usage();
		return 1;
	}
	sprintf_s(dev_name, sizeof(dev_name), "%S", argv[1]); /* convert to char */
	printf("looping TDM data on %s\n", dev_name);

	rc = MgslOpenByName(dev_name, &dev);
	if (rc != NO_ERROR) {
		printf("MgslOpenByName error=%d\n", rc);
		return rc;
	}

	rc = configure_port(dev);
	if (rc != NO_ERROR)
		goto done;

	dev_handle = dev;
	signal(SIGINT, sigint_handler);
	printf("press Ctrl-C to stop program\n");

	receive_thread = CreateThread(NULL, 0, receive_thread_func, &dev, 0, NULL);

	/* initialize send buffer */
	for (i = 0 ; i < slot_count * tx_frame_count ; i++)
		set_slot_data(buf, i, 0x12345678);
		
	size = tx_frame_count * slot_count * buffer_bytes_per_slot(slot_size);

	i = 1;
	while (!stop_program) {
		printf(">>> %09d sending %d bytes\n", i, size);
		rc = MgslWrite(dev, buf, size);
		if (!rc)
			printf("MgslWrite error=%d\n", GetLastError());
		i++;
	}

	printf("waiting for all data sent...\n");
	rc = MgslWaitAllSent(dev);
	if (!rc)
		printf("all data sent\n");
	else
		printf("MgslWaitAllSent error=%d\n", rc);

done:
	MgslClose(dev);
	return 0;
}
