/*
 * raw protocol sample
 *
 * Use a single port with a loopback plug installed or
 * alter configure_port function for internal loopback.
 */

#include "stdafx.h"

/* global set by ctrl-C handler */
int stop_program = 0;
HANDLE dev_handle;

void sigint_handler(int sigid)
{
	stop_program = 1;
	// cancel blocked MgslRead/MgslWrite calls
	MgslCancelReceive(dev_handle);
	MgslCancelTransmit(dev_handle);
}

int configure_port(HANDLE dev)
{
	MGSL_PARAMS params;
	int rc;

	/*
	 * configure port for raw synchronous mode
	 * loopback disabled
	 * use external clock pins for data clocks
	 * AUXCLK output speed = 19200bps
	 */
	memset(&params, 0, sizeof(params));
	params.Mode = MGSL_MODE_RAW;
	params.Loopback = 0;
	params.Flags = HDLC_FLAG_RXC_RXCPIN + HDLC_FLAG_TXC_TXCPIN;
	params.Encoding = HDLC_ENCODING_NRZ;
	params.ClockSpeed = 19200;
	params.CrcType = HDLC_CRC_NONE;

	rc = MgslSetParams(dev, &params);
	if (rc != NO_ERROR) {
		printf("MgslSetParams error=%d\n", rc);
		return rc;
	}
	
	/* set transmit idle pattern to all ones */
	rc = MgslSetIdleMode(dev, HDLC_TXIDLE_ONES);
	if (rc != NO_ERROR) {
		printf("MgslSetIdleMode() error=%d", rc);
		return rc;
	}

	/* set blocked mode for MgslRead */
	rc = MgslSetOption(dev, MGSL_OPT_RX_POLL, 0);
	if (rc != NO_ERROR) {
		printf("MgslSetOption(MGSL_OPT_RX_POLL) error=%d", rc);
		return rc;
	}

	/* set MgslRead to return only error free data */
	rc = MgslSetOption(dev, MGSL_OPT_RX_ERROR_MASK, 1);
	if (rc != NO_ERROR) {
		printf("MgslSetOption(MGSL_OPT_RX_ERROR_MASK) error=%d", rc);
		return rc;
	}

	/* set blocked mode for MgslWrite and MgslWaitAllSent */
	rc = MgslSetOption(dev, MGSL_OPT_TX_POLL, 0);
	if (rc != NO_ERROR)
		printf("MgslSetOption(MGSL_OPT_TX_POLL) error=%d", rc);

	return rc;
}

/*
 * display a buffer of data in hex format, 16 bytes per line
 */
void display_buf(unsigned char *buf, unsigned int size)
{
	unsigned int i;

	for (i = 0 ; i < size ; i++) {
		if (!(i % 16))
			printf("%04X: ", i);
		if (i % 16 == 15)
			printf("%02X\n", *buf++);
		else
			printf("%02X ", *buf++);
	}
	if (i % 16)
			printf("\n");
}

DWORD WINAPI receive_thread_func(LPVOID context)
{
	HANDLE dev = *((HANDLE*)context);
	DWORD rc;
	unsigned int i;
	unsigned int count;
	unsigned char buf[256];

	/* receiver must be enabled to receive data */
	rc = MgslEnableReceiver(dev, TRUE);
	if (rc != NO_ERROR)
		goto done;

	i = 1;
	while (!stop_program) {
		/*
		 * get data in 256 byte fixed size blocks
		 * - reduce requested size to lower receive latency (low data rates)
		 * - increase requested size for more efficient throughput (high data rates)
		 *
		 * - For this sample, first and last 2 bytes of sent data are 0, intermediate bytes are 0x55.
		 * - This pattern is easy to detect from the all ones idle pattern.
		 * - This pattern will be shifted 0-7 bits on receive side, with each byte possibly
		 *   spanning multiple receive buffer bytes, because there is no framing/byte alignment
		 *   performed by hardware in raw mode.
		 */
		count = MgslRead(dev, buf, sizeof(buf));
		if (!count)
			break;
		printf("<<< %09d receive %d bytes\n", i, count);
		display_buf(buf, count);
		i++;
	}

done:
	return rc;
}

void display_usage()
{
	printf("\nusage: loop <devicename>\n"
		   "Examples:\n"
           "C:>loop MGMP4P2  (adapter #4 port #2 of multiport adapter)\n"
		   "C:>loop MGHDLC1  (single port adapter adapter #1)\n"
		   "Device names are displayed in the SyncLink branch\n"
		   "of the Windows device manager.\n\n");
}

int _tmain(int argc, _TCHAR* argv[])
{
	HANDLE dev;
	char dev_name[MAX_PATH];
	HANDLE receive_thread;
	int rc;
	unsigned int i;
	unsigned char buf[256];
	unsigned int size = sizeof(buf);

	if (argc < 2) {
		display_usage();
		return 1;
	}
	sprintf_s(dev_name, sizeof(dev_name), "%S", argv[1]); /* convert to char */
	printf("looping asynchronous data on %s\n", dev_name);

	rc = MgslOpenByName(dev_name, &dev);
	if (rc != NO_ERROR) {
		printf("MgslOpenByName error=%d\n", rc);
		return rc;
	}

	rc = configure_port(dev);
	if (rc != NO_ERROR)
		goto done;

	dev_handle = dev;
	signal(SIGINT, sigint_handler);
	printf("press Ctrl-C to stop program\n");

	receive_thread = CreateThread(NULL, 0, receive_thread_func, &dev, 0, NULL);

	/*
	 * initialize send buffer
	 * - First and last 2 bytes are 0, intermediate bytes are 0x55.
	 * - This pattern is easy to detect from the all ones idle pattern.
	 * - This pattern will be shifted 0-7 bits on receive side, with each byte possibly
	 *   spanning multiple receive buffer bytes, because there is no framing/byte alignment
	 *   performed by hardware in raw mode.
	 */
	memset(buf, 0x55, size);
	buf[0] = 0;
	buf[1] = 0;
	buf[size-2] = 0; 
	buf[size-1] = 0; 

	i = 1;
	while (!stop_program) {
		printf(">>> %09d sending %d bytes\n", i, size);
		rc = MgslWrite(dev, buf, size);
		if (!rc)
			printf("MgslWrite error=%d\n", GetLastError());
		i++;
	}

	printf("waiting for all data sent...\n");
	rc = MgslWaitAllSent(dev);
	if (!rc)
		printf("all data sent\n");
	else
		printf("MgslWaitAllSent error=%d\n", rc);

done:
	MgslClose(dev);
	return 0;
}
