========================================================================
    CONSOLE APPLICATION : loop
========================================================================

This program loops (send and receives) bisync data on a single serial device.

By default, an external loopback plug or cable must be attached. Alternatively, edit
the configure_port function to enable internal loopback mode.

The program accepts a single command line argument identifying the device to use.

==================================
Build Notes
==================================

Building the application requires installing the Microgate serial API and setting
the MGAPI environment variable. MGAPI is used in the project properties to locate
the API header file (mghdlc.h) and the API import library (mghdlc.lib).

Environment variables are defined in the system settings of the Windows control panel.
Verify the environment variable is set by running "set MGAPI" from a command prompt.
You should see something like "MGAPI=C:\MGAPI" that points to the location of the
serial API installation. It may be necessary to reboot the system for Visual Studio
to recognize the new environment variable.

Open the project properties by right clicking on the project in the Solution Explorer
and selecting "Properties" from the pop-up menu.

The project properties must include the following:

In the "Configuration Properties" branch (expand if needed) on the left side of the
"Property Pages" window, find and expand the "C/C++" branch. Select the "General"
item under "C/C++". On the right, add "$(MGAPI)\c\include" to "Additional Include Directories".
This location contains the API header file (mghdlc.h) that must be included in
the application code.

In the "Configuration Properties" branch, find and expand the "Linker" branch.
Select the "General" item under "Linker". On the right, add "$(MGAPI)\c\lib" (32-bit) or
"$(MGAPI)\c\lib\x64" (64-bit) to "Additional Library Directories". This location contains
the API import library (mghdlc.lib) that the application code is linked against.

Select the "Input" item under "Linker". On the right, add "mghdlc.lib" to
"Additional Dependencies". This informs the linker to link the application
to this library.

