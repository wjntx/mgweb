/*
 * bisync protocol sample
 *
 * Use a single port with a loopback plug installed or
 * alter configure_port function for internal loopback.
 */

#include "stdafx.h"

/* These patterns are samples. Actual values are application dependent. */

/* 16 bit synchronization pattern (activates receiver on remote end) */
unsigned char syn1 = 0x67;
unsigned char syn2 = 0x98;

/* start and end of block characters (marks data boundaries) */
unsigned char start_of_block = 0x55;
unsigned char end_of_block = 0xaa;

/* global set by ctrl-C handler */
int stop_program = 0;
HANDLE dev_handle;

void sigint_handler(int sigid)
{
	stop_program = 1;
	// cancel blocked MgslRead/MgslWrite calls
	MgslCancelReceive(dev_handle);
	MgslCancelTransmit(dev_handle);
}

int configure_port(HANDLE dev)
{
	unsigned int idle;
	MGSL_PARAMS params;
	int rc;

	/*
	 * configure port for bisync mode
	 * loopback disabled
	 * receiver clock source = RxC clock input
	 * transmit clock source = TxC clock input
	 * encoding = NRZ
	 * output clock on AUXCLK output at 19200 bps
	 * disable ITU/CCITT CRC-16 frame checking (not supported in bisync mode)
	 */
	memset(&params, 0, sizeof(params));
	params.Mode = MGSL_MODE_BISYNC;
	params.Loopback = 0;
	params.Flags = HDLC_FLAG_RXC_RXCPIN + HDLC_FLAG_TXC_TXCPIN;
	params.Encoding = HDLC_ENCODING_NRZ;
	params.ClockSpeed = 19200;
	params.CrcType = HDLC_CRC_NONE;

	rc = MgslSetParams(dev, &params);
	if (rc != NO_ERROR) {
		printf("MgslSetParams error=%d\n", rc);
		return rc;
	}
	
	/* set SYN1 and SYN2 sync characters */
	idle = HDLC_TXIDLE_CUSTOM_16 | (syn2 << 8) | syn1;
	rc = MgslSetIdleMode(dev, idle);
	if (rc != NO_ERROR) {
		printf("MgslSetIdleMode() error=%d", rc);
		return rc;
	}

	/* set blocked mode for MgslRead */
	rc = MgslSetOption(dev, MGSL_OPT_RX_POLL, 0);
	if (rc != NO_ERROR) {
		printf("MgslSetOption(MGSL_OPT_RX_POLL) error=%d", rc);
		return rc;
	}

	/* set MgslRead to return only error free data */
	rc = MgslSetOption(dev, MGSL_OPT_RX_ERROR_MASK, 1);
	if (rc != NO_ERROR) {
		printf("MgslSetOption(MGSL_OPT_RX_ERROR_MASK) error=%d", rc);
		return rc;
	}

	/* set blocked mode for MgslWrite and MgslWaitAllSent */
	rc = MgslSetOption(dev, MGSL_OPT_TX_POLL, 0);
	if (rc != NO_ERROR)
		printf("MgslSetOption(MGSL_OPT_TX_POLL) error=%d", rc);

	return rc;
}

/*
 * Assemble receive data into application defined block marked by start/end of block patterns.
 * One block of data may span multiple receive_data calls.
 *
 * Note: This is a sample and the start/end block format for an actual application
 *       will be different.
 *
 * Enable receiver when starting to receive block and disable receive after receiving block. This
 * forces the hardware to search for leading 16-bit sync pattern (hunt mode) at start of each block.
 * If you leave receiver active after receiving a block, following blocks may not be properly byte aligned
 * and receive buffers will fill with idle pattern or noise between blocks.
 *
 * This sample assumes blocks are not byte aligned to each other, requiring the receiver
 * to reset after each block is received so it resynchronizes for each block.
 *
 * Actual applications may send multiple byte aligned blocks that do not require resynchronization
 * on each block. In this case the receiver must remain active (no reset) between blocks. The application
 * is responsible for determining when the receiver must resynchronize between blocks.
 *
 * dev            = open device handle
 * block_buf      = buffer to hold block data
 * block_buf_size = size of block_buf in bytes
 *
 * returns 0 on error or the size of a returned block in bytes
 */
int receive_block(HANDLE dev, unsigned char *block_buf, unsigned int block_buf_size)
{
	unsigned char buf[128];
	unsigned int count;
	unsigned int block_buf_count = 0;
	unsigned int i;
	bool sob = false;
	bool eob = false;

	MgslEnableReceiver(dev, 1); /* enable receiver */

	while (!stop_program) {

		/*
		 * wait for received data in fixed increment (128 bytes default covers most cases)
		 * larger increment increases receive latency to detect sob/eob
		 * smaller increment increases call overhead and may limit max data rate
		 * For high data rates you may need to increase value.
		 * For low data rates you may need to decrease value.
		 */
		count = MgslRead(dev, buf, sizeof(buf));
		if (count == 0)
			continue;

		/* find start of block (discard leading bytes and sob char) */
		if (!sob) {
			for (i=0 ; i < count ; i++) {
				if (buf[i] == start_of_block) {
					printf("<<< start of block\n");
					sob = true;
					count -= i;
					memmove(buf, buf + i, count);
					break;
				}
			}
		}
		if (!sob)
			continue;

		/* find end of block (discard eob char and trailing bytes) */
		for (i=0 ; i < count ; i++) {
			if (buf[i] == end_of_block) {
				count = i + 1;
				eob = true;
				break;
			}
		}

		printf("<<< received %d bytes\n", count);
		if (block_buf_count + count > block_buf_size) {
			printf("error, block is larger than buffer size\n");
			break;
		}

		/* store data to block buffer */
		memcpy(block_buf, buf, count);
		block_buf += count;
		block_buf_count += count;

		if (eob) {
			printf("<<< end of block, block size = %d, disable receiver\n", block_buf_count);
			MgslEnableReceiver(dev, 0); /* disable receiver */
			return block_buf_count;
		}
	}
	
	MgslEnableReceiver(dev, 0); /* error or control-break, disable receiver */
	return 0;
}

DWORD WINAPI receive_thread_func(LPVOID context)
{
	HANDLE dev = *((HANDLE*)context);
	unsigned int i;
	unsigned int count;
	unsigned char buf[4096];

	i = 1;
	while (!stop_program) {
		count = receive_block(dev, buf, sizeof(buf));
		if (count == 0) {
			printf("error or user stop request\n");
			break;
		}
		printf("<<< %09d block received %d bytes\n", i, count);
		i++;
	}

	return 0;
}

void display_usage()
{
	printf("\nusage: loop <devicename>\n"
		   "Examples:\n"
           "C:>send MGMP4P2  (adapter #4 port #2 of multiport adapter)\n"
		   "C:>send MGHDLC1  (single port adapter adapter #1)\n"
		   "Device names are displayed in the SyncLink branch\n"
		   "of the Windows device manager.\n\n");
}

int _tmain(int argc, _TCHAR* argv[])
{
	char dev_name[MAX_PATH];
	HANDLE dev;
	HANDLE receive_thread;
	unsigned char buf[512];
	int size = sizeof(buf);
	int rc;
	unsigned int i;

	if (argc < 2) {
		display_usage();
		return 1;
	}
	sprintf_s(dev_name, sizeof(dev_name), "%S", argv[1]); /* convert to char */
	printf("looping bisync data on %s\n", dev_name);

	rc = MgslOpenByName(dev_name, &dev);
	if (rc != NO_ERROR) {
		printf("MgslOpenByName error=%d\n", rc);
		return rc;
	}

	rc = configure_port(dev);
	if (rc != NO_ERROR)
		goto done;

	dev_handle = dev;
	signal(SIGINT, sigint_handler);
	printf("press Ctrl-C to stop program\n");

	receive_thread = CreateThread(NULL, 0, receive_thread_func, &dev, 0, NULL);

	/*
	 * initialize send buffer
	 *
	 * 16 bit sync pattern (activates remote receiver)
	 * start of block character
	 * data (all zero)
	 * end of block character
	 *
	 * Note: hardware does not automatically send leading syncs,
	 * the application must send leading syncs as part of data.
	 */
	memset(buf, 0, size);
	buf[0] = syn1;
	buf[1] = syn2;
	buf[2] = start_of_block;
	buf[size-1] = end_of_block; 

	i = 1;
	while (!stop_program) {

		// This sample assumes blocks are not byte aligned to each other, requiring the receiver
		// to reset after each block is received so it resynchronizes for each block. To allow time
		// for the receiver reset/resynchronization a delay is added between sending blocks.
		//
		// Actual applications may send multiple byte aligned blocks that do not require resynchronization
		// on each block. In this case the receiver must remain active (no reset) between blocks. The application
		// is responsible for determining when the receiver must resynchronize between blocks.

		printf(">>> %09d sending 16-bit sync and %d byte block\n", i, size - 2);
		rc = MgslWrite(dev, buf, size);
		if (!rc)
			printf("MgslWrite error=%d\n", GetLastError());

		printf("waiting for all data sent...\n");
		rc = MgslWaitAllSent(dev);
		if (!rc)
			printf("all data sent\n");
		else
			printf("MgslWaitAllSent error=%d\n", rc);

		// Disable transmitter between unaligned data blocks.
		// When disabled, the transmitter is held in a continuous one state and
		// subsequent send data is not byte aligned to previous data.
		//
		// When enabled and idle, the transmitter inserts sync patterns to maintain
		// byte alignment between data blocks. The choice of behavior is application dependent.
		//
		// Calling MgslWrite enables the transmitter without calling MgslEnableTransmitter(dev, 1).
		// The transmitter remains enabled until calling MgslEnableTransmitter(dev, 0).
		MgslEnableTransmitter(dev, 0);

		// application specific delay to allow remote receiver to reset
		Sleep(50);

		i++;
	}


	/*
	 * Receive side may require extra data clocks to completely process
	 * received data. Maintain clock output for a second.
	 * If clocks are supplied by external device, this is not needed.
	 */
	printf("delay for receive to complete\n");
	Sleep(1000);

done:
	MgslClose(dev);
	return 0;
}
