==================================
console application loop
==================================

This Windows console application demonstrates sending data and receiving
data using the asynchronous serial protocol on a SyncLink device
with the Windows Communication API instead of Microgate Serial API.
See Microsoft documentation for details of Windows Comm API. Device names
for Windows Comm API are different than that used for Microgate Serial API.

Run the application with a single argument identifying the device by name.

Example:
C:>loop MGC1

Device names are displayed in the SyncLink branch of the Windows device manager.

==================================
Build Notes
==================================


