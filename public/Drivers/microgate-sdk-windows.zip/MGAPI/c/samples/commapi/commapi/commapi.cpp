/*
 * asynchronous protocol sample data using Windows Communication API
 * instead of Microgate Serial API. See Microsoft documentation
 * for details of Windows Comm API. Device names for Windows Comm API
 * are different than that used for Microgate Serial API.
 *
 * Use a single port with a loopback plug installed.
 */

#include "stdafx.h"

/* global set by ctrl-C handler */
int stop_program = 0;

void sigint_handler(int sigid)
{
	stop_program = 1;
}

int configure_port(HANDLE dev)
{
	DCB cfg; /* device configuration block */
	COMMTIMEOUTS timeouts = {0};
	int rc;

	/* get current device configuration */
	memset(&cfg, 0, sizeof(cfg));
	cfg.DCBlength = sizeof(DCB);
	if (!GetCommState(dev, &cfg)) {
		rc = GetLastError();
		printf("GetCommState() error %d", rc);
		return rc;
	}

	/* modify device configuration */
	cfg.BaudRate = 19200;
	cfg.ByteSize = 8;
	cfg.fParity  = TRUE;
	cfg.Parity   = NOPARITY;
	cfg.StopBits = ONESTOPBIT;

	/* set device configuration */
	if (!SetCommState(dev, &cfg)) {
		rc = GetLastError();
		printf("SetCommState() error %d", rc);
		return rc;
	}
	
	/* no read timeout, block until all requested data available */
	timeouts.ReadIntervalTimeout=0;
	timeouts.ReadTotalTimeoutConstant=0;
	timeouts.ReadTotalTimeoutMultiplier=0;

	/* no write timeout, block until all data accepted */
	timeouts.WriteTotalTimeoutConstant=0;
	timeouts.WriteTotalTimeoutMultiplier=0;
	
	if(!SetCommTimeouts(dev, &timeouts)){
		rc = GetLastError();
		printf("SetCommTimeouts() error %d", rc);
		return rc;
	}

	return NO_ERROR;
}

DWORD WINAPI receive_thread_func(LPVOID context)
{
	HANDLE dev = *((HANDLE*)context);
	DWORD rc;
	unsigned int i = 1;
	DWORD count;
	unsigned char buf[1024];

	while (!stop_program) {
		if (!ReadFile(dev, buf, sizeof(buf), &count, NULL)) {
			rc = GetLastError();
			if (rc != NO_ERROR) {
				printf("ReadFile error=%d\n", rc);
				break;
			}
		}
		printf("<<< %09d receive %d bytes\n", i, count);
		i++;
	}
	return rc;
}

void display_usage()
{
	printf("\nusage: loop <devicename>\n"
		   "Examples:\n"
           "C:>loop MC42  (adapter #4 port #2 of multiport adapter)\n"
		   "C:>loop MGC1  (single port adapter adapter #1)\n"
		   "Device names are displayed in the SyncLink branch\n"
		   "of the Windows device manager.\n\n");
}

int _tmain(int argc, TCHAR* argv[])
{
	HANDLE dev;
	TCHAR dev_name[MAX_PATH];
	HANDLE receive_thread;
	int rc;
	unsigned char buf[1024];
	DWORD size = sizeof(buf);
	DWORD count;
	unsigned int i;

	if (argc < 2) {
		display_usage();
		return 1;
	}

	/* add device name prefix */
	_stprintf_s(dev_name, sizeof(dev_name)/sizeof(TCHAR), TEXT("\\\\.\\%s"), argv[1]);
	_tcprintf(TEXT("sending asynchronous data on %s\n"), dev_name);

	/* open device */
	dev = CreateFile(dev_name, GENERIC_READ + GENERIC_WRITE, 0, NULL,
					 OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (dev == INVALID_HANDLE_VALUE) {
		rc = GetLastError();
		printf("CreateFile() error %d", rc);
		return rc;
	}

	rc = configure_port(dev);
	if (rc != NO_ERROR)
		goto done;

	signal(SIGINT, sigint_handler);
	printf("press Ctrl-C to stop program\n");

	/* initialize send buffer */
	for (i=0 ; i < size ; i++)
		buf[i] = (unsigned char)i;

	printf("Turn on DTR and RTS\n");
	if (!EscapeCommFunction(dev, SETDTR))
		printf("EscapeCommFunction(SETDTR) error %d\n", GetLastError());
	if (!EscapeCommFunction(dev, SETRTS))
		printf("EscapeCommFunction(SETRTS) error %d\n", GetLastError());

	receive_thread = CreateThread(NULL, 0, receive_thread_func, &dev, 0, NULL);

	i = 1;
	while (!stop_program) {
		printf(">>> %09d sending %d bytes\n", i, size);
		if (!WriteFile(dev, buf, size, &count, NULL)) {
			rc = GetLastError();
			if (rc != NO_ERROR) {
				printf("WriteFile error=%d\n", rc);
				return rc;
			}
		}
		i++;
	}

	printf("wait for all data sent...\n");
	FlushFileBuffers(dev);
	printf("all data sent\n");

	printf("Turn off DTR and RTS\n");
	if (!EscapeCommFunction(dev, CLRDTR))
		printf("EscapeCommFunction(CLRDTR) error %d\n", GetLastError());
	if (!EscapeCommFunction(dev, CLRRTS))
		printf("EscapeCommFunction(CLRRTS) error %d\n", GetLastError());

done:
	CloseHandle(dev);
	return 0;
}

