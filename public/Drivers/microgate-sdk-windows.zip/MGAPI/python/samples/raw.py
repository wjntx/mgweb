# raw synchronous protocol sample
# - send data in main thread
# - receive data in receive thread
#
# == Single Port Use ==
# Connect data and clock outputs to data and clock inputs with
# loopback plug or external cabling. Alternatively, set
# settings.internal_loopback = True.
#
# == Two Port Use ==
# Connect ports with crossover cable that:
# - connects data output of each port to data input of other port
# - connects clock output of one port to clock inputs of both ports
# Run sample on both ports.

import sys
import threading

# mgapi module is available to import if:
# 1. mgapi package installed using pip command.
# 2. mgapi.py is in current directory or python sys path.
sys.path.append('..')  # not needed if mgapi package installed using pip
from mgapi import Port


def display_buf(buf: bytearray):
    """display a buffer of data in hex format, 16 bytes per line"""
    output = ''
    size = len(buf)
    for i in range(0, size):
        if not (i % 16):
            output += '{:0>9x}'.format(i) + ': '
        if i % 16 == 15:
            output += '{:0>2x}'.format(buf[i]) + '\n'
        else:
            output += '{:0>2x}'.format(buf[i]) + ' '
    if size % 16:
        output += '\n'
    print(output, end='')


def receive_thread_func():
    # Lower value reduces latency but increases processing overhead.
    read_size = 128

    i = 1
    while True:
        # - For this sample, first and last 2 bytes of sent data are 0, other bytes are 0x55.
        # - This pattern is easy to detect from the all ones idle pattern.
        # - This pattern will be shifted 0-7 bits on receive side, with each byte possibly
        #   spanning multiple receive buffer bytes, because there is no framing/byte alignment
        #   performed by hardware in raw mode.
        buf = port.read(read_size)
        if not buf:
            break
        print('<<< ' + '{:0>9d}'.format(i) + ' received ' + 
              str(len(buf)) + ' bytes\n', end='')
        display_buf(buf)
        i += 1


# port name format
# single port adapter: MGHDLCx, x=adapter number
# multiport adapter: MGMPxPy, x=adapter number, y=port number
if len(sys.argv) < 2:
    # no port name on command line, use first enumerated port
    names = Port.enumerate()
    if not names:
        print('no ports available')
        exit()
    port = Port(names[0])
else:
    port = Port(sys.argv[1])
print('raw bitstream sample running on', port.name)

try:
    port.open()
except FileNotFoundError:
    print('port not found')
    exit()
except PermissionError:
    print('access denied or port in use')
    exit()
except OSError:
    print('open error')
    exit()

# If default 14.7456MHz base clock does not allow exact
# internal clock generation of desired rate, uncomment these lines and
# select a new base clock sourced from the frequency synthesizer.
# PCI Express/USB only. See API manual for details.
# fsynth_rate = 16000000
# if port.set_fsynth_rate(fsynth_rate):
#     print('base clock set to', fsynth_rate)
# else:
#     print(fsynth_rate, 'not supported by fsynth')
#     exit()

settings = Port.Settings()
settings.protocol = Port.RAW
settings.encoding = Port.NRZ
settings.crc = Port.OFF
settings.transmit_clock = Port.TXC_INPUT
settings.receive_clock = Port.RXC_INPUT
settings.internal_clock_rate = 2400
port.apply_settings(settings)

# send all ones when no data is available
port.transmit_idle_pattern = 0xff

print('press Ctrl-C to stop program')

port.enable_receiver()
receive_thread = threading.Thread(target=receive_thread_func)
receive_thread.start()

# prepare send buffer
# - First and last 2 bytes are 0, other bytes are 0x55.
# - This pattern is easy to detect from the all ones idle pattern.
# - This pattern will be shifted 0-7 bits on receive side, with each byte possibly
#   spanning multiple receive buffer bytes, because there is no framing/byte alignment
#   performed by hardware in raw mode.
buf = bytearray(128)
for i in range(0, len(buf)):
    buf[i] = 0x55
buf[0] = 0
buf[1] = 0
buf[len(buf)-2] = 0
buf[len(buf)-1] = 0

i = 1
try:
    while True:
        print('>>> ' + '{:0>9d}'.format(i) + ' send ' +
            str(len(buf)) + ' bytes\n', end='')
        port.write(buf)
        port.flush()
        i += 1
except KeyboardInterrupt:
    print('Ctrl-C pressed')
    port.close()