# HDLC/SDLC sample using C API wrapper
#
# This sample performs the same task as hdlc.py but uses
# the C API wrapper to ease porting C applications
# to Python. The wrapper follows the structure and naming
# of the C API as closely as possible. Refer to the
# C API documentation for details and this sample
# for how the C API maps to Python.
#
# New applications should use the Python optimized serial API
# as shown in hdlc.py and the Python API documentation.

import sys
import threading
from signal import signal, SIGINT

# mgapi module is available to import if:
# 1. mgapi package installed using pip command.
# 2. mgapi.py is in current directory or python sys path.
sys.path.append('..')  # not needed if mgapi package installed using pip
import mgapi


def receive_thread_func():
    # 4096 = MaxFrameSize
    buf = bytearray(4096)
    i = 1
    while True:
        # get one HDLC frame of variable size
        count = mgapi.MgslRead(port, buf, len(buf))
        if not count:
            break
        print('<<< ' + '{:0>9d}'.format(i) + ' received ' + 
            str(count) + ' bytes\n', end='')
        i += 1


# port name format
# single port adapter: MGHDLCx, x=adapter number
# multiport adapter: MGMPxPy, x=adapter number, y=port number
if len(sys.argv) < 2:
    port_name = 'MGHDLC1'
else:
    port_name = sys.argv[1]
print('C serial API wrapper sample running on', port_name)

port = mgapi.HANDLE()
error = mgapi.MgslOpenByName(port_name, port)
if error == mgapi.ERROR_BAD_DEVICE:
    print('port not found')
    exit(error)
elif error == mgapi.ERROR_ACCESS_DENIED or \
     error == mgapi.ERROR_DEVICE_IN_USE or \
     error == mgapi.ERROR_OPEN_FAILED:
    print('access denied or port in use')
    exit(error)
elif error:
    print('MgslOpenByName error =', error)
    exit(error)

params = mgapi.MGSL_PARAMS()
params.Mode = mgapi.MGSL_MODE_HDLC
params.Loopback = 0
params.Flags = mgapi.HDLC_FLAG_RXC_RXCPIN | mgapi.HDLC_FLAG_TXC_TXCPIN
params.Encoding = mgapi.HDLC_ENCODING_NRZ
params.ClockSpeed = 9600
params.CrcType = mgapi.HDLC_CRC_16_CCITT
params.Addr = 0xff
params.PreambleLength = mgapi.HDLC_PREAMBLE_LENGTH_8BITS
params.PreamblePattern = mgapi.HDLC_PREAMBLE_PATTERN_NONE
mgapi.MgslSetParams(port, params)

# set transmit pattern when not sending data
mgapi.MgslSetIdleMode(port, mgapi.HDLC_TXIDLE_FLAGS)

# set blocked mode for MgslRead
mgapi.MgslSetOption(port, mgapi.MGSL_OPT_RX_POLL, False)

# set MgslRead to return only error free data
mgapi.MgslSetOption(port, mgapi.MGSL_OPT_RX_ERROR_MASK, True)

# set blocked mode for MgslWrite and MgslWaitAllSent
mgapi.MgslSetOption(port, mgapi.MGSL_OPT_TX_POLL, False)

print('press Ctrl-C to stop program')

mgapi.MgslEnableReceiver(port, True)
receive_thread = threading.Thread(target=receive_thread_func)
receive_thread.start()

# prepare send buffer
buf = bytearray(100)
for i in range(0, len(buf)):
    buf[i] = i & 0xff

i = 1
try:
    while True:
        # send one HDLC frame
        print('>>> ' + '{:0>9d}'.format(i) + ' send ' +
            str(len(buf)) + ' bytes\n', end='')
        bytes_sent = mgapi.MgslWrite(port, buf, len(buf))
        if bytes_sent != len(buf):
            break
        mgapi.MgslWaitAllSent(port)
        i += 1
except KeyboardInterrupt:
    print('Ctrl-C pressed')
    mgapi.MgslClose(port)