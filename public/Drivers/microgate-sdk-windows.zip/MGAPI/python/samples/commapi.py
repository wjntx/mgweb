# asynchronous sample using pyserial/Windows Comm API.
#
# Use a single port with a loopback plug installed or
# alter configure_port function for internal loopback.
#
# Windows Comm API device names are different than
# Microgate Serial API device names. See comments below.
#
# pyserial is not included with base python installation.
# Install pyserial using command 'pip install pyserial'.

import sys
import threading
import serial
import ctypes


def receive_thread_func():
    i = 1
    while True:
        buf = port.read(100)
        if not buf:
            break
        print('<<< ' + '{:0>9d}'.format(i) + ' received ' + 
              str(len(buf)) + ' bytes\n', end='')
        i += 1


# Windows Comm API uses secondary device names:
# Single Port Adapter: \\.\MGCx, x=adapter number
# Multiport Adapter:   \\.\MCxy, x=adapter number y=port number
#
# Using primary (mgapi) device names (MGHDLCx or MGMPxPy) with
# the Windows Comm API or pyserial wrapper results in errors and
# undefined behavior.
if len(sys.argv) < 2:
    port_name = 'MGC1'
else:
    port_name = sys.argv[1]
print('pyserial sample running on', port_name)

port = serial.Serial()
port.port = '\\\\.\\' + port_name
port.baudrate = 9600
port.bytesize = serial.EIGHTBITS
port.stopbits = serial.STOPBITS_ONE
port.parity = serial.PARITY_NONE

port.open()
if not port.is_open:
    print('failed to open port', port_name)
    exit(1)

print('press Ctrl-C to stop program')

receive_thread = threading.Thread(target=receive_thread_func)
receive_thread.start()

# prepare send buffer
buf = bytearray(100)
for i in range(0, len(buf)):
    buf[i] = i & 0xff

i = 1
try:
    while True:
        print('>>> ' + '{:0>9d}'.format(i) + ' send ' +
            str(len(buf)) + ' bytes\n', end='')
        port.write(buf)
        port.flush()
        i += 1
except KeyboardInterrupt:
    print('Ctrl-C pressed')
    port.close()