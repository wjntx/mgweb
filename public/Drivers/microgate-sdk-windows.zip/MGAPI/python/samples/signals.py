# signal control and monitoring sample
#
# The RTS output should be connected to the CTS input.

import sys
import time

# mgapi module is available to import if:
# 1. mgapi package installed using pip command.
# 2. mgapi.py is in current directory or python sys path.
sys.path.append('..')  # not needed if mgapi package installed using pip
from mgapi import Port


# port name format
# single port adapter: MGHDLCx, x=adapter number
# multiport adapter: MGMPxPy, x=adapter number, y=port number
if len(sys.argv) < 2:
    # no port name on command line, use first enumerated port
    names = Port.enumerate()
    if not names:
        print('no ports available')
        exit()
    port = Port(names[0])
else:
    port = Port(sys.argv[1])
print('signals sample running on', port.name)

try:
    port.open()
except FileNotFoundError:
    print('port not found')
    exit()
except PermissionError:
    print('access denied or port in use')
    exit()
except:
    print('open error')
    exit()

print('turn on RTS')
port.rts = True

print('wait 1 second for CTS on')
# This blocks for 1 second waiting for CTS on.
# port.wait() called without timeout argument waits forever.
# A blocked wait can be cancelled with port.cancel_wait().
events = port.wait(Port.CTS_ON, timeout=1000)
if events & Port.CTS_ON:
    print('CTS is on')
else:
    print('wait timed out or cancelled')

print('turn off RTS')
port.rts = False

print('poll for CTS off for 1 second')
for i in range(9):
    if not port.cts:
        break
    time.sleep(0.1)
print('CTS is off')

port.close()